package com.xnullcat.app;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Sambungan internet (Firebase) ke HP anak (aplikasi Jaga Anak).
 * Pesan berupa satu baris JSON per perintah. Semua field publik hanya dibaca dan diubah di main thread.
 */
final class Link {
    static final int IDLE = 0, CONNECTING = 1, CONNECTED = 2;

    interface Listener {
        void onLinkChanged();
    }

    static final class App {
        final String name;
        final String pkg;

        App(String name, String pkg) {
            this.name = name;
            this.pkg = pkg;
        }
    }

    private final Handler main = new Handler(Looper.getMainLooper());

    Listener listener;
    int state = IDLE;
    String name = "";
    String address = "";
    String error = null;
    boolean net = true; // selalu lewat internet (Firebase)
    boolean online = true; // HP anak sedang aktif
    boolean screenLocked;
    final Set<String> lockedApps = new HashSet<>();
    List<App> apps; // null = belum dimuat
    String photoB64; // null = belum ada foto
    int photoSeq; // bertambah tiap foto baru datang, supaya tampilan tahu kapan harus digambar ulang
    String screenB64; // null = belum ada frame layar (Live Screen)
    int screenSeq;

    private volatile int generation;
    private NetLink netLink;
    private boolean haveSeen;
    private long lastSeen;
    private long lastChange;
    private static final long ONLINE_MS = 75000; // HP anak mengabari tiap 30 detik

    /** Menyambung lewat internet memakai kode dari HP anak. Dipanggil dari main thread. */
    void connectNet(final String code, String label) {
        final int gen;
        synchronized (this) {
            closeNetLocked();
            gen = ++generation;
        }
        online = false;
        haveSeen = false;
        state = CONNECTING;
        name = label;
        address = "net:" + code;
        error = null;
        screenLocked = false;
        lockedApps.clear();
        photoB64 = null;
        screenB64 = null;
        apps = null;
        notifyChanged();
        final NetLink nl = new NetLink(code, new java.util.concurrent.Executor() {
            @Override
            public void execute(Runnable r) {
                main.post(r);
            }
        }, new NetLink.Sink() {
            @Override
            public void opened() {
                if (gen != generation) {
                    return;
                }
                state = CONNECTED;
                error = null;
                notifyChanged();
                send("status", null); // supaya HP anak langsung mengabari keadaannya
                main.postDelayed(expire, 10000);
            }

            @Override
            public void line(String json) {
                if (gen == generation) {
                    handle(json, gen);
                }
            }

            @Override
            public void seen(long value) {
                if (gen != generation) {
                    return;
                }
                if (!haveSeen) {
                    haveSeen = true; // nilai pertama hanya patokan, bisa saja sudah lama
                } else if (value != lastSeen) {
                    lastChange = SystemClock.elapsedRealtime();
                    if (!online) {
                        online = true;
                        notifyChanged();
                    }
                }
                lastSeen = value;
            }

            @Override
            public void name(String n) {
                if (gen == generation && n != null && !n.isEmpty() && !n.equals(name)) {
                    name = n;
                    notifyChanged();
                }
            }

            @Override
            public void photo(String base64) {
                if (gen == generation && base64 != null && !base64.isEmpty()) {
                    photoB64 = base64;
                    photoSeq++;
                    notifyChanged();
                }
            }

            @Override
            public void screen(String base64) {
                if (gen == generation && base64 != null && !base64.isEmpty()) {
                    screenB64 = base64;
                    screenSeq++;
                    notifyChanged();
                }
            }

            @Override
            public void failed(String message, boolean permanent) {
                if (gen != generation) {
                    return;
                }
                if (permanent) {
                    state = IDLE;
                    error = message;
                    screenLocked = false;
                    lockedApps.clear();
                    photoB64 = null;
                    screenB64 = null;
                    apps = null;
                } else {
                    online = false; // terputus sebentar, aliran mencoba lagi sendiri
                }
                notifyChanged();
            }
        });
        netLink = nl;
        nl.start();
    }

    /** Mengecek tiap beberapa detik apakah HP anak masih mengabari. */
    private final Runnable expire = new Runnable() {
        @Override
        public void run() {
            if (state == IDLE) {
                return;
            }
            if (online && SystemClock.elapsedRealtime() - lastChange > ONLINE_MS) {
                online = false;
                notifyChanged();
            }
            main.postDelayed(this, 10000);
        }
    };

    /** Dipanggil dari main thread. */
    void disconnect() {
        synchronized (this) {
            generation++;
            closeNetLocked();
        }
        online = true;
        state = IDLE;
        error = null;
        screenLocked = false;
        lockedApps.clear();
        photoB64 = null;
        screenB64 = null;
        apps = null;
        notifyChanged();
    }

    void send(String cmd, String pkg) {
        send(cmd, pkg, null, null, null);
    }

    /** msg dan pw (hash) dipakai oleh perintah lockScreen. */
    void send(String cmd, String pkg, String msg, String pw) {
        send(cmd, pkg, msg, pw, null);
    }

    /** Mengirim perintah bawa gambar (base64), dipakai perintah wallpaper. */
    void sendImage(String cmd, String base64) {
        send(cmd, null, null, null, base64);
    }

    /** img = base64 (dipakai perintah wallpaper), boleh null. */
    void send(String cmd, String pkg, String msg, String pw, String img) {
        NetLink nl = netLink;
        if (nl != null) {
            nl.send(cmd, pkg, msg, pw, img);
        }
    }

    private void handle(String line, int gen) {
        try {
            JSONObject o = new JSONObject(line);
            final String type = o.optString("type");
            final boolean sl = o.optBoolean("screenLocked", false);
            final Set<String> la = new HashSet<>();
            JSONArray ja = o.optJSONArray("lockedApps");
            if (ja != null) {
                for (int i = 0; i < ja.length(); i++) {
                    la.add(ja.getString(i));
                }
            }
            final List<App> list = "apps".equals(type) ? parseApps(o) : null;
            final String photo = "photo".equals(type) ? o.optString("photo", null) : null;
            postIfCurrent(gen, new Runnable() {
                @Override
                public void run() {
                    if ("state".equals(type) || "apps".equals(type)) {
                        screenLocked = sl;
                        lockedApps.clear();
                        lockedApps.addAll(la);
                    }
                    if (list != null) {
                        apps = list;
                    }
                    if (photo != null) {
                        photoB64 = photo;
                        photoSeq++;
                    }
                }
            });
        } catch (Exception ignored) {
            // baris rusak diabaikan
        }
    }

    private static List<App> parseApps(JSONObject o) throws Exception {
        List<App> list = new ArrayList<>();
        JSONArray arr = o.optJSONArray("apps");
        if (arr != null) {
            for (int i = 0; i < arr.length(); i++) {
                JSONObject x = arr.getJSONObject(i);
                list.add(new App(x.getString("n"), x.getString("p")));
            }
        }
        return list;
    }

    private void postIfCurrent(final int gen, final Runnable change) {
        main.post(new Runnable() {
            @Override
            public void run() {
                if (gen == generation) {
                    change.run();
                    notifyChanged();
                }
            }
        });
    }

    private void notifyChanged() {
        if (listener != null) {
            listener.onLinkChanged();
        }
    }

    private void closeNetLocked() {
        if (netLink != null) {
            netLink.close();
            netLink = null;
        }
        main.removeCallbacks(expire);
    }
}
