package com.xnullcat.app;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.media.MediaPlayer;
import android.view.Surface;
import android.view.TextureView;

/** Video (dengan suara) yang diputar SEKALI saja lalu memanggil callback selesai. Dipakai untuk transisi welcome. */
final class OnceVideo extends TextureView implements TextureView.SurfaceTextureListener {

    interface OnFinished {
        void run();
    }

    private final String asset;
    private final OnFinished onFinished;
    private MediaPlayer mp;
    private int vw;
    private int vh;
    private boolean done;

    OnceVideo(Context c, String asset, OnFinished onFinished) {
        super(c);
        this.asset = asset;
        this.onFinished = onFinished;
        setOpaque(true);
        setAlpha(0f);
        setSurfaceTextureListener(this);
    }

    private void finishOnce() {
        if (done) {
            return;
        }
        done = true;
        if (onFinished != null) {
            onFinished.run();
        }
    }

    @Override
    public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) {
        release();
        try {
            final MediaPlayer m = new MediaPlayer();
            mp = m;
            try (AssetFileDescriptor fd = getContext().getAssets().openFd(asset)) {
                m.setDataSource(fd.getFileDescriptor(), fd.getStartOffset(), fd.getLength());
            }
            m.setSurface(new Surface(st));
            m.setVolume(1f, 1f);
            m.setLooping(false);
            m.setOnVideoSizeChangedListener(new MediaPlayer.OnVideoSizeChangedListener() {
                @Override
                public void onVideoSizeChanged(MediaPlayer p, int w2, int h2) {
                    vw = w2;
                    vh = h2;
                    fit();
                }
            });
            m.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer p) {
                    if (mp != p) {
                        return;
                    }
                    p.start();
                    fit();
                    animate().alpha(1f).setDuration(400).start();
                }
            });
            m.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer p) {
                    finishOnce();
                }
            });
            m.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer p, int what, int extra) {
                    finishOnce(); // video gagal: jangan sampai macet, langsung lanjut
                    return true;
                }
            });
            m.prepareAsync();
        } catch (Exception e) {
            finishOnce();
            release();
        }
    }

    @Override
    public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) {
        fit();
    }

    @Override
    public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
        release();
        return true;
    }

    @Override
    public void onSurfaceTextureUpdated(SurfaceTexture st) {
        // tidak dipakai
    }

    /** Memperbesar gambar supaya menutup seluruh kotak tanpa gepeng. */
    private void fit() {
        int w = getWidth();
        int h = getHeight();
        if (w == 0 || h == 0 || vw == 0 || vh == 0) {
            return;
        }
        float view = (float) w / h;
        float vid = (float) vw / vh;
        float sx = 1f;
        float sy = 1f;
        if (vid < view) {
            sy = view / vid;
        } else {
            sx = vid / view;
        }
        Matrix m = new Matrix();
        m.setScale(sx, sy, w / 2f, h / 2f);
        setTransform(m);
    }

    private void release() {
        MediaPlayer m = mp;
        mp = null;
        if (m != null) {
            try {
                m.release();
            } catch (Exception ignored) {
                // sudah dilepas
            }
        }
    }
}
