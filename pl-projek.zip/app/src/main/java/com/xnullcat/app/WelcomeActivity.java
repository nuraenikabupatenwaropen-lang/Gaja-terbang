package com.xnullcat.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;

/** Layar transisi: video welcome diputar sekali layar penuh setelah login Gmail, lalu lanjut ke dashboard utama. */
public class WelcomeActivity extends Activity {
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private boolean moved;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Window w = getWindow();
        w.setStatusBarColor(0xFF000000);
        w.setNavigationBarColor(0xFF000000);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        root.addView(new OnceVideo(this, "welcome.mp4", this::goNext), new FrameLayout.LayoutParams(MATCH, MATCH));
        setContentView(root);
    }

    private void goNext() {
        if (moved) {
            return;
        }
        moved = true;
        runOnUiThread(() -> {
            startActivity(new Intent(WelcomeActivity.this, MainActivity.class));
            finish();
        });
    }

    @Override
    public void onBackPressed() {
        // video welcome tidak bisa diskip/mundur, biar dilihat sampai habis
    }
}
