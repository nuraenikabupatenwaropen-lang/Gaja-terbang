package com.xnullcat.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;

/** Layar pembuka: video intro singkat, lalu otomatis lanjut ke dashboard utama PL Projek (tanpa login Gmail). */
public class SplashActivity extends Activity {
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private boolean moved;
    private final Handler h = new Handler();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Window w = getWindow();
        w.setStatusBarColor(0xFF000000);
        w.setNavigationBarColor(0xFF000000);
        w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        root.addView(new LoopVideo(this, "intro.mp4"), new FrameLayout.LayoutParams(MATCH, MATCH));
        setContentView(root);

        h.postDelayed(this::goNext, 2200);
    }

    private void goNext() {
        if (moved) {
            return;
        }
        moved = true;
        startActivity(new Intent(SplashActivity.this, WelcomeActivity.class));
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        h.removeCallbacksAndMessages(null);
    }
}
