package com.xnullcat.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Layar pembuka: video intro (dengan suara), lalu login pakai Gmail sebelum masuk ke dashboard utama PL Projek. */
public class SplashActivity extends Activity {
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Window w = getWindow();
        w.setStatusBarColor(Ui.BG);
        w.setNavigationBarColor(Ui.BG);
        w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Ui.BG);
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_VERTICAL);
        col.setPadding(dp(20), dp(28), dp(20), dp(28));

        // video intro, bingkai hitam tebal ala neobrutalism (sama seperti banner di dashboard)
        FrameLayout shell = new FrameLayout(this);
        shell.setBackground(Ui.box(this, Ui.SURFACE, 18, Ui.INK, 3.5f));
        shell.setPadding(dp(5), dp(5), dp(5), dp(5));
        Ui.clipRound(shell, dp(18));
        Ui.AspectFrame video = new Ui.AspectFrame(this, 1.78f);
        video.setBackgroundColor(0xFF20242C);
        Ui.clipRound(video, dp(13));
        video.addView(new LoopVideo(this, "intro.mp4"), new FrameLayout.LayoutParams(MATCH, MATCH));
        shell.addView(video, new FrameLayout.LayoutParams(MATCH, WRAP));
        col.addView(shell, lp(MATCH, WRAP, 0, 0, 0, 26));

        // judul
        TextView title = Ui.text(this, "Masuk ke PL Projek", 19, Ui.INK, true, false);
        title.setGravity(Gravity.CENTER);
        col.addView(title, lp(MATCH, WRAP, 0, 0, 0, 6));
        TextView sub = Ui.text(this, "Masukkan Gmail kamu untuk melanjutkan ke dashboard.", 12.5f, Ui.SOFT, false, true);
        sub.setGravity(Gravity.CENTER);
        sub.setLineSpacing(0, 1.2f);
        col.addView(sub, lp(MATCH, WRAP, 10, 0, 10, 20));

        // kartu login
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(Ui.box(this, Ui.SURFACE, 18, Ui.INK, 2.5f));

        final EditText email = new EditText(this);
        email.setHint("nama@gmail.com");
        email.setHintTextColor(Ui.SOFT);
        email.setTextColor(Ui.INK);
        email.setTextSize(15);
        email.setSingleLine(true);
        email.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        email.setBackground(Ui.box(this, Ui.BG, 12, Ui.EDGE, 1.5f));
        email.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.addView(email, lp(MATCH, WRAP, 0, 0, 0, 14));

        TextView masuk = Ui.text(this, "Masuk", 15, Color.WHITE, true, false);
        masuk.setGravity(Gravity.CENTER);
        masuk.setPadding(0, dp(14), 0, dp(14));
        masuk.setBackground(Ui.box(this, Ui.GREEN, 14, Ui.INK, 2.5f));
        masuk.setClickable(true);
        Ui.pressable(masuk);
        masuk.setOnClickListener(v -> doLogin(email));
        View masukWrap = Ui.brutal(this, masuk, 14, 4);
        card.addView(masukWrap, new LinearLayout.LayoutParams(MATCH, WRAP));

        View cardWrap = Ui.brutal(this, card, 18, 5);
        col.addView(cardWrap, lp(MATCH, WRAP, 0, 0, 0, 0));

        sv.addView(col, new FrameLayout.LayoutParams(MATCH, WRAP));
        root.addView(sv, new FrameLayout.LayoutParams(MATCH, MATCH));
        setContentView(root);
    }

    private void doLogin(EditText email) {
        String em = email.getText().toString().trim();
        if (em.isEmpty() || !em.contains("@") || !em.contains(".")) {
            Toast.makeText(this, "Masukkan Gmail yang benar dulu.", Toast.LENGTH_SHORT).show();
            return;
        }
        getSharedPreferences("pl", MODE_PRIVATE).edit().putString("email", em).apply();
        startActivity(new Intent(this, WelcomeActivity.class));
        finish();
    }

    private int dp(float v) {
        return Ui.dp(this, v);
    }

    private LinearLayout.LayoutParams lp(int w, int h, float l, float t, float r, float b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }
}
