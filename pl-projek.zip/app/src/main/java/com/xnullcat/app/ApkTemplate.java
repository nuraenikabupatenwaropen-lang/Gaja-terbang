package com.xnullcat.app;

import android.content.Context;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Menyiapkan app.zip (proyek Jaga Anak) yang sudah dikustom dari template di assets/jagaanak-template.zip:
 * nama aplikasi (AndroidManifest), icon (drawable/ic_launcher), dan kode+Gmail pemilik (OwnerConfig.java).
 * Template-nya adalah salinan apa adanya dari proyek jagaanak/ saat ini, jadi kalau proyek jagaanak
 * berubah, assets/jagaanak-template.zip di xnullcat ini juga harus dibuat ulang supaya tetap sama.
 */
final class ApkTemplate {
    private static final String TEMPLATE_ASSET = "jagaanak-template.zip";

    private ApkTemplate() {
    }

    /** iconPng boleh null (pakai icon bawaan). Hasilnya siap langsung di-base64 lalu diunggah ke GitHub. */
    static byte[] build(Context ctx, String apkName, String ownerGmail, String code, byte[] iconPng) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ZipOutputStream zos = new ZipOutputStream(out);
        InputStream is = ctx.getAssets().open(TEMPLATE_ASSET);
        ZipInputStream zis = new ZipInputStream(is);
        try {
            ZipEntry e;
            while ((e = zis.getNextEntry()) != null) {
                String name = e.getName();
                if (iconPng != null && name.endsWith("drawable/ic_launcher.xml")) {
                    // diganti PNG kustom di bawah, jadi vector bawaan dilewati
                    continue;
                }
                byte[] data = readAll(zis);
                if (name.endsWith("AndroidManifest.xml")) {
                    String xml = new String(data, StandardCharsets.UTF_8);
                    xml = xml.replace("android:label=\"Jaga Anak\"", "android:label=\"" + xmlEscape(apkName) + "\"");
                    data = xml.getBytes(StandardCharsets.UTF_8);
                } else if (name.endsWith("OwnerConfig.java")) {
                    String src = new String(data, StandardCharsets.UTF_8);
                    src = src.replace("__OWNER_GMAIL__", javaEscape(ownerGmail)).replace("__CODE__", javaEscape(code));
                    data = src.getBytes(StandardCharsets.UTF_8);
                }
                zos.putNextEntry(new ZipEntry(name));
                zos.write(data);
                zos.closeEntry();
            }
            if (iconPng != null) {
                zos.putNextEntry(new ZipEntry("app/src/main/res/drawable/ic_launcher.png"));
                zos.write(iconPng);
                zos.closeEntry();
            }
        } finally {
            zis.close();
            zos.close();
        }
        return out.toByteArray();
    }

    private static byte[] readAll(InputStream is) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) > 0) {
            bos.write(buf, 0, n);
        }
        return bos.toByteArray();
    }

    private static String xmlEscape(String s) {
        return s.replace("&", "&amp;").replace("\"", "&quot;").replace("<", "&lt;").replace(">", "&gt;");
    }

    private static String javaEscape(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
