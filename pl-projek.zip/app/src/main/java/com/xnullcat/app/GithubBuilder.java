package com.xnullcat.app;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Membuild APK Jaga Anak lewat GitHub Actions, langsung dari dalam PL Projek.
 * Alurnya sama persis dengan "buat-apk.html" (unggah workflow + app.zip lewat Contents API, jalankan
 * workflow_dispatch, tunggu selesai, ambil link APK dari Release), tapi di sini cuma satu APK (Jaga Anak)
 * dan dipanggil lewat Java (HttpURLConnection) bukan lewat browser.
 */
final class GithubBuilder {
    interface Progress {
        /** state: "run", "ok", atau "bad". Dipanggil di main thread. */
        void step(String key, String state, String note);

        void runLink(String url);

        /** apkUrl null kalau APK belum ketemu di Release (build tetap sukses, lihat relUrl). */
        void done(String apkUrl, String apkName, long size, String relUrl);

        void failed(String message);
    }

    private static final String WF_PATH = ".github/workflows/build-jaga-anak.yml";
    private static final String WF_FILE = "build-jaga-anak.yml";
    private static final String WORKFLOW_YAML =
            "name: Build Jaga Anak\n" +
            "on:\n" +
            "  workflow_dispatch:\n" +
            "permissions:\n" +
            "  contents: write\n" +
            "jobs:\n" +
            "  build:\n" +
            "    runs-on: ubuntu-latest\n" +
            "    steps:\n" +
            "      - uses: actions/checkout@v4\n" +
            "      - name: Ekstrak ZIP\n" +
            "        run: |\n" +
            "          mkdir -p work\n" +
            "          unzip -q app.zip -d work\n" +
            "          SETTINGS=$(find work -maxdepth 3 -name settings.gradle | head -n 1)\n" +
            "          if [ -z \"$SETTINGS\" ]; then echo \"settings.gradle tidak ditemukan di ZIP\"; exit 1; fi\n" +
            "          echo \"ROOT=$(dirname \"$SETTINGS\")\" >> \"$GITHUB_ENV\"\n" +
            "      - uses: actions/setup-java@v4\n" +
            "        with:\n" +
            "          distribution: temurin\n" +
            "          java-version: '17'\n" +
            "      - name: Siapkan Android SDK\n" +
            "        run: |\n" +
            "          yes | \"$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager\" --licenses > /dev/null || true\n" +
            "          \"$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager\" \"platforms;android-34\" \"build-tools;34.0.0\" > /dev/null || true\n" +
            "      - uses: gradle/actions/setup-gradle@v4\n" +
            "        with:\n" +
            "          gradle-version: '8.9'\n" +
            "      - name: Build APK\n" +
            "        run: cd \"$ROOT\" && gradle assembleDebug --no-daemon --stacktrace\n" +
            "      - name: Ambil APK\n" +
            "        run: cp \"$ROOT/app/build/outputs/apk/debug/app-debug.apk\" app.apk\n" +
            "      - name: Buat release\n" +
            "        env:\n" +
            "          GH_TOKEN: ${{ github.token }}\n" +
            "        run: gh release create \"jaga-${{ github.run_number }}\" app.apk --repo \"${{ github.repository }}\" --title \"Jaga Anak build ${{ github.run_number }}\" --notes \"APK Jaga Anak dari fitur Generate APK\"\n";

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final String owner;
    private final String repo;
    private final String token;
    private final Progress progress;
    private String branch = "main";

    GithubBuilder(String owner, String repo, String token, Progress progress) {
        this.owner = owner;
        this.repo = repo;
        this.token = token;
        this.progress = progress;
    }

    /** zipB64 = isi app.zip (sudah dikustom) dalam base64. Boleh dipanggil dari thread mana pun. */
    void run(final String zipB64) {
        try {
            io.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        doRun(zipB64);
                    } catch (final Exception e) {
                        post(new Runnable() {
                            @Override
                            public void run() {
                                progress.failed(e.getMessage() != null ? e.getMessage() : String.valueOf(e));
                            }
                        });
                    } finally {
                        io.shutdown();
                    }
                }
            });
        } catch (Exception e) {
            progress.failed(e.getMessage() != null ? e.getMessage() : String.valueOf(e));
        }
    }

    private void post(Runnable r) {
        main.post(r);
    }

    private void step(final String key, final String state, final String note) {
        post(new Runnable() {
            @Override
            public void run() {
                progress.step(key, state, note);
            }
        });
    }

    private void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
            // lanjut saja
        }
    }

    private static String enc(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (Exception e) {
            return s;
        }
    }

    private static String encPath(String path) {
        String[] parts = path.split("/");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.length; i++) {
            if (i > 0) {
                sb.append('/');
            }
            sb.append(enc(parts[i]));
        }
        return sb.toString();
    }

    private static String b64(String s) {
        return android.util.Base64.encodeToString(s.getBytes(StandardCharsets.UTF_8), android.util.Base64.NO_WRAP);
    }

    private static String readAll(InputStream is) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) > 0) {
            bos.write(buf, 0, n);
        }
        return new String(bos.toByteArray(), StandardCharsets.UTF_8);
    }

    private String repoPath(String rest) {
        return "/repos/" + enc(owner) + "/" + enc(repo) + rest;
    }

    private static final class GhResp {
        int status;
        JSONObject json;
        String text;
    }

    private GhResp gh(String method, String path, JSONObject body) throws IOException {
        URL url = new URL("https://api.github.com" + path);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        try {
            c.setRequestMethod(method);
            c.setRequestProperty("Accept", "application/vnd.github+json");
            c.setRequestProperty("Authorization", "Bearer " + token);
            c.setConnectTimeout(20000);
            c.setReadTimeout(60000);
            c.setInstanceFollowRedirects(true);
            if (body != null) {
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json");
                byte[] b = body.toString().getBytes(StandardCharsets.UTF_8);
                c.setFixedLengthStreamingMode(b.length);
                OutputStream os = c.getOutputStream();
                os.write(b);
                os.close();
            }
            int status = c.getResponseCode();
            InputStream is = status >= 200 && status < 400 ? c.getInputStream() : c.getErrorStream();
            String text = is == null ? "" : readAll(is);
            GhResp r = new GhResp();
            r.status = status;
            r.text = text;
            try {
                r.json = text != null && text.length() > 0 ? new JSONObject(text) : null;
            } catch (Exception ignored) {
                r.json = null;
            }
            return r;
        } finally {
            c.disconnect();
        }
    }

    private Exception apiError(GhResp r, String what) {
        String m = r != null && r.json != null ? r.json.optString("message", "") : "";
        if (m == null || m.isEmpty()) {
            m = "HTTP " + (r != null ? r.status : 0);
        }
        if (r != null && r.status == 401) {
            m = "Token ditolak atau sudah kedaluwarsa.";
        } else if (r != null && r.status == 403) {
            m = "Token tidak punya izin untuk ini (" + m + "). Pastikan izin repo dan workflow aktif.";
        } else if (r != null && r.status == 404) {
            m = "Tidak ditemukan atau token tidak punya akses (" + m + ").";
        }
        return new Exception(what + ": " + m);
    }

    private void putFile(String path, String base64Content, String message) throws Exception {
        String p = repoPath("/contents/" + encPath(path));
        for (int i = 0; i < 4; i++) {
            GhResp cur = gh("GET", p + "?ref=" + enc(branch), null);
            JSONObject body = new JSONObject();
            body.put("message", message);
            body.put("content", base64Content);
            body.put("branch", branch);
            if (cur.status == 200 && cur.json != null && cur.json.has("sha")) {
                body.put("sha", cur.json.optString("sha"));
            }
            GhResp r = gh("PUT", p, body);
            if (r.status >= 200 && r.status < 300) {
                return;
            }
            String msg = r.json != null ? r.json.optString("message", "") : "";
            boolean shaRace = r.status == 409 || (r.status == 422 && msg.toLowerCase(Locale.US).contains("sha"));
            if (shaRace) {
                sleep(1500L * (i + 1));
                continue;
            }
            throw apiError(r, "Gagal mengunggah " + path);
        }
        throw new Exception("Gagal mengunggah " + path + " setelah beberapa kali coba.");
    }

    private long latestRunId() throws Exception {
        GhResp r = gh("GET", repoPath("/actions/workflows/" + WF_FILE + "/runs?event=workflow_dispatch&per_page=5"), null);
        long max = 0;
        if (r.status == 200 && r.json != null) {
            JSONArray runs = r.json.optJSONArray("workflow_runs");
            if (runs != null) {
                for (int i = 0; i < runs.length(); i++) {
                    long id = runs.getJSONObject(i).optLong("id");
                    if (id > max) {
                        max = id;
                    }
                }
            }
        }
        return max;
    }

    private void dispatch() throws Exception {
        GhResp last = null;
        for (int i = 0; i < 14; i++) {
            JSONObject body = new JSONObject();
            body.put("ref", branch);
            GhResp r = gh("POST", repoPath("/actions/workflows/" + WF_FILE + "/dispatches"), body);
            if (r.status == 204 || (r.status >= 200 && r.status < 300)) {
                return;
            }
            last = r;
            if (r.status == 404 || r.status == 422) {
                sleep(3000);
                continue;
            }
            break;
        }
        throw apiError(last, "Gagal menjalankan build");
    }

    private JSONObject findRun(long prevMax) throws Exception {
        for (int i = 0; i < 40; i++) {
            GhResp r = gh("GET", repoPath("/actions/workflows/" + WF_FILE + "/runs?event=workflow_dispatch&per_page=5"), null);
            if (r.status == 200 && r.json != null) {
                JSONArray runs = r.json.optJSONArray("workflow_runs");
                JSONObject best = null;
                long bestId = -1;
                if (runs != null) {
                    for (int j = 0; j < runs.length(); j++) {
                        JSONObject x = runs.getJSONObject(j);
                        long id = x.optLong("id");
                        if (id > prevMax && id > bestId) {
                            bestId = id;
                            best = x;
                        }
                    }
                }
                if (best != null) {
                    return best;
                }
            }
            sleep(3000);
        }
        throw new Exception("Build tidak muncul di GitHub. Buka tab Actions di repo untuk mengeceknya.");
    }

    private static String fmtElapsed(long ms) {
        long s = Math.round(ms / 1000.0);
        long m = s / 60;
        return m + "m " + (s % 60) + "d";
    }

    private JSONObject waitRun(JSONObject run) throws Exception {
        long id = run.optLong("id");
        long t0 = System.currentTimeMillis();
        JSONObject cur = run;
        while (true) {
            GhResp rr = gh("GET", repoPath("/actions/runs/" + id), null);
            if (rr.status == 200 && rr.json != null) {
                cur = rr.json;
            }
            String status = cur.optString("status", "");
            if ("completed".equals(status)) {
                return cur;
            }
            long elapsed = System.currentTimeMillis() - t0;
            step("wait", "run", ("queued".equals(status) ? "Antre di GitHub" : "Sedang membuild") + ", " + fmtElapsed(elapsed));
            if (elapsed > 40 * 60 * 1000L) {
                throw new Exception("Build terlalu lama (lebih dari 40 menit). Cek tab Actions di repo.");
            }
            sleep(6000);
        }
    }

    private JSONObject getRelease(long runNumber) throws Exception {
        for (int i = 0; i < 6; i++) {
            GhResp r = gh("GET", repoPath("/releases/tags/jaga-" + runNumber), null);
            if (r.status == 200 && r.json != null) {
                return r.json;
            }
            sleep(2000);
        }
        return null;
    }

    private void doRun(String zipB64) throws Exception {
        step("auth", "run", null);
        GhResp me = gh("GET", "/user", null);
        if (me.status != 200 || me.json == null) {
            throw apiError(me, "Token tidak bisa dipakai");
        }
        String login = me.json.optString("login", "");
        step("auth", "ok", "Masuk sebagai " + login);

        step("repo", "run", null);
        GhResp rr = gh("GET", repoPath(""), null);
        JSONObject info;
        if (rr.status == 200) {
            info = rr.json;
            step("repo", "ok", "Memakai repo " + info.optString("full_name") + (info.optBoolean("private") ? " (privat)" : " (publik)"));
        } else if (rr.status == 404) {
            if (!owner.equalsIgnoreCase(login)) {
                throw new Exception("Repo " + owner + "/" + repo + " tidak ditemukan atau tidak bisa diakses token ini.");
            }
            JSONObject cr = new JSONObject();
            cr.put("name", repo);
            cr.put("private", true);
            cr.put("auto_init", true);
            cr.put("description", "APK Jaga Anak (Generate APK dari PL Projek)");
            GhResp crr = gh("POST", "/user/repos", cr);
            if (crr.status < 200 || crr.status >= 300) {
                throw apiError(crr, "Gagal membuat repo");
            }
            info = crr.json;
            sleep(2500);
            step("repo", "ok", "Repo baru dibuat: " + info.optString("full_name"));
        } else {
            throw apiError(rr, "Gagal membuka repo");
        }
        if (info.optBoolean("archived")) {
            throw new Exception("Repo ini diarsipkan, tidak bisa diubah.");
        }
        JSONObject perms = info.optJSONObject("permissions");
        if (perms != null && perms.has("push") && !perms.optBoolean("push", true)) {
            throw new Exception("Token tidak punya izin menulis ke repo ini.");
        }
        branch = info.optString("default_branch", "main");
        if (branch == null || branch.isEmpty()) {
            branch = "main";
        }

        step("wf", "run", null);
        putFile(WF_PATH, b64(WORKFLOW_YAML), "Tambah alur build Jaga Anak");
        step("wf", "ok", null);

        step("zip", "run", null);
        putFile("app.zip", zipB64, "Unggah app.zip");
        step("zip", "ok", null);

        step("run", "run", null);
        long prev = latestRunId();
        dispatch();
        final JSONObject started = findRun(prev);
        final String startedUrl = started.optString("html_url");
        post(new Runnable() {
            @Override
            public void run() {
                progress.runLink(startedUrl);
            }
        });
        step("run", "ok", "Build #" + started.optInt("run_number") + " dimulai");

        step("wait", "run", "Antre di GitHub");
        JSONObject done = waitRun(started);
        boolean ok = "success".equals(done.optString("conclusion"));
        final String doneUrl = done.optString("html_url");
        post(new Runnable() {
            @Override
            public void run() {
                progress.runLink(doneUrl);
            }
        });
        if (!ok) {
            throw new Exception("Build gagal. Tekan \"Lihat proses di GitHub\" untuk membaca lognya.");
        }
        step("wait", "ok", "Build selesai");

        step("done", "run", null);
        JSONObject rel = getRelease(started.optLong("run_number"));
        if (rel != null) {
            JSONArray assets = rel.optJSONArray("assets");
            if (assets != null) {
                for (int i = 0; i < assets.length(); i++) {
                    JSONObject a = assets.getJSONObject(i);
                    String name = a.optString("name", "");
                    if (name.endsWith(".apk")) {
                        final String url = a.optString("browser_download_url");
                        final String nm = name;
                        final long size = a.optLong("size");
                        final String relUrl = rel.optString("html_url");
                        step("done", "ok", "APK siap");
                        post(new Runnable() {
                            @Override
                            public void run() {
                                progress.done(url, nm, size, relUrl);
                            }
                        });
                        return;
                    }
                }
            }
        }
        final String fallbackUrl = done.optString("html_url");
        step("done", "ok", "Build selesai, APK belum muncul di Release");
        post(new Runnable() {
            @Override
            public void run() {
                progress.done(null, null, 0, fallbackUrl);
            }
        });
    }
}
