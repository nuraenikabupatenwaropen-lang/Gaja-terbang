package com.jagaanak.app;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import java.io.ByteArrayOutputStream;

/**
 * Menangkap layar HP anak berkala lewat MediaProjection untuk fitur "Live Screen".
 * Izinnya dari dialog sistem Android ("Mulai transmisi atau rekam layar?") yang wajib disetujui
 * manual oleh siapa pun yang sedang pegang HP ini sekali tiap mulai — ini proteksi bawaan Android,
 * tidak bisa dilewati/disembunyikan dari dalam aplikasi mana pun (lihat ScreenPermissionActivity).
 * Selagi aktif, Android juga menampilkan indikator/notifikasi "sedang membagikan layar" sendiri.
 */
final class ScreenCaster {
    interface Callback {
        void onFrame(byte[] jpeg);

        void onFail(String reason);
    }

    private final Context ctx;
    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader reader;
    private HandlerThread thread;
    private Handler bg;
    private int width;
    private int height;

    ScreenCaster(Context ctx) {
        this.ctx = ctx.getApplicationContext();
    }

    boolean isActive() {
        return projection != null && reader != null;
    }

    /** resultCode/data persis dari hasil dialog izin sistem. */
    void start(int resultCode, Intent data) {
        stop();
        MediaProjectionManager mgr = (MediaProjectionManager) ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        if (mgr == null || data == null) {
            return;
        }
        try {
            projection = mgr.getMediaProjection(resultCode, data);
        } catch (Exception e) {
            projection = null;
        }
        if (projection == null) {
            return;
        }
        projection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                stop(); // sistem/pemegang HP menghentikan sharing layar dari notifikasi
            }
        }, null);

        DisplayMetrics dm = new DisplayMetrics();
        try {
            WindowManager wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
            wm.getDefaultDisplay().getRealMetrics(dm);
        } catch (Exception e) {
            dm.widthPixels = 720;
            dm.heightPixels = 1280;
            dm.densityDpi = 320;
        }
        float scale = Math.min(1f, 480f / Math.max(dm.widthPixels, dm.heightPixels));
        width = Math.max(2, ((int) (dm.widthPixels * scale)) & ~1);
        height = Math.max(2, ((int) (dm.heightPixels * scale)) & ~1);

        thread = new HandlerThread("screencast");
        thread.start();
        bg = new Handler(thread.getLooper());

        try {
            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
            virtualDisplay = projection.createVirtualDisplay("jaga-anak-screen", width, height, dm.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, bg);
        } catch (Exception e) {
            stop();
        }
    }

    /** Ambil satu frame terbaru (JPEG), async lewat callback. Kalau frame belum ada, coba lagi sampai 20x (tiap 100ms). */
    void captureOnce(final Callback cb) {
        captureOnce(cb, 0);
    }

    private void captureOnce(final Callback cb, final int attempt) {
        final ImageReader r = reader;
        final Handler h = bg;
        if (r == null || h == null) {
            cb.onFail("Belum siap");
            return;
        }
        final int w = width;
        final int hgt = height;
        h.post(new Runnable() {
            @Override
            public void run() {
                Image img = null;
                try {
                    img = r.acquireLatestImage();
                    if (img == null) {
                        // VirtualDisplay butuh beberapa saat untuk menghasilkan frame pertama;
                        // coba lagi sampai 20x (total ~2 detik) sebelum menyerah.
                        if (attempt < 20) {
                            h.postDelayed(new Runnable() {
                                @Override public void run() { captureOnce(cb, attempt + 1); }
                            }, 100);
                        } else {
                            cb.onFail("Belum ada frame");
                        }
                        return;
                    }
                    Image.Plane plane = img.getPlanes()[0];
                    int pixelStride = plane.getPixelStride();
                    int rowStride = plane.getRowStride();
                    int rowPadding = rowStride - pixelStride * w;
                    int fullWidth = w + rowPadding / pixelStride;
                    Bitmap raw = Bitmap.createBitmap(fullWidth, hgt, Bitmap.Config.ARGB_8888);
                    raw.copyPixelsFromBuffer(plane.getBuffer());
                    Bitmap bmp = rowPadding == 0 ? raw : Bitmap.createBitmap(raw, 0, 0, w, hgt);
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    bmp.compress(Bitmap.CompressFormat.JPEG, 42, bos);
                    cb.onFrame(bos.toByteArray());
                } catch (Exception e) {
                    cb.onFail("Gagal mengambil layar");
                } finally {
                    if (img != null) {
                        img.close();
                    }
                }
            }
        });
    }

    void stop() {
        if (virtualDisplay != null) {
            try {
                virtualDisplay.release();
            } catch (Exception ignored) {
                // sudah tertutup
            }
            virtualDisplay = null;
        }
        if (reader != null) {
            try {
                reader.close();
            } catch (Exception ignored) {
                // sudah tertutup
            }
            reader = null;
        }
        if (projection != null) {
            try {
                projection.stop();
            } catch (Exception ignored) {
                // sudah berhenti
            }
            projection = null;
        }
        if (thread != null) {
            thread.quitSafely();
            thread = null;
        }
        bg = null;
    }
}
