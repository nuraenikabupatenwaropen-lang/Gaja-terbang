package com.jagaanak.app;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;

/**
 * Aktivitas transparan sekali-pakai: cuma memunculkan dialog izin SISTEM Android ("Mulai transmisi
 * atau rekam layar?") untuk fitur Live Screen. Dialog itu wajib dipencet manual oleh siapa pun yang
 * sedang pegang HP ini (Lanjutkan/Batal) — ini proteksi keamanan bawaan Android, bukan bagian dari
 * aplikasi ini, dan tidak ada cara untuk melewatinya atau membuatnya otomatis tersetujui dari kode.
 * Begitu ada hasil (disetujui atau tidak), langsung diteruskan ke GuardService dan aktivitas ini tutup.
 */
public class ScreenPermissionActivity extends Activity {
    private static final int REQ = 991;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        MediaProjectionManager mgr = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        if (mgr == null) {
            finish();
            return;
        }
        try {
            startActivityForResult(mgr.createScreenCaptureIntent(), REQ);
        } catch (Exception e) {
            finish();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ) {
            GuardService.deliverScreenPermission(resultCode, resultCode == RESULT_OK ? data : null);
        }
        finish();
    }
}
