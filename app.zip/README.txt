Jaga Anak (HP anak)
Proyek Android (Gradle). Dibuild otomatis lewat buat-apk.html, atau buka folder ini di Android Studio.
Pasangannya: PL Projek (HP orang tua).
Kontrol jarak jauh lewat Firebase Realtime Database (alamat di Rtdb.java). Kode pairing ada di layar aplikasi.
