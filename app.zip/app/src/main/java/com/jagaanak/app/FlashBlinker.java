package com.jagaanak.app;

import android.content.Context;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.os.Handler;
import android.os.Looper;

/** Membuat senter HP berkedip-kedip. Tidak memerlukan izin kamera (torch mode saja). */
final class FlashBlinker {
    private final CameraManager cm;
    private final String id;
    private final Handler h = new Handler(Looper.getMainLooper());
    private volatile boolean on;
    private boolean state;

    FlashBlinker(Context c) {
        CameraManager found = null;
        String camId = null;
        try {
            found = (CameraManager) c.getSystemService(Context.CAMERA_SERVICE);
            if (found != null) {
                for (String s : found.getCameraIdList()) {
                    Boolean has = found.getCameraCharacteristics(s).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                    if (Boolean.TRUE.equals(has)) {
                        camId = s;
                        break;
                    }
                }
            }
        } catch (CameraAccessException | RuntimeException ignored) {
            // HP ini tidak punya senter yang bisa dikontrol, cukup diam
        }
        cm = found;
        id = camId;
    }

    void start() {
        if (cm == null || id == null || on) {
            return;
        }
        on = true;
        h.post(tick);
    }

    void stop() {
        on = false;
        h.removeCallbacks(tick);
        setTorch(false);
    }

    /** Menyalakan atau mematikan senter tetap (tidak berkedip), untuk Lock Screen. */
    void torch(boolean v) {
        on = false;
        h.removeCallbacks(tick);
        setTorch(v);
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!on) {
                return;
            }
            state = !state;
            setTorch(state);
            h.postDelayed(this, 160);
        }
    };

    private void setTorch(boolean v) {
        try {
            cm.setTorchMode(id, v);
        } catch (Exception ignored) {
            // senter sedang dipakai kamera lain, atau HP menolak
        }
    }
}
