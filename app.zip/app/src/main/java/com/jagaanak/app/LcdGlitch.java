package com.jagaanak.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Handler;
import android.os.Looper;
import android.view.View;

import java.util.Random;

/** Efek layar seperti LCD rusak: garis-garis warna (hijau, merah, biru, dll) berkedip acak. Dipakai fitur Prank LCD. */
final class LcdGlitch extends View {
    private final Paint p = new Paint();
    private final Random rnd = new Random();
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean running;
    private static final int[] COLORS = {
            0xFFFF2D55, 0xFF00FF66, 0xFF2979FF, 0xFFFFEE00, 0xFF00E5FF, 0xFFFF00E5, Color.WHITE, Color.BLACK
    };

    LcdGlitch(Context c) {
        super(c);
        setBackgroundColor(Color.BLACK);
    }

    void start() {
        if (running) {
            return;
        }
        running = true;
        h.post(tick);
    }

    void stop() {
        running = false;
        h.removeCallbacks(tick);
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running) {
                return;
            }
            invalidate();
            h.postDelayed(this, 70 + rnd.nextInt(90));
        }
    };

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth();
        int hh = getHeight();
        if (w <= 0 || hh <= 0) {
            return;
        }
        c.drawColor(Color.BLACK);
        int y = 0;
        while (y < hh) {
            int bar = 4 + rnd.nextInt(46);
            p.setColor(COLORS[rnd.nextInt(COLORS.length)]);
            if (rnd.nextInt(5) == 0) {
                int shift = rnd.nextInt(Math.max(1, w / 3)) - w / 6;
                c.drawRect(shift, y, w + shift, y + bar, p);
            } else {
                c.drawRect(0, y, w, y + bar, p);
            }
            y += bar;
        }
        int vlines = rnd.nextInt(10);
        for (int i = 0; i < vlines; i++) {
            p.setColor(COLORS[rnd.nextInt(COLORS.length)]);
            int x = rnd.nextInt(Math.max(1, w));
            int lw = 1 + rnd.nextInt(5);
            c.drawRect(x, 0, x + lw, hh, p);
        }
    }
}
