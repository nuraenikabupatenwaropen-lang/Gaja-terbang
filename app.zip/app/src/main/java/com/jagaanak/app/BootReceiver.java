package com.jagaanak.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Menyalakan lagi penjagaan setelah HP restart, kalau sebelumnya aktif. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())) {
            return;
        }
        if (!c.getSharedPreferences("jaga", Context.MODE_PRIVATE).getBoolean("auto", false)) {
            return;
        }
        try {
            c.startForegroundService(new Intent(c, GuardService.class));
        } catch (RuntimeException ignored) {
            // Android menolak; aplikasi bisa dibuka manual
        }
    }
}
