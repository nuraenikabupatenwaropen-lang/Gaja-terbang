package com.jagaanak.app;

/**
 * Diisi otomatis oleh PL Projek lewat fitur "Generate APK" (lihat GithubBuilder/ApkTemplate di proyek xnullcat).
 * Kalau APK ini dipasang langsung dari template tanpa lewat Generate APK, kedua nilai ini kosong
 * dan Pairing.java otomatis jatuh ke kode acak lama (lihat Pairing.java).
 */
final class OwnerConfig {
    /** Gmail orang tua yang membuild APK ini. Hanya catatan, tidak dipakai untuk logika. */
    static final String OWNER_GMAIL = "mhmmdamnnn13@gmail.com";
    /** Kode Firebase (16 huruf/angka) yang sudah ditanam saat build, supaya tidak perlu pairing manual lagi. */
    static final String CODE = "HKVMWJDTSJPACCVU";

    private OwnerConfig() {
    }
}
