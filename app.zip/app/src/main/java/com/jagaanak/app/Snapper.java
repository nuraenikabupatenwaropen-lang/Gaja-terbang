package com.jagaanak.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Size;

import java.nio.ByteBuffer;
import java.util.Comparator;

/**
 * Mengambil satu foto JPEG lewat kamera (depan atau belakang, dipilih tiap panggilan) dan
 * mengembalikan bytenya lewat callback. Tidak merekam video lewat MediaRecorder: dipakai berulang
 * kali secara cepat (lihat GuardService) untuk memberi efek tampilan kamera "real-time".
 * Kamera dibuka hanya untuk satu jepretan lalu langsung ditutup.
 * Android sendiri menampilkan tanda titik hijau berkedip di status bar selagi kamera terbuka;
 * itu bawaan sistem dan tidak disembunyikan di sini.
 */
final class Snapper {
    interface Callback {
        void onPhoto(byte[] jpeg);

        void onFail(String reason);
    }

    private final Context ctx;
    private HandlerThread thread;
    private Handler bg;
    private CameraDevice device;
    private CameraCaptureSession session;
    private ImageReader reader;
    private Callback cb;
    private boolean done;
    private String wantFacing;

    Snapper(Context ctx) {
        this.ctx = ctx.getApplicationContext();
    }

    /** facing: "front" atau "back" (atau null/lainnya, dianggap "back"). */
    @SuppressLint("MissingPermission")
    void takePhoto(String facing, final Callback callback) {
        if (ctx.checkSelfPermission(android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            callback.onFail("Izin kamera belum diberikan");
            return;
        }
        this.cb = callback;
        this.done = false;
        this.wantFacing = facing;
        thread = new HandlerThread("snapper");
        thread.start();
        bg = new Handler(thread.getLooper());
        bg.post(new Runnable() {
            @Override
            public void run() {
                openAndShoot();
            }
        });
    }

    private void fail(String reason) {
        if (done) {
            return;
        }
        done = true;
        Callback c = cb;
        closeAll();
        if (c != null) {
            c.onFail(reason);
        }
    }

    private void openAndShoot() {
        CameraManager cm = (CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
        if (cm == null) {
            fail("Tidak ada kamera");
            return;
        }
        try {
            int want = "front".equals(wantFacing)
                    ? CameraCharacteristics.LENS_FACING_FRONT
                    : CameraCharacteristics.LENS_FACING_BACK;
            String id = null;
            String fallback = null;
            Size size = new Size(640, 480);
            for (String s : cm.getCameraIdList()) {
                CameraCharacteristics c = cm.getCameraCharacteristics(s);
                Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                if (fallback == null) {
                    fallback = s;
                }
                if (facing != null && facing == want) {
                    id = s;
                    break;
                }
            }
            if (id == null) {
                id = fallback;
            }
            if (id == null) {
                fail("HP ini tidak punya kamera");
                return;
            }
            CameraCharacteristics chars = cm.getCameraCharacteristics(id);
            StreamConfigurationMap map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (map != null) {
                Size[] sizes = map.getOutputSizes(ImageFormat.JPEG);
                if (sizes != null && sizes.length > 0) {
                    size = pickSize(sizes);
                }
            }
            final String camId = id;
            reader = ImageReader.newInstance(size.getWidth(), size.getHeight(), ImageFormat.JPEG, 1);
            reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                @Override
                public void onImageAvailable(ImageReader r) {
                    try (Image img = r.acquireLatestImage()) {
                        if (img == null) {
                            fail("Gagal mengambil gambar");
                            return;
                        }
                        ByteBuffer buf = img.getPlanes()[0].getBuffer();
                        byte[] bytes = new byte[buf.remaining()];
                        buf.get(bytes);
                        done = true;
                        Callback c = cb;
                        closeAll();
                        if (c != null) {
                            c.onPhoto(bytes);
                        }
                    } catch (Exception e) {
                        fail("Gagal membaca gambar");
                    }
                }
            }, bg);

            cm.openCamera(camId, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(CameraDevice cam) {
                    device = cam;
                    startCapture(cam, chars);
                }

                @Override
                public void onDisconnected(CameraDevice cam) {
                    cam.close();
                    fail("Kamera terputus");
                }

                @Override
                public void onError(CameraDevice cam, int error) {
                    cam.close();
                    fail("Kamera gagal dibuka");
                }
            }, bg);
        } catch (CameraAccessException | RuntimeException e) {
            fail("Tidak bisa mengakses kamera");
        }
    }

    private void startCapture(final CameraDevice cam, final CameraCharacteristics chars) {
        try {
            cam.createCaptureSession(java.util.Collections.singletonList(reader.getSurface()),
                    new CameraCaptureSession.StateCallback() {
                        @Override
                        public void onConfigured(CameraCaptureSession s) {
                            session = s;
                            try {
                                CaptureRequest.Builder b = cam.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
                                b.addTarget(reader.getSurface());
                                b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);
                                b.set(CaptureRequest.JPEG_QUALITY, (byte) 55);
                                Integer rot = chars.get(CameraCharacteristics.SENSOR_ORIENTATION);
                                b.set(CaptureRequest.JPEG_ORIENTATION, rot == null ? 90 : rot);
                                s.capture(b.build(), null, bg);
                            } catch (Exception e) {
                                fail("Gagal memotret");
                            }
                        }

                        @Override
                        public void onConfigureFailed(CameraCaptureSession s) {
                            fail("Kamera gagal disiapkan");
                        }
                    }, bg);
        } catch (Exception e) {
            fail("Gagal menyiapkan kamera");
        }
    }

    private static Size pickSize(Size[] sizes) {
        final long target = 640L * 480L;
        Size best = sizes[0];
        long bestDiff = Long.MAX_VALUE;
        for (Size s : sizes) {
            long area = (long) s.getWidth() * s.getHeight();
            long diff = Math.abs(area - target);
            if (diff < bestDiff) {
                bestDiff = diff;
                best = s;
            }
        }
        return best;
    }

    private void closeAll() {
        try {
            if (session != null) {
                session.close();
            }
        } catch (Exception ignored) {
            // sudah tertutup
        }
        try {
            if (device != null) {
                device.close();
            }
        } catch (Exception ignored) {
            // sudah tertutup
        }
        try {
            if (reader != null) {
                reader.close();
            }
        } catch (Exception ignored) {
            // sudah tertutup
        }
        session = null;
        device = null;
        reader = null;
        if (thread != null) {
            thread.quitSafely();
            thread = null;
        }
        bg = null;
    }
}
