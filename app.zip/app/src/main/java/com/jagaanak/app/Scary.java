package com.jagaanak.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.View;

import java.util.Random;

/**
 * Latar menyeramkan yang bergerak: kabut merah berdenyut, tengkorak samar, darah menetes,
 * mata yang muncul dan berkedip, dan gangguan layar. Mode ALARM dipakai untuk prank virus.
 */
final class Scary extends View {
    static final int LOCK = 0;
    static final int ALARM = 1;
    private static final int DRIPS = 9;
    private static final int EYES = 4;

    private final int mode;
    private final float d;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint haze = new Paint();
    private final Path tri = new Path();
    private final RectF rect = new RectF();
    private long t0;
    private int w;
    private int h;
    private final float[] dx = new float[DRIPS];
    private final float[] dlen = new float[DRIPS];
    private final float[] dw = new float[DRIPS];
    private final float[] dsp = new float[DRIPS];
    private final float[] dph = new float[DRIPS];
    private final float[] ex = new float[EYES];
    private final float[] ey = new float[EYES];
    private final float[] es = new float[EYES];
    private final float[] eph = new float[EYES];
    private final float[] eper = new float[EYES];

    Scary(Context c, int mode) {
        super(c);
        this.mode = mode;
        this.d = c.getResources().getDisplayMetrics().density;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        stroke.setStrokeCap(Paint.Cap.ROUND);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        t0 = SystemClock.uptimeMillis();
        invalidate();
    }

    @Override
    protected void onSizeChanged(int nw, int nh, int ow, int oh) {
        w = nw;
        h = nh;
        haze.setShader(new RadialGradient(w / 2f, h * 0.42f, Math.max(w, h) * 0.75f,
                new int[]{0xFF5C0505, 0x00000000}, null, Shader.TileMode.CLAMP));
        Random r = new Random(11);
        for (int i = 0; i < DRIPS; i++) {
            dx[i] = (i + 0.5f) / DRIPS * w + (r.nextFloat() - 0.5f) * w * 0.05f;
            dlen[i] = h * (0.08f + r.nextFloat() * 0.22f);
            dw[i] = (2.5f + r.nextFloat() * 2.5f) * d;
            dsp[i] = 0.4f + r.nextFloat() * 0.7f;
            dph[i] = r.nextFloat() * 6.28f;
        }
        float[][] pos = {{0.14f, 0.24f}, {0.86f, 0.30f}, {0.12f, 0.58f}, {0.88f, 0.66f}};
        for (int i = 0; i < EYES; i++) {
            ex[i] = pos[i][0] * w;
            ey[i] = pos[i][1] * h;
            es[i] = w * (0.035f + r.nextFloat() * 0.015f);
            eph[i] = r.nextFloat() * 10f;
            eper[i] = 5f + r.nextFloat() * 4f;
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        float s = (SystemClock.uptimeMillis() - t0) / 1000f;
        if (mode == LOCK) {
            drawLock(c, s);
        } else {
            drawAlarm(c, s);
        }
        if (isAttachedToWindow()) {
            postInvalidateOnAnimation();
        }
    }

    private static float rr(int seed) {
        int x = seed * 1103515245 + 12345;
        x = (x >>> 8) & 0xFFFF;
        return x / 65535f;
    }

    // ------------------------------------------------------------------ Lock Screen

    private void drawLock(Canvas c, float s) {
        c.drawColor(Color.BLACK);
        float pulse = 0.55f + 0.35f * (float) Math.sin(s * 1.6f);
        haze.setAlpha((int) (255 * pulse));
        c.drawRect(0, 0, w, h, haze);
        drawSkull(c, s);
        drawDrips(c, s);
        drawEyes(c, s);
        drawGlitch(c, s);
    }

    private void drawSkull(Canvas c, float s) {
        float cx = w / 2f;
        float cy = h * 0.40f;
        float r = Math.min(w, h) * 0.22f;
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0xFFDDD6C6);
        fill.setAlpha((int) (70 + 25 * Math.sin(s * 1.1f)));
        rect.set(cx - r, cy - r * 1.1f, cx + r, cy + r * 0.85f);
        c.drawOval(rect, fill);
        rect.set(cx - r * 0.6f, cy + r * 0.5f, cx + r * 0.6f, cy + r * 1.3f);
        c.drawRoundRect(rect, r * 0.2f, r * 0.2f, fill);

        fill.setColor(Color.BLACK);
        fill.setAlpha(235);
        rect.set(cx - r * 0.68f, cy - r * 0.35f, cx - r * 0.16f, cy + r * 0.30f);
        c.drawOval(rect, fill);
        rect.set(cx + r * 0.16f, cy - r * 0.35f, cx + r * 0.68f, cy + r * 0.30f);
        c.drawOval(rect, fill);
        tri.reset();
        tri.moveTo(cx, cy + r * 0.05f);
        tri.lineTo(cx - r * 0.1f, cy + r * 0.38f);
        tri.lineTo(cx + r * 0.1f, cy + r * 0.38f);
        tri.close();
        c.drawPath(tri, fill);

        float glint = (float) Math.sin(s * 3.3f);
        fill.setColor(0xFFFF2A1A);
        fill.setAlpha((int) (140 + 100 * glint * glint));
        c.drawCircle(cx - r * 0.42f, cy - r * 0.03f, r * 0.08f, fill);
        c.drawCircle(cx + r * 0.42f, cy - r * 0.03f, r * 0.08f, fill);

        stroke.setColor(Color.BLACK);
        stroke.setAlpha(220);
        stroke.setStrokeWidth(2 * d);
        for (int i = -2; i <= 2; i++) {
            c.drawLine(cx + i * r * 0.22f, cy + r * 0.78f, cx + i * r * 0.22f, cy + r * 1.25f, stroke);
        }
        c.drawLine(cx - r * 0.55f, cy + r * 0.95f, cx + r * 0.55f, cy + r * 0.95f, stroke);
    }

    private void drawDrips(Canvas c, float s) {
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0xFF8E0A0A);
        fill.setAlpha(230);
        for (int i = 0; i < DRIPS; i++) {
            float len = dlen[i] * (0.65f + 0.35f * (float) Math.sin(s * dsp[i] + dph[i]));
            rect.set(dx[i] - dw[i] / 2f, 0, dx[i] + dw[i] / 2f, len);
            c.drawRect(rect, fill);
            c.drawCircle(dx[i], len, dw[i] * 1.25f, fill);
        }
    }

    private void drawEyes(Canvas c, float s) {
        fill.setStyle(Paint.Style.FILL);
        for (int i = 0; i < EYES; i++) {
            float t = (s + eph[i]) % eper[i];
            float life = 1.8f;
            if (t > life) {
                continue;
            }
            float a = (float) Math.sin(Math.PI * t / life);
            float sz = es[i];
            fill.setColor(0xFFFF1E1E);
            fill.setAlpha((int) (40 * a));
            c.drawCircle(ex[i], ey[i], sz * 3.2f, fill);
            for (int side = -1; side <= 1; side += 2) {
                float x = ex[i] + side * sz * 1.6f;
                fill.setColor(0xFFFF3B2E);
                fill.setAlpha((int) (255 * a));
                rect.set(x - sz, ey[i] - sz * 0.5f, x + sz, ey[i] + sz * 0.5f);
                c.drawOval(rect, fill);
                fill.setColor(Color.BLACK);
                fill.setAlpha((int) (255 * a));
                rect.set(x - sz * 0.12f, ey[i] - sz * 0.5f, x + sz * 0.12f, ey[i] + sz * 0.5f);
                c.drawOval(rect, fill);
            }
        }
    }

    private void drawGlitch(Canvas c, float s) {
        fill.setStyle(Paint.Style.FILL);
        float cyc = s % 3.7f;
        int k = (int) (s / 3.7f);
        if (cyc < 0.14f) {
            fill.setColor(0xFFFF2A2A);
            fill.setAlpha(70);
            for (int j = 0; j < 3; j++) {
                float y = rr(k * 7 + j) * h;
                float hh = (3 + rr(k * 13 + j) * 10) * d;
                float off = (rr(k * 5 + j) - 0.5f) * 40 * d;
                rect.set(off, y, w + off, y + hh);
                c.drawRect(rect, fill);
            }
        }
        if ((s % 7.3f) < 0.05f) {
            fill.setColor(Color.WHITE);
            fill.setAlpha(45);
            c.drawRect(0, 0, w, h, fill);
        }
    }

    // ------------------------------------------------------------------ alarm virus palsu

    private void drawAlarm(Canvas c, float s) {
        boolean on = ((int) (s * 3.2f)) % 2 == 0;
        c.drawColor(on ? 0xFF3C0000 : 0xFF080000);
        float cx = w / 2f;
        float cy = h * 0.24f;
        float r = Math.min(w, h) * 0.20f;
        tri.reset();
        tri.moveTo(cx, cy - r);
        tri.lineTo(cx + r * 0.95f, cy + r * 0.75f);
        tri.lineTo(cx - r * 0.95f, cy + r * 0.75f);
        tri.close();
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0xFFFF2A2A);
        fill.setAlpha(on ? 60 : 25);
        c.drawPath(tri, fill);
        stroke.setColor(0xFFFF3B2E);
        stroke.setAlpha(on ? 255 : 170);
        stroke.setStrokeWidth(5 * d);
        c.drawPath(tri, stroke);
        fill.setColor(0xFFFF3B2E);
        fill.setAlpha(on ? 255 : 170);
        rect.set(cx - r * 0.07f, cy - r * 0.35f, cx + r * 0.07f, cy + r * 0.25f);
        c.drawRoundRect(rect, r * 0.05f, r * 0.05f, fill);
        c.drawCircle(cx, cy + r * 0.48f, r * 0.09f, fill);

        int k = (int) (s * 12);
        fill.setColor(0xFFFF2A2A);
        fill.setAlpha(60);
        for (int j = 0; j < 2; j++) {
            if (rr(k * 3 + j) < 0.5f) {
                float y = rr(k * 11 + j) * h;
                float hh = (2 + rr(k * 17 + j) * 12) * d;
                float off = (rr(k * 5 + j) - 0.5f) * 60 * d;
                rect.set(off, y, w + off, y + hh);
                c.drawRect(rect, fill);
            }
        }
    }
}
