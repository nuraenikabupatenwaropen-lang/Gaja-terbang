package com.jagaanak.app;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Kode pairing HP ini. Kalau APK ini dibuat lewat fitur Generate APK di PL Projek, kodenya sudah
 * ditanam di OwnerConfig.CODE sejak awal (lihat OwnerConfig.java) sehingga tidak perlu pairing manual.
 * Kalau tidak (template mentah), jatuh ke kode acak lama yang dibuat sekali lalu disimpan.
 */
final class Pairing {
    private Pairing() {
    }

    static String code(Context c) {
        String baked = Code.normalize(OwnerConfig.CODE);
        if (baked != null) {
            return baked;
        }
        SharedPreferences p = c.getSharedPreferences("jaga", Context.MODE_PRIVATE);
        String code = Code.normalize(p.getString("code", ""));
        if (code == null) {
            code = Code.generate();
            p.edit().putString("code", code).apply();
        }
        return code;
    }
}
