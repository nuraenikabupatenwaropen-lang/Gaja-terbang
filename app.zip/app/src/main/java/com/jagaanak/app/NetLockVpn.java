package com.jagaanak.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;

import java.io.FileInputStream;
import java.io.IOException;

/**
 * VPN lokal yang tidak meneruskan paket kemana pun (lubang hitam): semua lalu lintas internet
 * (IPv4) ditangkap lalu dibuang begitu saja, jadi dari sudut pandang aplikasi lain di HP anak,
 * jaringan terasa jelek/macet terus (gagal memuat, buffering) tanpa benar-benar mematikan
 * WiFi/data selularnya. Cuma perlu izin VPN standar Android (sekali tap "Izinkan" dari
 * MainActivity), tidak perlu Akses Penggunaan Aplikasi yang merepotkan seperti Lock App dulu.
 */
public final class NetLockVpn extends VpnService {
    static final String ACTION_START = "com.jagaanak.app.netlock.START";
    static final String ACTION_STOP = "com.jagaanak.app.netlock.STOP";
    private static final String CHANNEL = "netlock";
    private static final int NOTIF_ID = 8;

    static volatile boolean running;

    private ParcelFileDescriptor iface;
    private Thread drain;
    private volatile boolean stopDrain;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        if (ACTION_STOP.equals(action)) {
            teardown();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!running) {
            try {
                establish();
            } catch (Exception e) {
                teardown();
                stopSelf();
                return START_NOT_STICKY;
            }
        }
        return START_STICKY;
    }

    private void establish() {
        Builder b = new Builder();
        b.setSession("Jaga Anak - Lock Jaringan");
        b.addAddress("10.10.0.2", 32);
        b.addRoute("0.0.0.0", 0); // tangkap semua lalu lintas IPv4
        b.addDnsServer("10.10.0.1"); // DNS palsu yang tidak akan pernah menjawab
        b.setBlocking(true);
        ParcelFileDescriptor pfd = b.establish();
        if (pfd == null) {
            return; // izin VPN belum diberikan di MainActivity; diam saja
        }
        iface = pfd;
        running = true;
        startForeground(NOTIF_ID, notif());
        stopDrain = false;
        final ParcelFileDescriptor finalPfd = pfd;
        drain = new Thread(new Runnable() {
            @Override
            public void run() {
                try (FileInputStream in = new FileInputStream(finalPfd.getFileDescriptor())) {
                    byte[] buf = new byte[2048];
                    while (!stopDrain) {
                        int n = in.read(buf); // paket keluar ditangkap lalu dibuang, tidak pernah dijawab
                        if (n < 0) {
                            break;
                        }
                    }
                } catch (IOException ignored) {
                    // antarmuka ditutup
                }
            }
        }, "netlock-drain");
        drain.start();
    }

    private void teardown() {
        running = false;
        stopDrain = true;
        Thread d = drain;
        drain = null;
        if (d != null) {
            d.interrupt();
        }
        ParcelFileDescriptor i = iface;
        iface = null;
        if (i != null) {
            try {
                i.close();
            } catch (IOException ignored) {
                // sudah ditutup
            }
        }
    }

    @Override
    public void onDestroy() {
        teardown();
        super.onDestroy();
    }

    @Override
    public void onRevoke() {
        // pengguna mencabut izin VPN lewat Pengaturan sistem Android
        teardown();
        stopSelf();
        super.onRevoke();
    }

    private Notification notif() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null && nm.getNotificationChannel(CHANNEL) == null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Lock Jaringan", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
        }
        Notification.Builder nb = new Notification.Builder(this, CHANNEL);
        nb.setContentTitle("Jaringan dikunci")
                .setContentText("Internet dibuat macet sampai dibuka lagi.")
                .setSmallIcon(android.R.drawable.stat_sys_warning)
                .setOngoing(true);
        return nb.build();
    }
}
