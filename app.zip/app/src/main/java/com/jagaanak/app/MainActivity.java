package com.jagaanak.app;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/** Jaga Anak: aplikasi di HP anak. Tekan Izinkan Semua, lalu terhubung ke PL Projek lewat internet. */
public class MainActivity extends Activity {

    private static final int REQ_PERM = 21;
    private static final int REQ_VPN = 23;
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean allowAllFlow;
    private TextView stNet;
    private TextView btnLabel;
    private TextView btnSub;
    private LinearLayout btn;
    private FrameLayout btnIcon;
    private Ui.IconView btnIconView;
    private TextView stScreen;
    private TextView stApps;

    private final Runnable refresh = new Runnable() {
        @Override
        public void run() {
            refreshUi();
            handler.postDelayed(this, 800);
        }
    };

    // ------------------------------------------------------------------ siklus hidup

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Window w = getWindow();
        w.setStatusBarColor(Ui.BG);
        w.setNavigationBarColor(Ui.BG);
        w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Ui.BG);
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(10), dp(16), dp(28));

        col.addView(Ui.sectionHead(this, Ui.LOCK, "Jaga Anak"), lp(MATCH, WRAP, 0, 8, 0, 14));
        TextView intro = Ui.text(this,
                "Aplikasi ini dipasang di HP anak. Tekan Izinkan Semua di bawah, semua izin akan aktif otomatis dan HP ini langsung terhubung ke PL Projek lewat internet.",
                13, Ui.SOFT, false, true);
        intro.setLineSpacing(0, 1.2f);
        col.addView(intro, lp(MATCH, WRAP, 4, 0, 4, 20));

        // tombol Izinkan Semua / Aktif
        btn = new LinearLayout(this);
        btn.setGravity(Gravity.CENTER_VERTICAL);
        btn.setPadding(dp(18), dp(18), dp(18), dp(18));
        btn.setElevation(dp(6));
        btn.setClickable(true);
        btn.setOnClickListener(v -> {
            if (GuardService.running) {
                stopGuard();
            } else {
                startAllowAll();
            }
        });
        Ui.pressable(btn);
        btnIcon = new FrameLayout(this);
        btnIconView = new Ui.IconView(this, Ui.LOCK, Ui.INK);
        btnIcon.addView(btnIconView, new FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER));
        btn.addView(btnIcon, lp(dp(56), dp(56), 0, 0, 16, 0));
        LinearLayout bt = new LinearLayout(this);
        bt.setOrientation(LinearLayout.VERTICAL);
        btnLabel = Ui.text(this, "Izinkan Semua", 18, Ui.INK, true, false);
        btnSub = Ui.text(this, "", 12, Ui.SOFT, false, true);
        bt.addView(btnLabel, lp(WRAP, WRAP, 0, 0, 0, 6));
        bt.addView(btnSub, lp(WRAP, WRAP, 0, 0, 0, 0));
        btn.addView(bt, new LinearLayout.LayoutParams(0, WRAP, 1f));
        col.addView(btn, lp(MATCH, WRAP, 0, 0, 0, 16));

        // status
        LinearLayout st = card();
        stNet = value();
        stScreen = value();
        stApps = value();
        st.addView(statRow("Internet", stNet), lp(MATCH, WRAP, 0, 0, 0, 12));
        st.addView(statRow("Layar", stScreen), lp(MATCH, WRAP, 0, 0, 0, 12));
        st.addView(statRow("Jaringan", stApps), lp(MATCH, WRAP, 0, 0, 0, 0));
        col.addView(st, lp(MATCH, WRAP, 0, 0, 0, 16));

        TextView foot = Ui.text(this,
                "Aplikasi ini terlihat di daftar aplikasi dan menampilkan notifikasi selama aktif. Tersambung otomatis ke PL Projek yang membuat APK ini.",
                11.5f, Ui.SOFT, false, true);
        foot.setLineSpacing(0, 1.2f);
        col.addView(foot, lp(MATCH, WRAP, 4, 0, 4, 0));

        sv.addView(col, new FrameLayout.LayoutParams(MATCH, WRAP));
        root.addView(sv, new FrameLayout.LayoutParams(MATCH, MATCH));
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(refresh);
        continueAllowAll();
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(refresh);
        super.onPause();
    }

    // ------------------------------------------------------------------ pembantu tampilan

    private int dp(float v) {
        return Ui.dp(this, v);
    }

    private LinearLayout.LayoutParams lp(int w, int h, float l, float t, float r, float b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(18), dp(18), dp(18), dp(18));
        c.setBackground(Ui.box(this, Ui.SURFACE, 26, Ui.EDGE, 1));
        c.setElevation(dp(4));
        return c;
    }

    private TextView pill() {
        TextView t = Ui.text(this, "", 12, Ui.INK, true, false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), dp(7), dp(12), dp(7));
        return t;
    }

    private TextView value() {
        TextView t = Ui.text(this, "-", 14, Ui.INK, true, false);
        t.setGravity(Gravity.END);
        return t;
    }

    private LinearLayout statRow(String label, TextView value) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.addView(Ui.text(this, label, 13, Ui.SOFT, false, true), new LinearLayout.LayoutParams(WRAP, WRAP));
        r.addView(value, new LinearLayout.LayoutParams(0, WRAP, 1f));
        return r;
    }

    private void refreshUi() {
        boolean on = GuardService.running;
        boolean ready = permOk() && overOk() && vpnOk() && batteryOk();
        btn.setBackground(Ui.box(this, on ? Ui.INK : Ui.SURFACE, 26, on ? Ui.INK : Ui.EDGE, 1.5f));
        btnIcon.setBackground(Ui.box(this, on ? 0x26FFFFFF : Ui.BG, 18, 0, 0));
        btnIconView.setColor(on ? Color.WHITE : Ui.INK);
        if (on) {
            btnLabel.setText("Matikan");
            btnSub.setText("Aktif. Bisa dikontrol lewat internet.");
        } else if (ready) {
            btnLabel.setText("Nyalakan");
            btnSub.setText("Tekan untuk mengaktifkan penjagaan.");
        } else {
            btnLabel.setText("Izinkan Semua");
            btnSub.setText("Tekan sekali untuk izinkan semua akses, lalu otomatis menyala.");
        }
        btnLabel.setTextColor(on ? Color.WHITE : Ui.INK);
        btnSub.setTextColor(on ? 0xB3FFFFFF : Ui.SOFT);

        if (!on) {
            stNet.setText("Belum aktif");
            stScreen.setText("-");
            stApps.setText("-");
        } else {
            stNet.setText(Remote.status);
            stScreen.setText(GuardService.screenLocked ? "Terkunci" : "Terbuka");
            stApps.setText(NetLockVpn.running ? "Dikunci" : "Normal");
        }
    }

    // ------------------------------------------------------------------ izin

    private String[] runtimePerms() {
        ArrayList<String> l = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33) {
            l.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        l.add(Manifest.permission.CAMERA);
        return l.toArray(new String[0]);
    }

    private boolean permOk() {
        for (String p : runtimePerms()) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    private boolean overOk() {
        return Settings.canDrawOverlays(this);
    }

    private boolean vpnOk() {
        // null berarti izin VPN sudah diberikan (atau tidak diperlukan lagi)
        return android.net.VpnService.prepare(this) == null;
    }

    private void askRuntime() {
        if (permOk()) {
            return;
        }
        requestPermissions(runtimePerms(), REQ_PERM);
    }

    private void openOverlay() {
        if (overOk()) {
            return;
        }
        startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
    }

    private boolean batteryOk() {
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        return pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
    }

    private void openBattery() {
        if (batteryOk()) {
            return;
        }
        try {
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        }
    }

    private void openVpnConsent() {
        if (vpnOk()) {
            return;
        }
        Intent i = android.net.VpnService.prepare(this);
        if (i != null) {
            startActivityForResult(i, REQ_VPN);
        } else {
            refreshUi();
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        refreshUi();
        continueAllowAll();
    }

    // ------------------------------------------------------------------ izinkan semua (satu tombol)

    /** Dipicu dari tombol: minta semua izin yang belum aktif satu per satu, lalu otomatis nyalakan Bluetooth. */
    private void startAllowAll() {
        allowAllFlow = true;
        continueAllowAll();
    }

    /** Dipanggil ulang tiap kembali ke layar ini (izin lewat Settings tidak selalu kasih callback langsung). */
    private void continueAllowAll() {
        if (!allowAllFlow) {
            return;
        }
        if (!permOk()) {
            askRuntime();
            return;
        }
        if (!overOk()) {
            openOverlay();
            return;
        }
        if (!vpnOk()) {
            openVpnConsent();
            return;
        }
        if (!batteryOk()) {
            openBattery();
            return;
        }
        allowAllFlow = false;
        startGuard();
    }

    // ------------------------------------------------------------------ nyala/mati penjagaan

    private void stopGuard() {
        startService(new Intent(this, GuardService.class).setAction(GuardService.ACTION_STOP));
        toast("Penjagaan dimatikan. Kunci dilepas sampai diaktifkan lagi.");
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_VPN) {
            refreshUi(); // cuma catat hasilnya; tidak memblokir apa pun kalau ditolak
            continueAllowAll();
        }
    }

    private void startGuard() {
        getSharedPreferences("jaga", MODE_PRIVATE).edit().putBoolean("auto", true).apply();
        startForegroundService(new Intent(this, GuardService.class));
        if (!batteryOk()) {
            toast("Aktifkan juga Tetap aktif di latar belakang supaya kontrol internet tidak terputus.");
        }
    }
}
