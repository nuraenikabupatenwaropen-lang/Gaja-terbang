package com.jagaanak.app;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Kontrol jarak jauh di HP anak lewat Firebase Realtime Database.
 * Mendengarkan /p/KODE/cmds, menjalankan perintah lewat Host, lalu menulis keadaan ke /p/KODE/state.
 */
final class Remote {
    interface Host {
        /** Dipanggil di thread latar. Host yang memindahkannya ke main thread dan memanggil pushState() setelahnya. img = base64 (dipakai perintah wallpaper), boleh kosong. */
        void command(String cmd, String pkg, String msg, String pw, String img);

        String stateJson();

        String appsJson();

        String deviceName();
    }

    static volatile String status = "Mati";

    private final String code;
    private final Host host;
    private final ScheduledExecutorService io = Executors.newSingleThreadScheduledExecutor();
    private final Set<String> handled = new HashSet<>();
    private volatile Rtdb.Stream stream;
    private volatile boolean stopped;

    Remote(String code, Host host) {
        this.code = code;
        this.host = host;
    }

    private String root() {
        return "/p/" + code;
    }

    void start() {
        status = "Menghubungkan…";
        openStream();
        try {
            io.scheduleWithFixedDelay(new Runnable() {
                @Override
                public void run() {
                    try {
                        beat();
                    } catch (Exception ignored) {
                        // putaran berikutnya tetap jalan
                    }
                }
            }, 30, 30, TimeUnit.SECONDS);
        } catch (RejectedExecutionException ignored) {
            // sudah dihentikan
        }
    }

    private void openStream() {
        stream = Rtdb.stream(root() + "/cmds", new Rtdb.Events() {
            @Override
            public void onOpen() {
                status = "Terhubung";
                pushState();
            }

            @Override
            public void onEvent(final String event, final String data) {
                submit(new Runnable() {
                    @Override
                    public void run() {
                        onCmdEvent(event, data);
                    }
                });
            }

            @Override
            public void onError(int httpCode, String message, boolean everOpened) {
                status = httpCode == 401 || httpCode == 403 ? "Ditolak Firebase (cek Rules)" : "Tidak ada internet";
                if (!everOpened && !stopped) {
                    scheduleRetry(); // percobaan pertama yang gagal menghentikan aliran, jadi diulang di sini
                }
            }
        });
    }

    private void scheduleRetry() {
        try {
            io.schedule(new Runnable() {
                @Override
                public void run() {
                    if (!stopped) {
                        openStream();
                    }
                }
            }, 20, TimeUnit.SECONDS);
        } catch (RejectedExecutionException ignored) {
            // sudah dihentikan
        }
    }

    void stop() {
        stopped = true;
        Rtdb.Stream s = stream;
        if (s != null) {
            s.close();
        }
        io.shutdownNow();
        status = "Mati";
    }

    private void submit(Runnable r) {
        if (stopped) {
            return;
        }
        try {
            io.execute(r);
        } catch (RejectedExecutionException ignored) {
            // sudah dihentikan
        }
    }

    /** Menulis keadaan terkini ke Firebase. Aman dipanggil dari thread mana pun. */
    void pushState() {
        submit(new Runnable() {
            @Override
            public void run() {
                doPushState();
            }
        });
    }

    /** Menulis daftar aplikasi lalu keadaan. */
    void pushApps() {
        submit(new Runnable() {
            @Override
            public void run() {
                Rtdb.put(root() + "/state/apps", JSONObject.quote(host.appsJson()));
                doPushState();
            }
        });
    }

    /** Menulis satu foto (base64 JPEG) ke Firebase. Aman dipanggil dari thread mana pun. */
    void pushPhoto(final String base64) {
        submit(new Runnable() {
            @Override
            public void run() {
                Rtdb.put(root() + "/state/photo", JSONObject.quote(base64));
                beat();
            }
        });
    }

    private void doPushState() {
        Rtdb.put(root() + "/state/s", JSONObject.quote(host.stateJson()));
        Rtdb.put(root() + "/state/name", JSONObject.quote(host.deviceName()));
        beat();
    }

    private void beat() {
        boolean ok = Rtdb.put(root() + "/state/seen", "{\".sv\":\"timestamp\"}");
        if (ok) {
            if ("Tidak ada internet".equals(status)) {
                status = "Terhubung";
            }
        } else if (!status.startsWith("Ditolak")) {
            status = "Tidak ada internet";
        }
    }

    private void onCmdEvent(String event, String raw) {
        if (!"put".equals(event) && !"patch".equals(event)) {
            return;
        }
        try {
            JSONObject d = new JSONObject(raw);
            String path = d.optString("path", "");
            Object data = d.opt("data");
            if (!(data instanceof JSONObject)) {
                return;
            }
            JSONObject o = (JSONObject) data;
            if ("/".equals(path)) {
                ArrayList<String> keys = new ArrayList<>();
                Iterator<String> it = o.keys();
                while (it.hasNext()) {
                    keys.add(it.next());
                }
                Collections.sort(keys); // kunci Firebase berurutan menurut waktu
                for (String k : keys) {
                    JSONObject c = o.optJSONObject(k);
                    if (c != null) {
                        run(k, c);
                    }
                }
            } else if (path.length() > 1 && path.indexOf('/', 1) < 0) {
                run(path.substring(1), o);
            }
        } catch (Exception ignored) {
            // kejadian rusak diabaikan
        }
    }

    private void run(String key, JSONObject c) {
        if (!key.matches("[-_A-Za-z0-9]{1,40}")) {
            return;
        }
        if (!handled.add(key)) {
            return; // sudah dijalankan (misalnya setelah tersambung ulang)
        }
        if (handled.size() > 500) {
            handled.clear();
            handled.add(key);
        }
        try {
            String cmd = c.optString("cmd", "");
            String pkg = c.optString("pkg", "");
            String msg = c.optString("msg", "");
            String pw = c.optString("pw", "");
            String img = c.optString("img", "");
            if (!cmd.isEmpty()) {
                host.command(cmd, pkg, msg, pw, img);
            }
        } catch (Exception ignored) {
            // satu perintah gagal tidak boleh menghentikan yang lain
        } finally {
            Rtdb.delete(root() + "/cmds/" + key);
        }
    }
}
